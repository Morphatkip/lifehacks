import React from "react";
import NavBar from "../components/NavBar";

import { HeroSectionPages } from "../components/HeroSection";
import Packages from "../components/homesection/Packages";
import Footer from "../components/Footer";
import Booking from "../components/homesection/Booking";
import Process from "../components/homesection/Process";

function PackagesPage() {
  return (
    <body>
      <NavBar>
        <HeroSectionPages
          title={"Packages"}
          backgroundImageUrl={
            "https://images.unsplash.com/photo-1449247666642-264389f5f5b1?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fFBhY2thZ2VzfGVufDB8fDB8fHww"
          }
        />
      </NavBar>
      <Packages />
      <Booking />
      <Process />
      <Footer />
    </body>
  );
}

export default PackagesPage;
