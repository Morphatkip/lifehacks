import React from "react";
import NavBar from "../components/NavBar";
import { HeroSectionPages } from "../components/HeroSection";
import Teams from "../components/homesection/Teams";
import Footer from "../components/Footer";

function TravelGuide() {
  return (
    <body>
      <NavBar>
        <HeroSectionPages
          title={"Travel guide"}
          backgroundImageUrl={
            "https://plus.unsplash.com/premium_photo-1661456049395-0eae5614858d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8dHJhdmVsJTIwZ3VpZGV8ZW58MHx8MHx8fDA%3D"
          }
        />
      </NavBar>
      <Teams />

      <Footer />
    </body>
  );
}

export default TravelGuide;
