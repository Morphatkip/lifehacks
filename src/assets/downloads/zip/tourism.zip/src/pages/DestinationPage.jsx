import React from "react";
import NavBar from "../components/NavBar";
import { HeroSectionPages } from "../components/HeroSection";
import PopularDestination from "../components/homesection/Destination";
import Footer from "../components/Footer";

function DestinationPage() {
  return (
    <body>
      <NavBar>
        <HeroSectionPages
          title={"Destination"}
          backgroundImageUrl={
            "https://images.unsplash.com/photo-1473442240418-452f03b7ae40?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8ZGVzdGluYXRpb258ZW58MHx8MHx8fDA%3D"
          }
        />
      </NavBar>
      <PopularDestination />
      <Footer />
    </body>
  );
}

export default DestinationPage;
