import React from "react";
import NavBar from "../components/NavBar";
import About from "../components/homesection/About";
import Footer from "../components/Footer";
import Teams from "../components/homesection/Teams";
import { HeroSectionPages } from "../components/HeroSection";

function AboutPage() {
  return (
    <body>
      <NavBar>
        <HeroSectionPages
          title={"About Us"}
          backgroundImageUrl={
            "https://plus.unsplash.com/premium_photo-1665990293319-fe271ebcb6f3?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8YWJvdXR8ZW58MHx8MHx8fDA%3D"
          }
        />
      </NavBar>

      <About />
      <Teams />
      <Footer />
    </body>
  );
}

export default AboutPage;
