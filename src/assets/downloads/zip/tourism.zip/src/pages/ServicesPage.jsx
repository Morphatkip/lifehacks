import React from "react";
import NavBar from "../components/NavBar";
import Services from "../components/homesection/Services";
import Testimonial from "../components/homesection/Testimonial";
import Footer from "../components/Footer";
import { HeroSectionPages } from "../components/HeroSection";
function ServicesPage() {
  return (
    <body>
      <NavBar>
        <HeroSectionPages
          title={"Services"}
          backgroundImageUrl={
            "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjB8fFNlcnZpY2VzfGVufDB8fDB8fHww"
          }
        />
      </NavBar>
      <Services />
      <Testimonial />
      <Footer />
    </body>
  );
}

export default ServicesPage;
