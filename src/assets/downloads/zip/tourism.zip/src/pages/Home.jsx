import NavBar from "../components/NavBar";
import "../assets/css/style.css";
import "../assets/css/animations.css";
import Footer from "../components/Footer";
import Packages from "../components/homesection/Packages";
import PopularDestination from "../components/homesection/Destination";
import Services from "../components/homesection/Services";
import Testimonial from "../components/homesection/Testimonial";
import Teams from "../components/homesection/Teams";
import Process from "../components/homesection/Process";
import Booking from "../components/homesection/Booking";
import About from "../components/homesection/About";
import { HeroSection } from "../components/HeroSection";

function Home() {
  return (
    <div>
      {/* Navbar & Hero Start  */}
      <NavBar>
        <HeroSection />
      </NavBar>
      {/* Navbar & Hero End */}

      {/*    About Start  */}
      <About />

      {/*  About End  */}

      {/*   Service Start  */}
      <Services />
      {/* Service End  */}

      {/* Destination Start */}
      <PopularDestination />
      {/*  Destination Start  */}

      {/*  Package Start  */}
      <Packages />
      {/*    Package End  */}

      {/*   Booking Start   */}
      <Booking />
      {/*   Booking Start   */}

      {/*   Process Start   */}
      <Process />
      {/*   Process Start   */}

      {/*   Team Start   */}
      <Teams />
      {/*   Team End   */}

      {/*   Testimonial Start   */}
      <Testimonial />
      {/*   Testimonial End   */}

      {/* Footer start */}
      <Footer />
      {/* Footer end */}
    </div>
  );
}

export default Home;
