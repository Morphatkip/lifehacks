import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";

function NavBar({ children }) {
  const [isCollapsed, setIsCollapsed] = useState(true);
  const location = useLocation();

  const toggleNavbar = () => {
    setIsCollapsed(!isCollapsed);
  };

  const isActive = (path) => location.pathname === path;

  return (
    <div>
      <div className="container-fluid position-relative p-0">
        <nav className="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">
          <Link to="/" className="navbar-brand p-0">
            <h1 className="text-primary m-0">
              <i className="bi bi-geo-alt"></i>Expedition
            </h1>
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            onClick={toggleNavbar}
            aria-controls="navbarCollapse"
            aria-expanded={!isCollapsed}
            aria-label="Toggle navigation"
          >
            <span className="bi bi-list"></span>
          </button>
          <div
            className={`collapse navbar-collapse ${isCollapsed ? "" : "show"}`}
            id="navbarCollapse"
          >
            <div className="navbar-nav ms-auto py-0">
              <Link
                to="/"
                className={`nav-item nav-link ${isActive("/") ? "active" : ""}`}
              >
                Home
              </Link>
              <Link
                to="/about"
                className={`nav-item nav-link ${
                  isActive("/about") ? "active" : ""
                }`}
              >
                About
              </Link>
              <Link
                to="/services"
                className={`nav-item nav-link ${
                  isActive("/services") ? "active" : ""
                }`}
              >
                Services
              </Link>
              <Link
                to="/packages"
                className={`nav-item nav-link ${
                  isActive("/packages") ? "active" : ""
                }`}
              >
                Packages
              </Link>
              <div className="nav-item dropdown">
                <Link
                  to="#"
                  className={`nav-link dropdown-toggle ${
                    location.pathname.startsWith("/pages") ? "active" : ""
                  }`}
                  data-bs-toggle="dropdown"
                >
                  Pages
                </Link>
                <div className="dropdown-menu m-0">
                  <Link
                    to="/pages/destination"
                    className={`dropdown-item ${
                      isActive("/pages/destination") ? "active" : ""
                    }`}
                  >
                    Destination
                  </Link>
                  <Link
                    to="/pages/booking"
                    className={`dropdown-item ${
                      isActive("/pages/booking") ? "active" : ""
                    }`}
                  >
                    Booking
                  </Link>
                  <Link
                    to="/travel-guides"
                    className={`dropdown-item ${
                      isActive("/travel-guides") ? "active" : ""
                    }`}
                  >
                    Travel Guides
                  </Link>
                  <Link
                    to="/testimonials"
                    className={`dropdown-item ${
                      isActive("/testimonials") ? "active" : ""
                    }`}
                  >
                    Testimonial
                  </Link>
                </div>
              </div>
              <Link
                to="/contact"
                className={`nav-item nav-link ${
                  isActive("/contact") ? "active" : ""
                }`}
              >
                Contact
              </Link>
            </div>
            <Link to="/" className="btn btn-primary rounded-pill py-2 px-4">
              Register
            </Link>
          </div>
        </nav>

        {children}
      </div>
    </div>
  );
}

export default NavBar;
