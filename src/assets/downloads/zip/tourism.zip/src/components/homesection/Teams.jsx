import React from "react";
import { Link } from "react-router-dom";

function Teams() {
  return (
    <div className="container-xxl py-5">
      <div className="container">
        <div className="text-center wow fadeInUp" data-wow-delay="0.1s">
          <h6 className="section-title bg-white text-center text-primary px-3">
            Travel Guide
          </h6>
          <h1 className="mb-5">Meet Our Guide</h1>
        </div>
        <div className="row g-4">
          <div className="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
            <div className="team-item">
              <div className="overflow-hidden">
                <img
                  className="img-fluid"
                  src="https://plus.unsplash.com/premium_photo-1682095218963-4e9fa1162f20?dpr=1&w=306&auto=format&fit=crop&q=60&crop=entropy&cs=tinysrgb&fm=jpg&ixid=M3wxMjA3fDB8MXxzZWFyY2h8Nnx8b2ZmaWNpYWwlMjBwZXJzb24lMjBwaG90b3xlbnwwfDB8fHwxNzE3NzY2OTI2fDE&ixlib=rb-4.0.3"
                  alt=""
                />
              </div>
              <div
                className="position-relative d-flex justify-content-center"
                style={{ marginTop: "-19px" }}
              >
                <Link className="btn btn-square mx-1" to="">
                  <i className="fab fa-facebook-f"></i>
                </Link>
                <Link className="btn btn-square mx-1" to="">
                  <i className="fab fa-twitter"></i>
                </Link>
                <Link className="btn btn-square mx-1" to="">
                  <i className="fab fa-instagram"></i>
                </Link>
              </div>
              <div className="text-center p-4">
                <h5 className="mb-0">Full Name</h5>
                <small>Designation</small>
              </div>
            </div>
          </div>
          <div className="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
            <div className="team-item">
              <div className="overflow-hidden">
                <img
                  className="img-fluid"
                  src="https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjJ8fHBlb3BsZXxlbnwwfHwwfHx8MA%3D%3D"
                  alt=""
                />
              </div>
              <div
                className="position-relative d-flex justify-content-center"
                style={{ marginTop: "-19px" }}
              >
                <Link className="btn btn-square mx-1" to="">
                  <i className="fab fa-facebook-f"></i>
                </Link>
                <Link className="btn btn-square mx-1" to="">
                  <i className="fab fa-twitter"></i>
                </Link>
                <Link className="btn btn-square mx-1" to="">
                  <i className="fab fa-instagram"></i>
                </Link>
              </div>
              <div className="text-center p-4">
                <h5 className="mb-0">Full Name</h5>
                <small>Designation</small>
              </div>
            </div>
          </div>
          <div className="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
            <div className="team-item">
              <div className="overflow-hidden">
                <img
                  className="img-fluid"
                  src="https://plus.unsplash.com/premium_photo-1682095218963-4e9fa1162f20?dpr=1&w=306&auto=format&fit=crop&q=60&crop=entropy&cs=tinysrgb&fm=jpg&ixid=M3wxMjA3fDB8MXxzZWFyY2h8Nnx8b2ZmaWNpYWwlMjBwZXJzb24lMjBwaG90b3xlbnwwfDB8fHwxNzE3NzY2OTI2fDE&ixlib=rb-4.0.3"
                  alt=""
                />
              </div>
              <div
                className="position-relative d-flex justify-content-center"
                style={{ marginTop: "-19px" }}
              >
                <Link className="btn btn-square mx-1" to="">
                  <i className="fab fa-facebook-f"></i>
                </Link>
                <Link className="btn btn-square mx-1" to="">
                  <i className="fab fa-twitter"></i>
                </Link>
                <Link className="btn btn-square mx-1" to="">
                  <i className="fab fa-instagram"></i>
                </Link>
              </div>
              <div className="text-center p-4">
                <h5 className="mb-0">Full Name</h5>
                <small>Designation</small>
              </div>
            </div>
          </div>
          <div className="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
            <div className="team-item">
              <div className="overflow-hidden">
                <img
                  className="img-fluid"
                  src="https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjJ8fHBlb3BsZXxlbnwwfHwwfHx8MA%3D%3D"
                  alt=""
                />
              </div>
              <div
                className="position-relative d-flex justify-content-center"
                style={{ marginTop: "-19px" }}
              >
                <Link className="btn btn-square mx-1" to="">
                  <i className="fab fa-facebook-f"></i>
                </Link>
                <Link className="btn btn-square mx-1" to="">
                  <i className="fab fa-twitter"></i>
                </Link>
                <Link className="btn btn-square mx-1" to="">
                  <i className="fab fa-instagram"></i>
                </Link>
              </div>
              <div className="text-center p-4">
                <h5 className="mb-0">Full Name</h5>
                <small>Designation</small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Teams;
