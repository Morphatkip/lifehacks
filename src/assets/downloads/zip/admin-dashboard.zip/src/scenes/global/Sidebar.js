import { useState } from "react";
import { ProSidebar, Menu, MenuItem } from "react-pro-sidebar";
import { Box, IconButton, Typography, useTheme } from "@mui/material";
import { Link } from "react-router-dom";
import "react-pro-sidebar/dist/css/styles.css";
import { tokens } from "../../theme";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import PeopleOutlinedIcon from "@mui/icons-material/PeopleOutlined";
import ContactsOutlinedIcon from "@mui/icons-material/ContactsOutlined";
import ReceiptOutlinedIcon from "@mui/icons-material/ReceiptOutlined";
import PersonOutlinedIcon from "@mui/icons-material/PersonOutlined";
import CalendarTodayOutlinedIcon from "@mui/icons-material/CalendarTodayOutlined";
import HelpOutlineOutlinedIcon from "@mui/icons-material/HelpOutlineOutlined";
import BarChartOutlinedIcon from "@mui/icons-material/BarChartOutlined";
import PieChartOutlineOutlinedIcon from "@mui/icons-material/PieChartOutlineOutlined";
import TimelineOutlinedIcon from "@mui/icons-material/TimelineOutlined";
import MenuOutlinedIcon from "@mui/icons-material/MenuOutlined";
import MapOutlinedIcon from "@mui/icons-material/MapOutlined";

const Item = ({ title, to, icon, selected, setSelected }) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <MenuItem
      active={selected === title}
      style={{
        color: colors.grey[100],
      }}
      onClick={() => setSelected(title)}
      icon={icon}
    >
      <Typography>{title}</Typography>
      <Link to={to} />
    </MenuItem>
  );
};

const Sidebar = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [selected, setSelected] = useState("Dashboard");

  return (
    <Box
      sx={{
        "& .pro-sidebar-inner": {
          background: `${colors.primary[400]} !important`,
        },
        "& .pro-icon-wrapper": {
          backgroundColor: "transparent !important",
        },
        "& .pro-inner-item": {
          padding: "5px 35px 5px 20px !important",
        },
        "& .pro-inner-item:hover": {
          color: "#868dfb !important",
        },
        "& .pro-menu-item.active": {
          color: "#6870fa !important",
        },
      }}
    >
      <ProSidebar collapsed={isCollapsed}>
        <Menu iconShape="square">
          {/* LOGO AND MENU ICON */}
          <MenuItem
            onClick={() => setIsCollapsed(!isCollapsed)}
            icon={isCollapsed ? <MenuOutlinedIcon /> : undefined}
            style={{
              margin: "10px 0 20px 0",
              color: colors.grey[100],
            }}
          >
            {!isCollapsed && (
              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                ml="15px"
              >
                <Typography variant="h3" color={colors.grey[100]}>
                  ADMINIS
                </Typography>
                <IconButton onClick={() => setIsCollapsed(!isCollapsed)}>
                  <MenuOutlinedIcon />
                </IconButton>
              </Box>
            )}
          </MenuItem>

          {!isCollapsed && (
            <Box mb="25px">
              <Box display="flex" justifyContent="center" alignItems="center">
                <img
                  alt="profile-user"
                  width="100px"
                  height="100px"
                  src={"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAnwMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAAAwQHAQUGAgj/xAA+EAABAgQDBAkCAwcDBQAAAAABAAIDBBEhBQYSEzFBUQcUIjJhcYGRoVLBI0JiCBVykrHC0UOy8CQzNIKi/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAECAwQFBv/EACQRAAMAAgEEAQUBAAAAAAAAAAABAgMREgQhMUEFBiJCUYEy/9oADAMBAAIRAxEAPwC5Nm/6Smwfw667V5qQo01vb4oB20ZTvBRixxJIaaLwpw3DyQEeACxxL7CnFOMRvBwS5rujzXJdIuYTlnKk5PQiOsuAhSwrve40B9BU+iA4vpI6WP3fNTGE5Z0umWOLI044AtYdxDBxI5m3gVSk5NzE9MxJqdjxY8xENXxYjtRck+JJJO8nihACEIQkEIQgGykzHk5mHMSsaJAjwzqZEhuLXNPgVdfRn0quxCbl8IzM5omXuDYE9ZoiHg1/AE7gRYqj0A0IIqCLgg0QH2ttGU7w90mMC9wLLgDguO6McwOzHlCTmo79c1A/6eYPEvbxPiRQ+q7SV7h80IEiG+x0lSdoz6gvTtxUAICRH7dCy9OSVs3/AElNlvzKQgIvWHcgst/HPatp5f8APBJoeR9k+XtqrbzQGert5uXjbuBsByUnUOY91CLSCbHfyQDWnbnS7heypT9oubcyZwXDmOdswyJMOHM1DR/d7q65ezjW1uKpj9o+Vq/Ap5tKUiwXH+Vw+6Apbehdb0ZYFK5hzG+Un4W0lWSsSJEbqI4taL8LuW7zL0T4jKPdGwCKJ2Bc7GIQ2K37O+FR3KemXUNraK3RdTprB8Uk4hhzeGzkFwNDrgOHzS63GWsi45j8wwNlYkpK17czMQy1oHGgN3HyVm0iEmzmOIAFzuHNSI8jOy8LazEnMwof1xILmt9yF9DZXyXg+W2B0rB203TtTUftP9ODfRdE8Ne3S8BzTvBvVYPOk+yNlgeu7Pk9CunPvRvKzsvGxHAITZecY0ufLsFGRgLmg/K7ysflUsCDuW0UqXYyqHL7l0fs5zTnvxvD3uOgCFHaBwN2n7K6XHYHSy4N7qh/2dXkZlxRteyZNtf5le8xd4IuKcFYoG3cbUC99XbzKQGuqOyfZTdQ5j3QCHfgd3jzXnrDuQXqYq6mm/kkUPI+yAnqPNd5nr9ljrH6PlZH4/6aeqAQpw3DySer/r+FjrFLad3igMzXdHmqs6fZTbZQl5gX6vOsNRycCP8ACtGu3t3aXquYzNhcDGpScwzEAXwIo0nmKbiPEb1S7UeS8S6K06DMP0yWJ4iW3iRGwGE8Q0VPyQrSXMdHOFRsDy6/DZmhjQJuM1zgLOvY+ooV065Mr3WzqxzqQQb70IWZoCEIQAqC6UstOwLH3zMvDpITxMSEQLMf+ZvvUjwPgr9WozdIy0/lvEYU1AZGa2Xe9rXCpDg00I5Fa4r40Z5I5ScB+zzBJxbGoxFmy8NnqXE/ZXzK9w+arrIWXIeWsBgQAyk7Fa2JMvG9z6bq8hWgVhB2w7NNVb13Lqm1TejlqHKRIduKgBSOsVto+UdW/X8K5QJX8ykKP/4/6qrHWD9HygE0KfLW1eifpHIeyRM9ks0237vRAPUIi581ip5lTQBQWCAjy1nuryUHFoFH7cXBFHU4FbCZs0UtfgkHtAh1weBVLnktFori9mkDQ2oA81lSp6X2DwQDocKjwUVcVTxemd0tNbQIQhVJBCEIAWCA4EEAg7wQsp8nAEaI4O7jW1KlJt6RDaS2z1h8Axphp/K25K28z3hxso8JjYQ0wxQee9S5a7TW9+K7cccFo4sl8mRwDUKbVYcBQ2ChBxpvK0KD5m9PIpFPBPl71rfzT6DkEArrDfpPwvLvxyC22nmkJ8r+b0QGOru5hetuBahtZPUA7z5oB7jt+y21L3WOru+oIlu+fJSUBBm2tjQTCLTUbj4rSkFpobELdxO+7zWvxNsNjNsTS4BoufNG1s3xXp6IaEW4IXKdQIQhAFKrcSMMQoGgjtv7xUDDmMiF0StdDqeq2cPvjzXVhj8mc2a/xQzq7vqCy12wGlwqTeykKNM94eS6DnPRjtNqFeBLu5hKG8KegI4/A7168lnrDfpKxNfl9UhATdm36Qkx+wWhlqr3t2ePsvET8YjR+XfWyAVrd9RUoMaeHBR9g/w900R2C16jwQGI/YaNNr0Sdb+abEIiijeFyTZaXE8w4LhVsQxWSgO+h0YFx8mi6EN6N8xrSxpIvRarMLmdT2TabQuBp4LSyXSHguJTww7C4kaLGLTpiOhFrbed0973RHl7zVx3qLltaLRWnyRCgzDodj2m8lMhx4cQWd72UKYh6HFw7pSty82k5ememuNraNm6KxoqXD3UWNNF/ZZUDj4qMmQYZivvuG8ot09INKVtm9y05ggxIbwNZdqAPELcva0MJApS65dtWkFtQRuISsTz7hWDx4Uliz4rYsVmrXDh6gBWgrS4XoxOpSPMyWnTZ0oe76inQBradV6G1VocMzPgOKuDZHF5KJEP+mYoa/8AlNCt7CeITO0d9wRcKz7FU9jSxoG5RNb/AKipBjMI4+yVsH+HuhJ7gdquq/mnbNv0hJZ+DXacd1F727PH2QERPlfzeibsWclzWes0S+UsJ6xRr5qNVsvAr33cz+kVqUXchvRNzNmjCssywjYpMaHO/wC3BYNT4h8B99yqPGulrF5qIW4TLQZKDwdEG0iHz4D2K4bFMRm8Xn4s/iMd0eaintPPAcABwA4BRFuoRhVt+DaYjmPHMTc7r2MT0Vp/Jt3NZ/K2g+Fr4VKGnHelpkLcVcoT8InXYbikpOtNNjFa4/w1v8VV8te17GvYatcKtPML56Vy5BxA4hlmW1nVFl6wX+m74os8q9muJ+joXND2lrtxUB7Sxxa7eFsAlzELW2oFXNXFnx8ls7sGXi9PwQ2gudpG8qdDYGNoEuWhaQHOrU3FRwT1GDHxW2T1GTk+KBUfm3EP3nmOemWu1QxE2cPwa0afsT6q3M0Yj+68AnZtrgIjYZbD/jNh8lUWLWG4bl2417ODK/R5igFlwDfipmH47jGGODpDFJ2ABuYyO7R/KTQ+yhxO4lLUy2d9g/SvjsnEYMRhS8/BFNVW7N9PMW+FbWU854RmiEeoRiyZYKxZaKKPZ/keIsvmdOk5qYkpqFNykZ8GYgu1Q4rDQtKpUJl1kaPq6ZvT1Udc10c5wh5sw58ObDW4lLUEaGLBw4PaOR5cCux2LOSxa0bp7WzDo8NrS5zwABUk8F81Z8zC/MuZJicD6ysM7KVbyYOPqb+3JXF0l4ocKybPvY7TFmB1aGQb1fY09KlfPfC25aY17Msr9AhCFqZAmQtxS1mpG5APXcdFU/scSm5B7uxMQxEYP1N3+4PwuFZWl1PwOeOGYxJzoNBBjNLv4dzvglRS2iZemX0xrnmjBUlV70jZhxSRxB+DwAZWFsw8xmntRQeR4DeOdlakBsNrA6FQtcAQeYKqzpodD/eGGQ2tbtBBeSeNNQoP6rgztqOx7nxUzXUpUtkLo+zFihxSVwd1ZuXjGjdR7UEUqTXl4FWe9j2O0vBBVYdED4bc0RWva0udKu0E8LtrRXG+G2I3S4f5Venbcdy/zEzPUalaKo6WMRpDk8Ma+7jt3t8BUN/u9lXK3mdcQGI5mnorHa4UOJsYZ/Sy39arRusLL0ZWkeBT2zzE7iUslxKwpKghCEJNrljHI+XcclcUl6nZGkVg/wBSGe83/nGi+n5ebgTECHGgxA6HEaHscOINwvktX10SYk/EMmS8OK7VFk4j4BNb6Qat/wDkgeiyyL2a436NL08zDGSmESLXdp0Z8cjnpbpH+8qn13vTVPdazmJdpqyUlWM8nOq4/BauCVoXYpb+4EIQrlQQhCEDxuWd68MdUL0gL66O8T/eeUpJ7naosu3q8Qk3qywr6UKrrpamNrm50MboEtDZ71d9wtl0NYkIWIT2FuIpHZt2A/U2zvgj2XL57mOs5vxR9agRtApyaAPsvP6v7Vo+i+BXLO6/SH9HEwZfOeHcopdCPq0/eiuPNWKDB8uz8/UB0OFSH/GTpb8lUNl+OZXHcOjg02c1CcfLUK/FVY3TNieiUkMLhm8Z5jxKcA2za+ZJ9lXo+6aNPn1xyTX7RVN+JqeJRwWV4eaC29ekfMi3bz5rCEISCEIQArc6Bo7XsxmTdWrXQow9QW/2qo1YfQdNCDm2YgE0EeTcL82uaf8AKrfgtHk5rPkV8XOmMOeanrJb6AAD4C0KEKV4IfkEIQpIBCEIQemHtJqEIDeZIjxJbNuFRIRo7bhp8Q6xHsVAxhxfjGIPddzpqKSf/coQvP6/0fT/AE5/qyI15hnaNs5naHmF03SRMxZjNswIrqiFDhMaOQ0A/wBSUIVeg8st9R+I/pzCS81KEL0j5Y8oQhCQQhCAF1PRnFfCzrIOYblkVp8tDj9ghChkryf/2Q=="}
                  style={{ cursor: "pointer", borderRadius: "50%" }}
                />
              </Box>
              <Box textAlign="center">
                <Typography
                  variant="h2"
                  color={colors.grey[100]}
                  fontWeight="bold"
                  sx={{ m: "10px 0 0 0" }}
                >
                Alphonce walters
                </Typography>
                <Typography variant="h5" color={colors.greenAccent[500]}>
                  VVP ADMIN
                </Typography>
              </Box>
            </Box>
          )}

          <Box paddingLeft={isCollapsed ? undefined : "10%"}>
            <Item
              title="Dashboard"
              to="/"
              icon={<HomeOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />

            <Typography
              variant="h6"
              color={colors.grey[300]}
              sx={{ m: "15px 0 5px 20px" }}
            >
              Data
            </Typography>
            <Item
              title="Manage Team"
              to="/team"
              icon={<PeopleOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="Contacts Information"
              to="/contacts"
              icon={<ContactsOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="Invoices Balances"
              to="/invoices"
              icon={<ReceiptOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />

            <Typography
              variant="h6"
              color={colors.grey[300]}
              sx={{ m: "15px 0 5px 20px" }}
            >
              Pages
            </Typography>
            <Item
              title="Profile Form"
              to="/form"
              icon={<PersonOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="Calendar"
              to="/calendar"
              icon={<CalendarTodayOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="FAQ Page"
              to="/faq"
              icon={<HelpOutlineOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />

            <Typography
              variant="h6"
              color={colors.grey[300]}
              sx={{ m: "15px 0 5px 20px" }}
            >
              Charts
            </Typography>
            <Item
              title="Bar Chart"
              to="/bar"
              icon={<BarChartOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="Pie Chart"
              to="/pie"
              icon={<PieChartOutlineOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="Line Chart"
              to="/line"
              icon={<TimelineOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />
            <Item
              title="Geography Chart"
              to="/geography"
              icon={<MapOutlinedIcon />}
              selected={selected}
              setSelected={setSelected}
            />
          </Box>
        </Menu>
      </ProSidebar>
    </Box>
  );
};

export default Sidebar;
