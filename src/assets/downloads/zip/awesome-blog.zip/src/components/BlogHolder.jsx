import React from "react";
import LikeIcon from "../assets/images/like-icon.png";
import InstragramIcon from "../assets/images/instagram-icon.png";
import FacebookIcon from "../assets/images/fb-icon.png";
import TwitterIcon from "../assets/images/twitter-icon.png";
import LinkedIcon from "../assets/images/linkedin-icon-1.png";

function BlogHolder({ imageUrl }) {
  return (
    <div class="col-lg-8 col-sm-12">
      <div class="about_img">
        <img src={imageUrl} />
      </div>
      <div class="like_icon">
        <img src={LikeIcon} />
      </div>
      <p class="post_text">Post By : 09/06/2019</p>
      <h2 class="most_text">
        Most Awesome Blue Lake With Snow <br />
        Mountain
      </h2>
      <p class="lorem_text">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis
      </p>
      <div class="social_icon_main">
        <div class="social_icon">
          <ul>
            <li>
              <a href="#">
                <img src={FacebookIcon} />
              </a>
            </li>
            <li>
              <a href="#">
                <img src={TwitterIcon} />
              </a>
            </li>
            <li>
              <a href="#">
                <img src={InstragramIcon} />
              </a>
            </li>
          </ul>
        </div>
        <div class="read_bt">
          <a href="#">Read More</a>
        </div>
      </div>
    </div>
  );
}

export default BlogHolder;

export const ConnectFollow = () => {
  return (
    <div class="col-lg-4 col-sm-12">
      <div class="about_main">
        <h1 class="follow_text">CONNECT & FOLLOW</h1>
        <div class="follow_icon">
          <ul>
            <li>
              <a href="#">
                <img src={FacebookIcon} />
              </a>
            </li>
            <li>
              <a href="#">
                <img src={TwitterIcon} />
              </a>
            </li>
            <li>
              <a href="#">
                <img src={LinkedIcon} />
              </a>
            </li>
            <li>
              <a href="#">
                <img src={InstragramIcon} />
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
