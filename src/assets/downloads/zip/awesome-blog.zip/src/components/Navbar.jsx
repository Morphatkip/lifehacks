import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../assets/css/style.css";
function Navbar() {
  const [expanded, setExpanded] = useState(false); // State to track Navbar expansion

  const handleToggle = () => {
    setExpanded(!expanded); // Toggle the expanded state
  };

  return (
    <div className="container-fluid header_main">
      <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
        <Link className="logo" to="/">
          <img
            style={{ height: "40px", width: "auto" }}
            src="https://images.unsplash.com/photo-1623375428145-4d276c83ce5e?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&dl=chase-yi-hO8h5miJ-Yc-unsplash.jpg"
            alt="Logo"
          />
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          onClick={handleToggle} // Added onClick event to toggle the Navbar
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div
          className={`collapse navbar-collapse ${expanded ? "show" : ""}`}
          id="navbarSupportedContent"
        >
          <ul className="navbar-nav mr-auto">
            <li className="nav-item">
              <Link className="nav-link" to="/">
                Home
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="about">
                About
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/blog">
                Blog
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/features">
                Features
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/contact-us">
                Contact Us
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/">
                Login
              </Link>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  );
}

export default Navbar;
