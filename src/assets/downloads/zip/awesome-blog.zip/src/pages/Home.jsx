import React from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { Carousel } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import BlogHolder, { ConnectFollow } from "../components/BlogHolder";
function Home() {
  return (
    <body>
      {/* header section start  */}
      <div class="header_section">
        <Navbar />
        {/* banner section start  */}
        <div class="container-fluid">
          <div class="banner_section layout_padding">
            <h1 class="banner_taital">
              Awesome <br />
              blog
            </h1>
            <Carousel className="container">
              <Carousel.Item>
                <img
                  className="d-block w-100"
                  style={{ height: "800px" }}
                  src="https://images.unsplash.com/photo-1602934445884-da0fa1c9d3b3?q=80&w=958&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
                  alt="First slide"
                />
                <Carousel.Caption>
                  <h3>First slide label</h3>
                  <p>
                    Nulla vitae elit libero, a pharetra augue mollis interdum.
                  </p>
                </Carousel.Caption>
              </Carousel.Item>
              <Carousel.Item>
                <img
                  className="d-block w-100"
                  style={{ height: "800px" }}
                  src="https://images.unsplash.com/photo-1670938904389-5a7b7ac1394d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1yZWxhdGVkfDJ8fHxlbnwwfHx8fHw%3D"
                  alt="Second slide"
                />
                <Carousel.Caption>
                  <h3>Second slide label</h3>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </p>
                </Carousel.Caption>
              </Carousel.Item>
              <Carousel.Item>
                <img
                  className="d-block w-100"
                  style={{ height: "800px" }}
                  src="https://images.unsplash.com/photo-1612367990403-73ef3e67bc4f?q=80&w=870&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
                  alt="Third slide"
                />
                <Carousel.Caption>
                  <h3>Third slide label</h3>
                  <p>
                    Praesent commodo cursus magna, vel scelerisque nisl
                    consectetur.
                  </p>
                </Carousel.Caption>
              </Carousel.Item>
            </Carousel>
          </div>
        </div>
        {/* banner section end  */}
      </div>
      {/* header section end  */}
      <div class="container">
        <div class="touch_setion">
          <div class="box_main">
            <div class="image_2 active">
              <h4 class="who_text active">Who am i</h4>
            </div>
          </div>
          <div class="box_main">
            <div class="image_3">
              <h4 class="who_text">Get In Touch</h4>
            </div>
          </div>
          <div class="box_main">
            <div class="image_4">
              <h4 class="who_text">Facebook</h4>
            </div>
          </div>
        </div>
      </div>
      {/* about section start  */}
      <div class="about_section layout_padding">
        <div class="container">
          <div class="row">
            <BlogHolder imageUrl="https://plus.unsplash.com/premium_photo-1665990293319-fe271ebcb6f3?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8YWJvdXR8ZW58MHx8MHx8fDA%3D" />
            <ConnectFollow />
          </div>
        </div>
      </div>
      {/* about section end  */}
      {/* blog section start  */}
      <div class="about_section layout_padding">
        <div class="container">
          <div class="row">
            <BlogHolder imageUrl="https://images.unsplash.com/photo-1462826303086-329426d1aef5?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fGFib3V0fGVufDB8fDB8fHww" />
            <ConnectFollow />
          </div>
        </div>
      </div>
      {/* blog section end  */}
      {/* newsletter section start  */}
      <div class="about_section layout_padding">
        <div class="container">
          <div class="row">
            <BlogHolder imageUrl="https://images.unsplash.com/photo-1505490096310-204ef067fe6b?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Ymx1ZSUyMGxha2V8ZW58MHx8MHx8fDA%3D" />
            <ConnectFollow />
          </div>
        </div>
      </div>
      {/* newsletter section end  */}
      {/* recent section start  */}
      <div class="about_section layout_padding">
        <div class="container">
          <div class="row">
            <BlogHolder imageUrl="https://images.unsplash.com/photo-1505490096310-204ef067fe6b?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Ymx1ZSUyMGxha2V8ZW58MHx8MHx8fDA%3D" />
            <ConnectFollow />
          </div>
        </div>
      </div>
      {/* recent section end  */}
      {/* tag section start  */}
      <div class="tag_section layout_padding">
        <div class="container">
          <h1 class="tag_taital">Tag</h1>
          <div class="tag_bt">
            <ul>
              <li class="active">
                <a href="#">Ectetur</a>
              </li>
              <li>
                <a href="#">Onsectetur</a>
              </li>
              <li>
                <a href="#">Consectetur</a>
              </li>
              <li>
                <a href="#">Consectetur</a>
              </li>
              <li>
                <a href="#">Consectetur</a>
              </li>
            </ul>
          </div>
          <div class="tag_bt_2">
            <ul>
              <li>
                <a href="#">Tetur</a>
              </li>
              <li>
                <a href="#">Conse</a>
              </li>
              <li>
                <a href="#">Nsectetur</a>
              </li>
              <li>
                <a href="#">Sectetur</a>
              </li>
              <li>
                <a href="#">Consectetur</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      {/* tag section end  */}
      {/* contact section start  */}
      <div class="contact_section layout_padding">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <div
                id="carouselExampleIndicators"
                class="carousel slide"
                data-ride="carousel"
              >
                <ol class="carousel-indicators">
                  <li
                    data-target="#carouselExampleIndicators"
                    data-slide-to="0"
                    class="active"
                    style={{
                      textIndent: 0,
                      border: "none",
                      color: "#000",
                      fontSize: "18px",
                      textAlign: "center",
                    }}
                  >
                    1
                  </li>
                  <li
                    data-target="#carouselExampleIndicators"
                    data-slide-to="1"
                    style={{
                      textIndent: 0,
                      border: "none",
                      color: "#000",
                      fontSize: "18px",
                      textAlign: "center",
                    }}
                  >
                    2
                  </li>
                  <li
                    data-target="#carouselExampleIndicators"
                    data-slide-to="2"
                    style={{
                      textIndent: 0,
                      border: "none",
                      color: "#000",
                      fontSize: "18px",
                      textAlign: "center",
                    }}
                  >
                    3
                  </li>
                  <li
                    data-target="#carouselExampleIndicators"
                    data-slide-to="3"
                    style={{
                      textIndent: 0,
                      border: "none",
                      color: "#000",
                      fontSize: "18px",
                      textAlign: "center",
                    }}
                  >
                    4
                  </li>
                </ol>
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <div class="contact_img"></div>
                  </div>
                  <div class="carousel-item">
                    <div class="contact_img"></div>
                  </div>
                  <div class="carousel-item">
                    <div class="contact_img"></div>
                  </div>
                  <div class="carousel-item">
                    <div class="contact_img"></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="mail_section">
                <h1 class="contact_taital">Contact us</h1>
                <input
                  type=""
                  class="email_text"
                  placeholder="Name"
                  name="Name"
                />
                <input
                  type=""
                  class="email_text"
                  placeholder="Phone"
                  name="Phone"
                />
                <input
                  type=""
                  class="email_text"
                  placeholder="Email"
                  name="Email"
                />
                <textarea
                  class="massage_text"
                  placeholder="Message"
                  rows="5"
                  id="comment"
                  name="Message"
                ></textarea>
                <div class="send_bt">
                  <a href="#">send</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* contact section end  */}

      {/* footer section start  */}

      <Footer />
    </body>
  );
}

export default Home;
