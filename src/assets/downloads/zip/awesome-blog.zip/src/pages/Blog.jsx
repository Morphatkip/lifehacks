import React from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import BlogHolder, { ConnectFollow } from "../components/BlogHolder";

function Blog() {
  return (
    <body>
      {/*  header section start  */}
      <div class="header_section">
        <Navbar />
      </div>
      {/*  blog section start  */}
      <div class="about_section layout_padding">
        <div class="container">
          <div class="row">
            <BlogHolder imageUrl="https://images.unsplash.com/photo-1499092346589-b9b6be3e94b2?q=80&w=871&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" />

            <ConnectFollow />
          </div>
        </div>
      </div>
      {/*  blog section end  */}
      {/*  footer section start  */}
      <Footer />
      {/*  footer section end  */}
    </body>
  );
}

export default Blog;
