import React from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import BlogHolder from "../components/BlogHolder";

function About() {
  return (
    <body>
      {/*   header section start  */}
      <div class="header_section">
        <Navbar />
      </div>
      {/*   about section start  */}
      <div class="about_section layout_padding">
        <div class="container">
          <div class="row">
            <BlogHolder imageUrl="https://images.unsplash.com/photo-1674076956170-87ef62dc27a1?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTh8fHJlY2VudHxlbnwwfHwwfHx8MA%3D%3D" />
            <div class="col-lg-4 col-sm-12">
              <div class="image_5">
                <img src="https://images.unsplash.com/photo-1522083165195-3424ed129620?q=80&w=997&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" />
              </div>
              <h1 class="about_taital">About Us</h1>
              <p class="about_text">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis
              </p>
              <div class="read_bt_1">
                <a href="#">Read More</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/*   about section end  */}
      {/*   footer section start  */}
      <Footer />
      {/*   footer section end  */}
    </body>
  );
}

export default About;
