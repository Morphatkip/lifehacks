import React from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import BlogHolder, { ConnectFollow } from "../components/BlogHolder";

function Features() {
  return (
    <body>
      {/*  header section start  */}
      <div class="header_section">
        <Navbar />
      </div>
      {/*  recent section start  */}
      <div class="about_section layout_padding">
        <div class="container">
          <div class="row">
            <BlogHolder imageUrl="https://images.unsplash.com/photo-1492666673288-3c4b4576ad9a?q=80&w=1032&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" />
            <ConnectFollow />
          </div>
        </div>
      </div>
      {/*  recent section end  */}
      {/*  footer section start  */}
      <Footer />
      {/*  footer section end  */}
    </body>
  );
}

export default Features;
