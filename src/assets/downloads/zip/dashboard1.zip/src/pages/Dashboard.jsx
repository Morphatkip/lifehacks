import React from "react";
import Navbar from "../components/Navbar";

function Dashboard() {
  return (
    <div>
      <Navbar />
    </div>
  );
}

export default Dashboard;
