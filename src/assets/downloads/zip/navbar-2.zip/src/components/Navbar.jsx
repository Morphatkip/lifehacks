import React, { useState } from "react";
import "../assets/styles.css";
import { Link } from "react-router-dom";

function Navbar() {
  const [showMenu, setShowMenu] = useState(false);

  const toggleMenu = () => {
    setShowMenu(!showMenu);
  };

  return (
    <div>
      <nav>
        <input
          type="checkbox"
          id="check"
          checked={showMenu}
          onChange={toggleMenu}
        />
        <label className="checkbtn" onClick={toggleMenu}>
          <i className="bi bi-list"></i>
        </label>
        <label className="logo">Firetipsedu</label>
        <ul className={showMenu ? "show" : ""}>
          <li>
            <Link className="active" to="#">
              Home
            </Link>
          </li>
          <li>
            <Link to="#">About</Link>
          </li>
          <li>
            <Link to="#">Services</Link>
          </li>
          <li>
            <Link to="#">Contact</Link>
          </li>
          <li>
            <Link to="#">Blog</Link>
          </li>
        </ul>
      </nav>
    </div>
  );
}

export default Navbar;
