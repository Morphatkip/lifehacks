const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("electron", {
  loginUser: (email, password) => {
    return ipcRenderer.invoke("login-user", email, password);
  },
  addService: (serviceData) => {
    return ipcRenderer.invoke("add-service", serviceData);
  },
  getAllServices: () => {
    return ipcRenderer.invoke("get-all-services");
  },
  fetchServiceById: (id) => {
    return ipcRenderer.invoke("fetch-service-by-id", id);
  },
  addExpense: (expenseData) => {
    return ipcRenderer.invoke("add-expense", expenseData);
  },
  fetchExpenses: () => {
    return ipcRenderer.invoke("fetch-expenses");
  },
  fetchExpenseById: (id) => {
    return ipcRenderer.invoke("fetch-expense-by-id", id);
  },
  createOrder: (orderData, serviceItems, customerData, paymentData) => {
    return ipcRenderer.invoke(
      "create-order",
      orderData,
      serviceItems,
      customerData,
      paymentData
    );
  },
  fetchOrders: () => {
    return ipcRenderer.invoke("fetch-orders");
  },
  fetchOrderById: (id) => {
    return ipcRenderer.invoke("fetch-order-by-id", id);
  },
  createPayment: (paymentData) => {
    return ipcRenderer.invoke("create-payment", paymentData);
  },
  createUser: (userData) => {
    return ipcRenderer.invoke("create-user", userData);
  },
  createDelivery: (deliveryData) => {
    return ipcRenderer.invoke("create-delivery", deliveryData);
  },
  addReview: (reviewData) => {
    return ipcRenderer.invoke("add-review", reviewData);
  },
  fetchReviews: () => {
    return ipcRenderer.invoke("fetch-reviews");
  },
  fetchReviewById: (id) => {
    return ipcRenderer.invoke("fetch-review-by-id", id);
  },
  createPromotion: (promotionData) => {
    return ipcRenderer.invoke("create-promotion", promotionData);
  },
  fetchPromotions: () => {
    return ipcRenderer.invoke("fetch-promotions");
  },
  fetchPromotionById: (id) => {
    return ipcRenderer.invoke("fetch-promotion-by-id", id);
  },
  deleteService: (id) => {
    return ipcRenderer.invoke("delete-service", id);
  },
  getAllExpenses: () => {
    return ipcRenderer.invoke("get-all-expenses");
  },
  getAllUsers: () => {
    return ipcRenderer.invoke("get-all-users");
  },
  getAllOrders: () => {
    return ipcRenderer.invoke("get-all-orders");
  },
  updatePayment: (orderId, updatedPayment) => {
    return ipcRenderer.invoke("update-payment", orderId, updatedPayment);
  },
  updateService: (serviceId, updatedServiceData) => {
    return ipcRenderer.invoke("update-service", serviceId, updatedServiceData);
  },
  updateUser: (userId, currentPassword, newPassword) => {
    return ipcRenderer.invoke(
      "update-user",
      userId,
      currentPassword,
      newPassword
    );
  },
  updateOrderStatus: (orderId) => {
    return ipcRenderer.invoke("update-order-status", orderId);
  },
  printReceipt: (receiptData) => {
    return ipcRenderer.invoke("print-receipt", receiptData);
  },
  createCompany: (companyData) => {
    return ipcRenderer.invoke("create-company", companyData);
  },
  getCompany: () => {
    return ipcRenderer.invoke("get-company");
  },
});
