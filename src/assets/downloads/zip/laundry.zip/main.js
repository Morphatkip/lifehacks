const { app, BrowserWindow, ipcMain } = require("electron");
const path = require("path");
const {
  loginUser,
  addService,
  addExpense,
  createOrder,
  getAllServices,
  deleteService,
  getAllExpenses,
  getAllUsers,
  getAllOrders,
  updatePayment,
  updateService,
  updateUser,
  createUser,
  updateOrderStatus,
  createCompany,
  getCompany,
} = require("./databaseOperations");

function createWindow() {
  const mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      enableRemoteModule: false,
      nodeIntegration: false,
    },
  });

  mainWindow.loadURL("http://localhost:3000"); // Adjust as needed
}

// Handle login requests
ipcMain.handle("login-user", async (event, email, password) => {
  return await loginUser(email, password);
});

// Handle adding a new service
ipcMain.handle("add-service", async (event, serviceData) => {
  return await addService(serviceData);
});

// Handle adding a new expense
ipcMain.handle("add-expense", async (event, expenseData) => {
  return await addExpense(expenseData);
});

// Handle creating a new order
ipcMain.handle(
  "create-order",
  async (event, orderData, serviceItems, customerData, paymentData) => {
    try {
      // Call the createOrder function with all necessary data
      const order = await createOrder(
        orderData,
        serviceItems,
        customerData,
        paymentData
      );
      return { success: true, order };
    } catch (error) {
      console.error("Error handling create-order:", error);
      return { success: false, message: error.message };
    }
  }
);

// Handle creating a new user
ipcMain.handle("create-user", async (event, userData) => {
  try {
    const user = await createUser(userData);
    return { success: true, user };
  } catch (error) {
    console.error("Error handling create-user:", error);
    return { success: false, message: error.message };
  }
});

//Handle getting all users
ipcMain.handle("get-all-users", async () => {
  try {
    const users = await getAllUsers();
    return users;
  } catch (error) {
    throw new Error("Failed to fetch users");
  }
});

ipcMain.handle("get-all-services", async () => {
  try {
    const services = await getAllServices();
    return services;
  } catch (error) {
    console.error("Failed to fetch services:", error);
    throw new Error("Failed to fetch services");
  }
});
//Handle getting all expenses
ipcMain.handle("get-all-expenses", async () => {
  try {
    const expenses = await getAllExpenses();
    return expenses;
  } catch (error) {
    throw new Error("Failed to fetch expenses");
  }
});

//Handle getting all orders
ipcMain.handle("get-all-orders", async () => {
  try {
    const orders = await getAllOrders();
    return orders;
  } catch (error) {
    throw new Error("Failed to fetch Orders");
  }
});
// Handle deleting a service
ipcMain.handle("delete-service", async (event, id) => {
  try {
    const result = await deleteService(id);
    return result; // Return success or failure message from deleteService
  } catch (error) {
    console.error("Failed to delete service:", error);
    return { success: false, message: "Failed to delete service" };
  }
});

//handle payment editing
ipcMain.handle("update-payment", async (event, orderId, updatedPayment) => {
  try {
    const updatedOrder = await updatePayment(orderId, updatedPayment);
    return { success: true, data: updatedOrder };
  } catch (error) {
    console.error("IPC update payment error:", error);
    return { success: false, message: error.message };
  }
});
// update Service
ipcMain.handle(
  "update-service",
  async (event, serviceId, updatedServiceData) => {
    try {
      const updatedService = await updateService(serviceId, updatedServiceData);
      return updatedService;
    } catch (error) {
      console.error("IPC Update Service Error:", error);
      throw error;
    }
  }
);

//update User

ipcMain.handle(
  "update-user",
  async (event, userId, currentPassword, newPassword) => {
    try {
      const updatedUser = await updateUser(
        userId,
        currentPassword,
        newPassword
      );
      return updatedUser;
    } catch (error) {
      console.error("IPC Update User Error:", error);
      throw error;
    }
  }
);

// Update Order Status
ipcMain.handle("update-order-status", async (event, orderId) => {
  try {
    const updatedOrder = await updateOrderStatus(orderId);
    return updatedOrder;
  } catch (error) {
    console.error("IPC Update Order Status Error:", error);
    throw error;
  }
});
//create company

ipcMain.handle("create-company", async (event, companyData) => {
  try {
    const company = await createCompany(companyData);
    return { success: true, company };
  } catch (error) {
    console.error("Error handling create-company:", error);
    return { success: false, message: error.message };
  }
});

//get company
ipcMain.handle("get-company", async () => {
  try {
    const company = await getCompany();
    return { success: true, company };
  } catch (error) {
    console.error("Error handling get-company:", error);
    return { success: false, message: error.message };
  }
});

// Handle receipt printing
ipcMain.handle("print-receipt", async (event, receiptData) => {
  const printWindow = new BrowserWindow({
    width: 400,
    height: 600,
    show: true, // Keep this true to debug layout
    webPreferences: {
      nodeIntegration: false,
    },
  });

  // Load the HTML receipt
  printWindow.loadURL(
    `data:text/html;charset=utf-8,${encodeURIComponent(
      generateReceiptHTML(receiptData)
    )}`
  );

  printWindow.webContents.once("did-finish-load", () => {
    printWindow.webContents.print(
      {
        silent: false,
        printBackground: true,
        pageSize: { width: 58000, height: 58000 }, // 58mm width, auto height
        margins: { top: 0, bottom: 0, left: 0, right: 0 },
      },
      () => {
        printWindow.close();
      }
    );
  });
});

app.whenReady().then(() => {
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

//Function to generate receipt HTML
function generateReceiptHTML(data) {
  return `
    <html>
    <head>
      <title>Receipt</title>
      <style>
        body { font-family: Arial, sans-serif; text-align: center; }
        h2 { margin-bottom: 5px; }
        .receipt { border: 1px dashed #000; padding: 10px; width: 300px; margin: auto; }
        .total { font-weight: bold; }
        .items-table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        .items-table th, .items-table td { border: 1px solid #000; padding: 5px; text-align: left; }
      </style>
    </head>
    <body>
      <div class="receipt">
        <h2>Receipt</h2>
        <p><strong>Dandt Cleaning Services LTD</strong></p>
        <p><strong>Order ID:</strong> ${data?.id}</p>
        <p><strong>Date:</strong> ${new Date(
          data?.orderDate
        ).toLocaleDateString()}</p>
        <p><strong>Items:</strong></p>
        <table class="items-table">
          <tr>
            <th>Service</th>
            <th>Unit Price (Ksh)</th>
            <th>Quantity</th>
            <th>Total (Ksh)</th>
          </tr>
          ${data.Services.map(
            (item) => `
              <tr>
                <td>${item?.serviceName}</td>
                <td>${item?.price}</td>
                <td>${item?.OrderItem?.quantity}</td>
                <td>${(item?.price * item?.OrderItem?.quantity).toFixed(2)}</td>
              </tr>
              `
          ).join("")}
        </table>
        <p class="total">Total: Ksh ${data?.totalPrice}</p>
        <p>Thank you for your purchase!</p>
      </div>
    </body>
    </html>
  `;
}
