import React from "react";
import "../Styles/Settings/Settings.css";
function Settings({ children }) {
  return (
    <div className="settings-wrapper ">
      <div className="">
        <h4>Account Settings</h4>
      </div>

      <div className="">{children}</div>
    </div>
  );
}

export default Settings;
