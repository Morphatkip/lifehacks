import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import CartBody from "../components/cart/CartBody";
import { getCart, storeCart } from "../Utils/local-storage";
import { showNotification } from "../Utils/notification.util";
import { useUser } from "../Utils/UserContext";

function Cart({ updateCart, spareParts }) {
  const { user } = useUser();
  const [cart, setCart] = useState([]);
  const [products, setProducts] = useState([]);
  const fetchProducts = () => {};

  const navigate = useNavigate();
  useEffect(() => {
    fetchProducts();
    if (!getCart()) {
      navigate("/");
      showNotification("Cart is empty!");
    }
    console.log({ user });
    // eslint-disable-next-line
  }, []);

  const updateCartItems = async (barcode) => {
    if (products) {
      const tempCart = getCart();
      console.log(products);

      const product = await products.find(
        (product) => product.barcode === barcode
      );

      if (tempCart[product.id]) {
        const productDetails = tempCart[product.id];
        tempCart[product.id] = {
          product,
          quantity: productDetails.quantity + 1,
          agreedPrice: product.sellingPrice,
        };
        storeCart(tempCart);
        updateCart();
        setCart(tempCart);
      } else {
        tempCart[product.id] = {
          product,
          quantity: 1,
          agreedPrice: product.sellingPrice,
        };
        storeCart(tempCart);
        updateCart();
        setCart(tempCart);
      }
    }
  };

  useEffect(() => {
    let scannedBarcode = ""; // Variable to accumulate the scanned barcode

    const handleBarcodeScan = (event) => {
      const { key } = event;

      if (key === "Enter") {
        // Barcode complete, process it
        console.log({ barcode: scannedBarcode });

        // Update cart with scanned barcode
        updateCartItems(scannedBarcode);

        // Navigate to cart route
        navigate("/cart");

        // Reset the scannedBarcode for the next scan
        scannedBarcode = "";
      } else {
        // Accumulate the scanned characters into the barcode string
        scannedBarcode += key;
      }
    };

    // Listen for barcode scan events
    document.addEventListener("keydown", handleBarcodeScan);

    return () => {
      // Cleanup event listener on component unmount
      document.removeEventListener("keydown", handleBarcodeScan);
    };
    // eslint-disable-next-line
  }, [navigate, updateCart, products]);

  return (
    <div>
      <CartBody
        updateCart={updateCart}
        spareParts={spareParts}
        cartUpdate={cart}
      />
    </div>
  );
}

export default Cart;
