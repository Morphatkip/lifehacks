import React from "react";
import { useState } from "react";
import { useEffect } from "react";
import { BarChart, LineChart } from "../components/accounting/SalesChart";
import "../assets/css/main.css";
import MainContentContainer from "../components/management/MainContentContainer";
function Accounting() {
  const [salesData, setSalesData] = useState([]);

  const getAllOrders = async () => {
    try {
      const orders = await window.electron.getAllOrders();
      setSalesData(orders);
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    getAllOrders();
    // eslint-disable-next-line
  }, []);

  return (
    <MainContentContainer>
      <main className="main">
        <section className="section">
          <div className="row">
            <div className="col-lg-6">
              <div className="card">
                <h5 className="card-title">Line Chart</h5>
                <LineChart salesData={salesData} />
              </div>
            </div>

            <div className="col-lg-6">
              <div className="card">
                <h5 className="card-title">Bar graph</h5>
                <BarChart salesData={salesData} />
              </div>
            </div>
          </div>
        </section>
      </main>
    </MainContentContainer>
  );
}

export default Accounting;
