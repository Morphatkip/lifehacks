import React from "react";
import { useEffect, useState } from "react";
import AddUser from "../components/Modal/AddUser";
import UseModal from "../components/Modal/UseModal";
import Title from "../components/title/Title";
import MainContentContainer from "../components/management/MainContentContainer";

function UserAccount() {
  const { isShowingAddUser, toggleAddUser } = UseModal();
  /*  const { user } = useUser(); */
  const [users, setUsers] = useState([]);

  const getAllUsers = async () => {
    try {
      const usrs = await window.electron.getAllUsers();
      setUsers(usrs);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getAllUsers();
  }, []);

  const handleSearch = () => {};

  /*   const userActionToggle = (message, condition, user) => {
    showNotification(user.firstName + " " + message, "success");
  }; */
  const handleToggle = (user) => {
    /*  putFunction(`/user/lock/${user.id}`)
      .then((message) => {
        user.accountNonLocked
          ? userActionToggle("locked successfully", false, user)
          : userActionToggle("unlocked successfully", true, user);
      })
      .catch((e) => {
        showNotification(e.message, "");
      }); */
    /*   getBusiness(); */
  };
  return (
    <MainContentContainer>
      <div className="mt-3 h-100">
        <div className="side-container">
          <Title
            handleClick={toggleAddUser}
            btn
            input
            handleSearch={handleSearch}
          />
          <AddUser
            hide={toggleAddUser}
            isShowingAddUser={isShowingAddUser}
            /*  business={business} */
          />
          <div className="card w-100 p-3">
            <div className="card-body table-responsive">
              <table className="table ">
                <thead className="fw-bold ">
                  <tr>
                    <th>Name</th>
                    <th>email</th>
                    <th>Address</th>
                    <th>Phone Number</th>
                  </tr>
                </thead>
                <tbody className="overflow-auto ">
                  {users?.map((user, index) => (
                    <UserAccountFrame
                      key={index}
                      user={user}
                      handleToggle={handleToggle}
                    />
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </MainContentContainer>
  );
}

export default UserAccount;
const UserAccountFrame = ({ user, handleToggle }) => {
  const { name, email, phone_number, address } = user.dataValues; // Destructure properties

  return (
    <tr>
      <td>{name}</td>
      <td>{email}</td>
      <td>{phone_number}</td>
      <td>{address}</td>
      {/*  <td>
        <Switch
          checked={user.accountNonLocked}
          onChange={() => handleToggle(user)}
          onColor="#86d3ff"
          offColor="#dddddd"
          onHandleColor="#2693e6"
          offHandleColor="#ff0000"
          handleDiameter={20}
          uncheckedIcon={false}
          checkedIcon={false}
          height={15}
          width={40}
        />
      </td> */}
    </tr>
  );
};
