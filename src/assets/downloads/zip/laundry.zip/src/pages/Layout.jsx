import React, { useState } from "react";
import { Link, Outlet, useLocation } from "react-router-dom";
import NavbarTop from "../components/Navbar/NavbarTop";
import "../Styles/Layout.css";
import { iconMap, menuItems } from "../constants/dashboard.constants";
import SettingIcon from "../images/icons/setting.png";
import { useUser } from "../Utils/UserContext";
function Layout({ role, cartLength, setBranch, currentUser }) {
  /*  const { business } = currentUser; */
  const [showSideNav, setShowSideNav] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const location = useLocation();
  const { user } = useUser();

  const toggleSettings = (e) => {
    e.preventDefault();
    setIsSettingsOpen(!isSettingsOpen);
  };

  const toggleSideNav = () => {
    setShowSideNav(!showSideNav);
  };

  const settingsLink = (to, iconClass, label) => (
    <Link to={to} className="settings-link">
      <i className={iconClass}></i>
      <span>{label}</span>
    </Link>
  );

  const renderMenuItems = (items) => (
    <>
      {/* Divider */}
      <hr className="sidebar-divider my-0" />

      {items.map((item) => (
        <li
          key={item.label}
          className={`nav-item ${
            location.pathname === item.to ? "active" : ""
          }`}
        >
          <Link className="nav-link" to={item.to}>
            <i className={`fas fa-fw ${iconMap[item.label]}`}></i>
            <span>{item.label}</span>
          </Link>
        </li>
      ))}
    </>
  );

  const renderSettings = () => (
    <></>
    /*  <li>
      <div className="d-flex flex-column">
        <div>
          <span className="nav-link dropdown-toggle" onClick={toggleSettings}>
            <img src={SettingIcon} alt="Settings" />
            Settings
          </span>
        </div>
        {isSettingsOpen && (
          <div>
            {settingsLink("/settings/account", "bi bi-person", "Account")}
            {role !== "USER" &&
              settingsLink(
                "/settings/business-profile",
                "bi bi-tools",
                "Business"
              )}
          </div>
        )}
      </div>
    </li> */
  );

  const getMenu = () => {
    return renderMenuItems(menuItems.GENERAL);
    /*  if (user.dataValues.role == "user") {
      return renderMenuItems(menuItems.USER);
    } else if (menuItems[role]) {
      return (
        <>
          {renderMenuItems(menuItems[role])}
          {renderSettings()}
        </>
      );
    }
    return null; */
  };

  return (
    <div id="wrapper">
      <ul
        className="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion"
        id="accordionSidebar"
      >
        {/*  Sidebar - Brand */}
        <Link
          className="sidebar-brand d-flex align-items-center justify-content-center"
          to="/"
        >
          <div className="sidebar-brand-icon ">
            <i className="fas fa-user"></i>
          </div>
          <div className="sidebar-brand-text mx-3">{currentUser?.role}</div>
        </Link>
        {/*   Divider */}
        <hr className="sidebar-divider my-0" />
        {getMenu()}
      </ul>

      <Outlet />
      {/*  <div className="content-wrapper">
        <div className="main-display">
          <div
            className={`side-navigation ${
              showSideNav
                ? "bg-dark p-4 position-fixed h-100 small-screens"
                : "d-md-block d-none text-dark large-screen"
            }`}
            style={{ width: "200px", zIndex: "800", color: "white" }}
          >
              <button
              type="button"
              className="close text-white d-md-none"
              onClick={toggleSideNav}
            >
              &times;
            </button> 
          </div>

          <div className="d-md-none position-relative top-0 start-0 m-2">
            <button
              className="navbar-toggler"
              type="button"
              onClick={toggleSideNav}
            >
              <i className="bi bi-list"></i>
            </button>
          </div>

          <main className="main-component">
            <Outlet />
          </main>
        </div>
      </div> */}
    </div>
  );
}

export default Layout;
