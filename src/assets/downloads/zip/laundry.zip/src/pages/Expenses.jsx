import React, { useEffect, useState } from "react";
import AddExpenses from "../components/expenses/AddExpenses";
import Title from "../components/title/Title";
import "../Styles/Summary.css";
import UseModal from "../components/Modal/UseModal";
import ExpenseFrame from "../components/DatePicker/ExpenseFrame";
import MainContentContainer from "../components/management/MainContentContainer";
function Expenses() {
  const [expenses, setExpenses] = useState([]);

  const fetchExpenses = async () => {
    try {
      const expenses = await window.electron.getAllExpenses();
      setExpenses(expenses);
    } catch (error) {
      console.error("Failed to fetch expenses:", error);
    }
  };

  useEffect(() => {
    fetchExpenses();
  }, []);

  const { isShowingAddExpense, toggleAddExpenses } = UseModal();
  const handleAddExpenses = () => {
    toggleAddExpenses();
  };
  return (
    <MainContentContainer>
      <div className="mt-3 h-100">
        <div className="side-container">
          <div>
            <Title branch="Expenses " btn handleClick={handleAddExpenses} />
          </div>
          <div className="card w-100 p3">
            {isShowingAddExpense ? (
              <AddExpenses
                hide={toggleAddExpenses}
                updateData={fetchExpenses}
              />
            ) : (
              <div className="container">
                <table className="table table-hover ">
                  <thead className="fw-bold">
                    <tr>
                      <th>Purpose</th>
                      <th>Date</th>
                      <th>Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {expenses.map((expense) => (
                      <ExpenseFrame
                        key={expense.dataValues.id}
                        expense={expense.dataValues}
                      />
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </MainContentContainer>
  );
}

export default Expenses;
