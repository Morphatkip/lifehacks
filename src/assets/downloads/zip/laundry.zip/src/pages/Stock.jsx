import React, { useEffect, useState } from "react";
import "../Styles/Summary.css";
import Title from "../components/title/Title";
import { useUser } from "../Utils/UserContext";
import { showNotification } from "../Utils/notification.util";

function Stock({ branch, spareParts, updateData, updateCart }) {
  const [searchField, setSearchField] = useState("");
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [stock, setStock] = useState([]);
  const { user } = useUser();

  const fetchProducts = () => {};

  useEffect(() => {
    fetchProducts();
    // eslint-disable-next-line
  }, []);

  useEffect(() => {
    let tempFilterdData = [];
    if (searchField) {
      tempFilterdData = stock.filter((prdt) => {
        return (
          prdt?.displayName?.toLowerCase().indexOf(searchField.toLowerCase()) >=
          0
        );
      });
      setFilteredProducts(tempFilterdData);
    } else {
      setFilteredProducts(stock);
    }
  }, [searchField, stock]);

  const handleSearch = (searchvalue) => {
    setSearchField(searchvalue);
  };

  return (
    <div className="mt-3 h-100 container">
      <div className="side-container">
        <div className="">
          <Title branch={branch} input handleSearch={handleSearch} />
        </div>

        <div className="card p-3">
          <div className="card-body table-responsive">
            <table className="table   ">
              <thead className=" fw-bold">
                <tr>
                  <th>Batch Number</th>
                  <th>Entry Date</th>
                  <th>Expiry date</th>
                </tr>
              </thead>
              <tbody className="overflow-auto table-hover">
                {stock?.map((product, index) => (
                  <Frame
                    key={product.id}
                    product={product}
                    index={index}
                    updateCart={updateCart}
                  />
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

const Frame = ({ product, index, updateCart: refresh }) => {
  return (
    <tr
      className={
        product.expired
          ? "table-danger"
          : product.nearExpiration
          ? "table-warning"
          : ""
      }
    >
      <td>{product.batchNumber}</td>
      <td>{product.stockEntryDate}</td>
      <td>{product.stockExpireDate}</td>
    </tr>
  );
};
export default Stock;
