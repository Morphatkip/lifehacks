import React, { useEffect, useState } from "react";
import CartFrame from "../components/cart/CartFrame";
import PaymentModal from "../components/Modal/PaymentModal";
import { useNavigate } from "react-router-dom";
import UseModal from "../components/Modal/UseModal";
import { showNotification } from "../Utils/notification.util";
function Sales() {
  const [services, setServices] = useState([]);
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredServices, setFilteredServices] = useState([]);
  const [isInvoice, setisInvoice] = useState(false);
  const { togglePayment, isShowingPayment } = UseModal();
  const [orderData, setOrderData] = useState({
    totalPrice: 0,
    status: "Pending",
    customerId: "",
  });
  const [customers, setCustomers] = useState([]);
  const [customer, setCustomer] = useState({
    name: "",
    phoneNumber: "",
    address: "",
  });
  const [serviceItems, setServiceItems] = useState([]);
  const [amountPaid, setAmountPaid] = useState(0);
  const handleCustomerChange = (e) => {
    const { name, value } = e.target;

    setCustomer((prevCustomer) => ({
      ...prevCustomer,
      [name]: value,
    }));
  };

  const fetchCustomers = async () => {
    try {
      const users = await window.electron.getAllUsers();
      const customers = users.filter(
        (user) => user.dataValues.role === "customer"
      );
      setCustomers(customers);
    } catch (error) {
      console.log(error);
    }
  };

  const fetchServices = async () => {
    try {
      const services = await window.electron.getAllServices();
      setServices(services);
    } catch (error) {
      console.error("Failed to fetch services:", error);
    }
  };

  useEffect(() => {
    fetchServices();
    fetchCustomers();
  }, []);

  useEffect(() => {
    // Filter the products array based on the search query
    let tempFilterdData = [];
    if (searchQuery) {
      tempFilterdData = services.filter((srvc) => {
        return (
          srvc?.dataValues.serviceName
            ?.toLowerCase()
            .indexOf(searchQuery.toLowerCase()) >= 0
        );
      });
      setFilteredServices(tempFilterdData);
    } else {
      setFilteredServices(services);
    }
  }, [searchQuery, services]);

  const handleBack = () => {
    navigate("/");
  };

  const handleAddToCart = (serviceId, price, name) => {
    // Define the quantity (you can adjust how the quantity is handled)
    const quantity = 1; // defaulting to 1 for example

    // Create a new service item
    const newServiceItem = {
      serviceId,
      quantity,
      price,
      name,
    };

    // Add the new service item to the array of service items
    setServiceItems((prevItems) => {
      // Check if the service already exists in the cart
      const existingItem = prevItems.find(
        (item) => item.serviceId === serviceId
      );

      if (existingItem) {
        // If it exists, update the quantity
        return prevItems.map((item) =>
          item.serviceId === serviceId
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        // If it's a new service, add it to the cart
        return [...prevItems, newServiceItem];
      }
    });
    setSearchQuery("");
  };

  // Function to change the quantity of a service item
  const changeQuantity = (index, newQuantity) => {
    setServiceItems((prevItems) =>
      prevItems.map((item, i) => {
        if (i === index) {
          // Set the new quantity directly from input
          return { ...item, quantity: newQuantity };
        }
        return item;
      })
    );
  };

  const handleRemove = (index) => {
    setServiceItems((prevItems) => prevItems.filter((item, i) => i !== index));
  };

  useEffect(() => {
    const total = serviceItems.reduce((sum, serviceItem) => {
      return sum + parseFloat(serviceItem.quantity) * serviceItem.price; // Assuming serviceItem has price and quantity
    }, 0);

    setOrderData((prevOrderData) => ({
      ...prevOrderData,
      totalPrice: total,
    }));
  }, [serviceItems]);

  const handleClose = () => {
    togglePayment();
    setisInvoice(false);
  };

  const handlePayment = (e) => {
    e.preventDefault();
    togglePayment();
  };

  const handleGenerateInvoice = async (e) => {
    e.preventDefault();

    const { phoneNumber, ...rest } = customer;
    const customerData = {
      ...rest,
      phone_number: phoneNumber,
      role: "customer",
    };

    try {
      // Validate customer data
      if (!customer.name || !customer.phoneNumber) {
        alert("Please provide valid customer details.");
        return;
      }

      // Validate service items
      if (serviceItems.length === 0) {
        alert("No service items added to the order.");
        return;
      }

      // Prepare data
      // Prepare data
      let paymentData = {
        amount: amountPaid,
        paymentMethod: "Cash",
        paymentStatus: amountPaid < orderData.totalPrice ? "Pending" : "Paid",
      };

      // Ensure customerData and other details are valid
      if (!customerData || !customerData.phone_number) {
        throw new Error("Invalid customer data: Missing phoneNumber");
      }

      // Call the backend function
      const response = await window.electron.createOrder(
        {
          ...orderData,
          status: "Pending",
        },
        serviceItems,
        customerData, // Pass customer data to backend
        paymentData
      );

      // Handle response
      if (response.success) {
        alert("Order created successfully!");
        setOrderData({ totalPrice: 0, status: "Pending", customerId: "" });
        setServiceItems([]);
        setCustomer({ name: "", phoneNumber: "", address: "" });
      } else {
        console.log(response);
        /*  alert(`Failed to create order: ${response.message}`); */
      }
    } catch (error) {
      console.error("Error creating order:", error);
    }
    setisInvoice(true);
  };

  const handleCreateOrder = async () => {
    const { phoneNumber, ...rest } = customer;
    const customerData = {
      ...rest,
      phone_number: phoneNumber,
      role: "customer",
    };

    try {
      // Validate customer data
      if (!customer.name || !customer.phoneNumber) {
        alert("Please provide valid customer details.");
        return;
      }

      // Validate service items
      if (serviceItems.length === 0) {
        alert("No service items added to the order.");
        return;
      }

      // Prepare data
      // Prepare data
      let paymentData = {
        amount: amountPaid,
        paymentMethod: "Cash",
        paymentStatus: amountPaid < orderData.totalPrice ? "Pending" : "Paid",
      };

      // Ensure customerData and other details are valid
      if (!customerData || !customerData.phone_number) {
        throw new Error("Invalid customer data: Missing phoneNumber");
      }

      // Call the backend function
      console.log({ customerData });
      const response = await window.electron.createOrder(
        {
          ...orderData,
          status: "Completed",
        },
        serviceItems,
        customerData, // Pass customer data to backend
        paymentData
      );
      // Handle response
      if (response.success) {
        showNotification("Order created succesfully", "success");
        setOrderData({ totalPrice: 0, status: "Pending", customerId: "" });
        setServiceItems([]);
        handlePrintReceipt(response.order);
        setCustomer({ name: "", phoneNumber: "", address: "" });
        setAmountPaid(0);
      } else {
        console.log(response);
        /*  alert(`Failed to create order: ${response.message}`); */
      }
    } catch (error) {
      console.error("Error creating order:", error);
    }
  };

  const handleCancelSale = (e) => {
    e.preventDefault();
    setServiceItems([]);
  };

  const handlePrintReceipt = (receiptData) => {
    window.electron.printReceipt(receiptData);
  };
  return (
    <div className="bg-light" style={{ height: "100vh" }}>
      <div className="d-flex">
        <div style={{ flex: 2 }} className="m-1 ">
          <div className="border p-3 mb-2 bg-white">
            <div>
              <div className="d-flex justify-content-between">
                <input
                  className="form-control w-50"
                  placeholder="Search product"
                  onChange={(e) => setSearchQuery(e.target.value)}
                  value={searchQuery}
                />
                {searchQuery && filteredServices.length > 0 && (
                  <div className="supplier-list-container ">
                    <table className="">
                      <tbody>
                        {filteredServices.map((service) => (
                          <tr
                            onClick={() =>
                              handleAddToCart(
                                service.dataValues.id,
                                service.dataValues.price,
                                service.dataValues.name
                              )
                            }
                            key={service.dataValues.id}
                            className="product-list-item d-flex "
                          >
                            <td className="product-data">
                              {service.dataValues.id}
                            </td>
                            <td className="product-data">
                              {service.dataValues.serviceName}
                            </td>
                            <td className="product-data">
                              {"Ksh"} {service.dataValues.price}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
                <button
                  className="btn btn-danger ml-3"
                  onClick={handleCancelSale}
                >
                  Cancel Sale
                </button>
                <button className="btn btn-light" onClick={handleBack}>
                  Back
                </button>
              </div>
            </div>
          </div>

          <div className="border p-3 bg-white" style={{ height: "70%" }}>
            <table className="table overflow-auto">
              <thead className="bg-muted fw-bold ">
                <tr>
                  <th> Item</th>
                  <th>Quantity</th>
                  <th>Price</th>
                  <th>Subtotal</th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tbody className="overflow-auto">
                {serviceItems?.map((serviceItem, index) => {
                  const serviceDetails = services.find(
                    (service) => service.dataValues.id === serviceItem.serviceId
                  );

                  // If serviceDetails exist, render the cart frame
                  return serviceDetails ? (
                    <CartFrame
                      serviceItem={{ ...serviceItem, ...serviceDetails }} // Pass the combined serviceItem and service details
                      key={index}
                      index={index}
                      handleRemove={() => handleRemove(index)}
                      changeQuantity={(newQuantity) =>
                        changeQuantity(index, newQuantity)
                      }
                      /* handleRemove={handleRemove}
      selectedRow={selectedRow}
      setSelectedRow={handleSelected}
      reduceQuantity={reduceQuantity}
      increaseQuantity={increaseQuantity}
      togggleShowCartItems={togggleShowCartItems}  */
                    />
                  ) : null; // In case the service details are not found, render nothing
                })}
              </tbody>
            </table>
          </div>
          <div className="mt-4">
            <div className="d-flex">
              <div style={{ flex: 2 }}></div>
            </div>
          </div>
        </div>
        <div style={{ flex: 1 }} className="m-1 bg-white">
          {" "}
          <div className="border p-3 mb-4">
            <div className="row">
              <div className="col-6"></div>
            </div>
            <div className="d-flex justify-content-between ">
              <div>Subtotal</div>
              <div>Ksh {orderData.totalPrice}</div>
            </div>
            <hr className="hr" />
            <div className="d-flex justify-content-between line-separator">
              <div>Discount</div>
              <div> Ksh {/* {discount?.toLocaleString()} */}</div>
            </div>
            <hr className="hr" />
            <div className="d-flex justify-content-between line-separator">
              <div className="text-danger">Total</div>
              <div>Ksh {orderData.totalPrice}</div>
            </div>
            <hr className="hr" />
            <div className="d-flex ">
              <div style={{ flex: 1 }} className="border p-2">
                Paid <br /> {amountPaid}
              </div>
              <div style={{ flex: 1 }} className="border p-2">
                Change <br />{" "}
                <span className="text-danger">
                  {" "}
                  {amountPaid > orderData.totalPrice
                    ? (amountPaid - orderData.totalPrice)?.toLocaleString()
                    : ""}{" "}
                </span>
              </div>
            </div>
            <hr className="hr" />

            <div className=" d-flex justify-content-between mt-4 ">
              <button className="btn btn-primary" onClick={handlePayment}>
                Payment
              </button>

              <button
                className="btn btn-danger"
                onClick={handleCreateOrder}
                /*    disabled={isWaiting}  */
              >
                End
              </button>
            </div>
            <div className=" d-flex justify-content-between mt-4 ">
              <button onClick={handleGenerateInvoice} className="btn btn-light">
                Generate Invoice
              </button>
            </div>

            <PaymentModal
              togglePayment={handleClose}
              isShowingPayment={isShowingPayment}
              handleCustomerChange={handleCustomerChange}
              customer={customer}
              isInvoice={isInvoice}
              customers={customers}
              setCustomer={setCustomer}
              setOrderData={setOrderData}
              setAmountPaid={setAmountPaid}

              /*   total={total - discount}
              change={amountPaid > total ? amountPaid - total : ""}
              setDiscount={setDiscount}
             
             
            
              */
            />
          </div>
        </div>
      </div>
    </div>
  );
}

/* const Frame = ({ product, index, updateCart: refresh }) => {
  const [cart, setCart] = useState([]);

  const [stockQuantity, setStockQuantity] = useState(0);

  const handleAddToCart = () => {
    const tempCart = getCart();

    

    if (tempCart[product.id]) {
      showNotification("Item already Exist in the Cart", "", "");
    } else {
      tempCart[product.id] = {
        product,
        quantity: 1,
        agreedPrice: product.sellingPrice,
      };
      storeCart(tempCart);
      setCart({ ...tempCart });
    }
    refresh();
  };

  useEffect(() => {
    setCart(getCart());
    getProductQuantity();
    // eslint-disable-next-line
  }, []);

  const getProductQuantity = () => {
    getFunction(`/products/stocks/${product.id}`)
      .then((qnty) => {
        setStockQuantity(qnty);
      })
      .catch((error) => {});
  };

  const removeFromCart = () => {
    const tempCart = getCart();
    delete tempCart[product.id];
    storeCart(tempCart);
    setCart({ ...tempCart });
    refresh();
  };

  return (
    <tr>
      <td>{product.displayName}</td>
      <td>{product.weight}</td>
      <td>{product.sellingPrice}</td>
    </tr>
  );
}; */
export default Sales;
