import React from "react";
import DatePicker from "../components/DatePicker/DatePicker";
import MainContentContainer from "../components/management/MainContentContainer";

function Summary() {
  return (
    <MainContentContainer>
      <div className="h-100">
        <div className="h-100">
          <DatePicker />
        </div>
      </div>
    </MainContentContainer>
  );
}

export default Summary;
