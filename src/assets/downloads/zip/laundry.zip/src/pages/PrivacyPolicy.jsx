import React from "react";

const PrivacyPolicy = () => {
  return (
    <div className="m-3 p-3">
      <h1>Green Zone Angle Ltd Privacy Policy (Vinsate POS)</h1>
      <p>
        <strong>Privacy Policy for Vinsate</strong>
      </p>
      <p>
        <strong>Effective Date:</strong> 18th March, 2024
      </p>
      <p>
        Vinsate Point of Sale system (“Vinsate POS”) will be used to manage
        payments for goods and services and other customer interactions. This
        “Privacy Policy” explains how we collect, use, disclose, and otherwise
        process our customers’ personal information in the context of the
        Vinsate POS. This Privacy Policy does not apply to Company’s privacy
        practices in any other context.
      </p>

      <h2>Information We Collect</h2>
      <h3>Information that we collect when you make a payment</h3>
      <p>
        When you make a payment via a Vinsate POS, we collect information about
        the transaction, which may include personal data. Information about
        transactions includes the payment card used, name associated with the
        payment card, the fact that the purchase happened at your store and the
        location of your store, date and time of the transaction, transaction
        amount, and information about the goods or services purchased in the
        transaction.
      </p>

      <h3>Additional information you provide through the Vinsate POS</h3>
      <p>
        We may collect additional information ancillary to the payment. This
        information may include:
      </p>
      <ul>
        <li>
          Your email address or phone number, such as if you choose to receive
          an electronic receipt
        </li>
        <li>
          Your marketing preferences, such as whether you wish to receive
          marketing communications or newsletters
        </li>
        <li>
          Information about your participation in a merchant’s loyalty program,
          if you choose to participate
        </li>
        <li>
          Other information you provide, such as your birthdate, interests or
          preferences, reviews, and feedback
        </li>
      </ul>

      <h3>
        Information that we input into the Vinsate POS about our customers
      </h3>
      <p>
        We may input additional information that we have collected about you
        into the Vinsate POS. This information may include email address, phone
        numbers, and purchase history.
      </p>

      <h3>Information that we collect about your personnel</h3>
      <p>
        We may collect information about your personnel and interactions with
        the Vinsate POS, such as clock-in and clock-out time and tips earned.
      </p>

      <h2>How We Use the Information We Collect</h2>
      <h3>Providing our products and services</h3>
      <p>
        We use the information we collect to provide our products and services.
        This may include:
      </p>
      <ul>
        <li>
          Fulfilling a payment or return transaction initiated by your
          customers.
        </li>
        <li>
          Delivering an electronic receipt via email or text message, if your
          customers request it
        </li>
        {/* Include other points here */}
      </ul>

      <h3>Marketing</h3>
      <p>
        We may present opportunities at the Vinsate POS to provide your personal
        data for your own marketing purposes, and we will send such marketing
        communications to your customers if they agree to receive them.
        Likewise, Vinsate may present opportunities to provide your customers’
        personal data for your marketing purposes.
      </p>

      {/* Include other sections here */}

      <h2>How We Share Information</h2>
      <h3>The Vinsate POS is operated by Green Zone Angle Ltd.</h3>
      <p>
        Vinsate uses the information to provide its services to us and as
        otherwise disclosed in its Privacy Notice.
      </p>

      <h3>Service providers</h3>
      <p>
        We may employ third party companies and individuals to administer and
        provide services on our behalf (such as companies that provide customer
        support and order fulfilment and delivery services).
      </p>

      {/* Include other sections here */}

      <h2>Data Retention</h2>
      <p>Company retains personal information for as long as necessary to:</p>
      <ul>
        <li>Provide our products and services</li>
        <li>Comply with legal obligations</li>
        {/* Include other points here */}
      </ul>
      <p>
        You may contact us via the contact us details provided below for
        additional information about our data retention practices in connection
        with the Service.
      </p>
    </div>
  );
};

export default PrivacyPolicy;
