import React from "react";
import AddSpareParts from "../components/AddSpareParts";

function Add() {
  return (
    <div>
      <AddSpareParts />
    </div>
  );
}

export default Add;
