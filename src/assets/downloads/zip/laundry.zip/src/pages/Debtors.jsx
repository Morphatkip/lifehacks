import React from "react";
import CreditorsBody from "../components/creditors/CreditorsBody";
import MainContentContainer from "../components/management/MainContentContainer";

function Debtors() {
  return (
    <MainContentContainer>
      <div className="h-100">
        <CreditorsBody />
      </div>
    </MainContentContainer>
  );
}

export default Debtors;
