import { useState } from "react";
import { postFunction } from "../../server/ApiService";
import { useUser } from "../../Utils/UserContext";

function ConfirmEmail() {
  const [confirmationStatus, setConfirmationStatus] = useState("");
  const { user } = useUser();

  const handleResendConfirmation = () => {
    const email = user.email;

    postFunction(`/resendConfirmation?email=${email}`, {})
      .then((response) => {
        setConfirmationStatus("Confirmation email has been resent.");

        postFunction(`/logout`)
          .then((message) => {
            //     window.location.reload();
          })
          .catch(() => {
            // window.location.reload();
          });
        // window.location.reload();
      })
      .catch((error) => {
        setConfirmationStatus("Error resending confirmation email.");
      });
  };

  const handlegoToHome = (e) => {
    e.preventDefault();
    localStorage.setItem("user", null);
    window.location.reload();
  };
  return (
    <div
      className="container d-flex justify-content-center align-items-center"
      style={{ height: "100vh" }}
    >
      <div className="bg-light p-4" style={{ borderRadius: "25px" }}>
        <h1>Email Address not Confirmed</h1>

        <p>{confirmationStatus}</p>
        <button onClick={handleResendConfirmation}>
          Resend Confirmation Email
        </button>
        <button className="btn btn-light" onClick={handlegoToHome}>
          Home
        </button>
      </div>
    </div>
  );
}

export default ConfirmEmail;
