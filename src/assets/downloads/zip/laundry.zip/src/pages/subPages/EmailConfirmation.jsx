import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const EmailConfirmation = () => {
  const { token } = useParams();
  const [confirmationStatus, setConfirmationStatus] = useState("");

  useEffect(() => {
    // Call the sendConfirmationEmail API service function to confirm the email with the provided token
    // eslint-disable-next-line
  }, [token]);

  return (
    <div
      className="container d-flex justify-content-center align-items-center"
      style={{ height: "100vh" }}
    >
      <div className="bg-light p-4" style={{ borderRadius: "25px" }}>
        <h1>Email Confirmation</h1>
        <p>{confirmationStatus}</p>
      </div>
    </div>
  );
};

export default EmailConfirmation;
