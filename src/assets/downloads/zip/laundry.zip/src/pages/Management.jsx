import React, { useEffect, useState } from "react";
import "../Styles/Summary.css";
import UseModal from "../components/Modal/UseModal";
import DeleteModal from "../components/Modal/DeleteModal";
import Title from "../components/title/Title";
import EditModal from "../components/Modal/EditModal";
import Modal from "../components/Modal/Modal";
import Product from "../components/Products/Product";
import MainContentContainer from "../components/management/MainContentContainer";

function Management() {
  const [searchField, setSearchField] = useState("");
  const [filteredProducts, setFilteredProducts] = useState([]);
  const { isShowingAdd, toggleAdd } = UseModal();
  const [products, setProducts] = useState([]);
  const [isShowingProductClicked, setIsShowingProductClicked] = useState(false);
  const [productClicked, setProductClicked] = useState();
  const [stockQuantity, setStockQuantity] = useState(0);

  const fetchServices = async () => {
    try {
      const services = await window.electron.getAllServices();
      setProducts(services);
    } catch (error) {
      console.error("Failed to fetch services:", error);
    }
  };

  useEffect(() => {
    fetchServices();
  }, []);
  useEffect(() => {
    let tempFilterdData = [];
    if (searchField) {
      tempFilterdData = products.filter((prdt) => {
        return (
          prdt?.dataValues.serviceName
            ?.toLowerCase()
            .indexOf(searchField.toLowerCase()) >= 0
        );
      });
      setFilteredProducts(tempFilterdData);
    } else {
      setFilteredProducts(products);
    }
  }, [searchField, products]);

  const handleSearch = (searchvalue) => {
    setSearchField(searchvalue);
  };

  const toggleIsShowingProductClicked = (product, stockQuantity) => {
    setIsShowingProductClicked(!isShowingProductClicked);
    setProductClicked(product);
    setStockQuantity(stockQuantity);
  };

  return (
    <MainContentContainer>
      {isShowingProductClicked ? (
        <Product
          management
          hide={toggleIsShowingProductClicked}
          product={productClicked}
          stockQuantity={stockQuantity}
          fetchProducts={fetchServices}
        />
      ) : (
        <div className="mt-3 h-100">
          <div className="side-container">
            <Title
              handleClick={toggleAdd}
              btn
              input
              handleSearch={handleSearch}
            />

            <Modal
              isShowingAdd={isShowingAdd}
              hide={toggleAdd}
              updateData={fetchServices}
            />

            <div className="card table-responsive-sm w-100 p-3">
              <table className="table  ">
                <thead className="fw-bold ">
                  <tr>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Created At</th>
                    <th> Action</th>
                  </tr>
                </thead>
                <tbody className="table-hover">
                  {filteredProducts?.map((product, index) => (
                    <Frame
                      product={product}
                      key={product.id}
                      index={index}
                      toggleIsShowingProductClicked={
                        toggleIsShowingProductClicked
                      }
                      fetchProducts={fetchServices}
                    />
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </MainContentContainer>
  );
}

const Frame = ({ product, toggleIsShowingProductClicked, fetchProducts }) => {
  const { isShowingEdit, toggleEdit, isShowingDelete, toggleDelete } =
    UseModal();

  const formattedDate = product?.dataValues.createdAt.toLocaleDateString(
    "en-US",
    {
      weekday: "short",
      year: "numeric",
      month: "short",
      day: "numeric",
    }
  );

  return (
    <tr>
      <td onClick={() => toggleIsShowingProductClicked(product)}>
        {product?.dataValues.serviceName}
      </td>
      <td onClick={() => toggleIsShowingProductClicked(product)}>
        {product?.dataValues.price}
      </td>
      <td>{formattedDate}</td>

      <td>
        {isShowingEdit ? <EditModal hide={toggleEdit} product={product} /> : ""}
        <button
          onClick={() => {
            toggleDelete(product.id);
          }}
          className="btn btn-outline-danger"
        >
          <i className="bi bi-trash" />
        </button>
        <DeleteModal
          isShowingDelete={isShowingDelete}
          hide={toggleDelete}
          id={product.dataValues.id}
          fetchProducts={fetchProducts}
        />
      </td>
    </tr>
  );
};

export default Management;
