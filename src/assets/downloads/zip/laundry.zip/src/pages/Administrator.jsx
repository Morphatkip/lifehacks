import React, { useState } from "react";
import { useEffect } from "react";
import ManagementFrame from "../components/management/ManagementFrame";
import User from "../components/management/User";
import UseModal from "../components/Modal/UseModal";
import MainContentContainer from "../components/management/MainContentContainer";

function Administrator() {
  const [businesses, setBusinesses] = useState([]);
  const [clickedUser, setClickedUser] = useState();
  const [isShowingUser, setIsShowingUser] = useState(false);
  const [isAddingPaymentPeriod, setIsAddingPaymentPeriod] = useState(false);
  const { toggleAddPayment, isShowingAddPayment } = UseModal();

  const getBusinesses = () => {};

  const handleSwitchToggle = () => {
    toggleAddPayment();
    console.log(isShowingAddPayment);
    setIsAddingPaymentPeriod(!isAddingPaymentPeriod);
  };
  useEffect(() => {
    getBusinesses();
  }, []);

  const handleShowUser = (business) => {
    setClickedUser(business);
    setIsShowingUser(!isShowingUser);
  };
  return (
    <MainContentContainer>
      <>
        {isShowingUser ? (
          <User
            user={clickedUser}
            handleShowUser={handleShowUser}
            handleSwitchToggle={handleSwitchToggle}
            isShowingAddPayment={isShowingAddPayment}
            hide={toggleAddPayment}
          />
        ) : (
          <div className="container">
            <table className="table table-hover">
              <thead className="fw-bold">
                <tr>
                  <td>Business Name</td>
                  <td>Telephone</td>
                  <td>Package</td>
                  <td>Status</td>
                  <td>Expiry Date</td>
                  <td>Action</td>
                </tr>
              </thead>
              <tbody>
                {businesses.map((user) => (
                  <ManagementFrame
                    key={user.id}
                    user={user}
                    handleShowUser={handleShowUser}
                  />
                ))}
              </tbody>
            </table>
          </div>
        )}
      </>
    </MainContentContainer>
  );
}

export default Administrator;
