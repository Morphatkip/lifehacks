import React from "react";

function emailSent() {
  return (
    <div className="main">
      <div className="card col-12 col-lg-3 d-flex flex-column justify-content-center  card-container ">
        <div className="card-body p-3">
          <div className="text-center my-3 fw-bold">Email sent succesfully</div>
        </div>
      </div>
    </div>
  );
}

export default emailSent;
