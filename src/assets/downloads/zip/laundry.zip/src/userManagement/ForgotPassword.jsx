import React, { useState } from "react";

function ForgotPassword() {
  const [email, setEmail] = useState({ email: "" });
  const [responseSent, setResponseSent] = useState(false);
  const [message, setMessage] = useState();
  const [positiveResponse, setPositiveResponse] = useState();

  const handleSubmit = (e) => {
    e.preventDefault();
  };

  const handleChange = (e) => {
    const { value } = e.target;
    setEmail({ email: value });
  };
  return (
    <div className="main">
      <div className="card col-12 col-lg-3 d-flex flex-column justify-content-center  card-container ">
        <div className="card-body p-3">
          <div className="text-center my-3 fw-bold">
            Enter email for password reset
          </div>

          <form onSubmit={handleSubmit} name="" className="form-group">
            {message && (
              <div className="col-12 my-3">
                <div
                  className={positiveResponse ? "text-success" : "text-danger"}
                >
                  {message}
                </div>
              </div>
            )}
            <div className="col-12 my-3">
              <input
                className="form-control"
                type="email"
                //value={email}
                required
                placeholder="Enter your email"
                onChange={handleChange}
              />
            </div>

            <button className="btn btn-primary text-white w-100 ">
              Submit
            </button>
            <div className="mt-2"></div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default ForgotPassword;
