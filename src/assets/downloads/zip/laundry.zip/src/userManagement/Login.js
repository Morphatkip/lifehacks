import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../Styles/Modal.css";
import { showNotification } from "../Utils/notification.util";
import "./login.css";
import { useUser } from "../Utils/UserContext";

function Login({ setUserExist }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
  const { setUser } = useUser();

  const handleLogin = async (e) => {
    e.preventDefault();

    if (window.electron && window.electron.loginUser) {
      try {
        const user = await window.electron.loginUser(email, password);
        if (user.success) {
          showNotification("Login successful", "success");
          setUser(user.user);
          setUserExist(true);

          navigate("/");
        } else {
          showNotification("Invalid username or password");
        }
      } catch (error) {
        console.error("Login error:", error);
        showNotification("An error occurred during login");
      }
    } else {
      console.error("Electron loginUser method is not defined.");
    }
  };

  return (
    <div className="login">
      <div className="card col-12 col-lg-3 d-flex flex-column justify-content-center  card-container ">
        <div className="card-body p-3">
          <div className="text-center my-3 fw-bold">Vinsate</div>
          <form onSubmit={handleLogin} className="form-group">
            <div className="col-12 my-3">
              <input
                className="form-control"
                type="text"
                value={email}
                required
                placeholder="Enter your email"
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="username"
              />
            </div>
            <div className="col-12 my-3 password-input ">
              <input
                className="form-control "
                type={showPassword ? "text" : "password"}
                value={password}
                required
                placeholder="Enter your password"
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="new-password"
              />
              <span className="password-toggle">
                <i
                  className="bi bi-eye mr-3"
                  onClick={() => setShowPassword(!showPassword)}
                />
              </span>
            </div>
            <button className="btn btn-primary text-white w-100 ">
              Log in
            </button>
            <div className="mt-2">
              {" "}
              <Link to="/forgot-password"> Forgot password ? </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
