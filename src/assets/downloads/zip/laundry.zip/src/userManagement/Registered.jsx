import React from "react";
import { Link } from "react-router-dom";

function Registered({ savedUser }) {
  return (
    <div className="container">
      {console.log({ savedUser })}
      <div className="row" style={{ height: "100vh" }}>
        <div className="col-md-8 mx-auto border d-flex justify-content-center align-items-center">
          <div>
            <div>Successfully registered</div>
            <div>Your username is {savedUser.data.username}</div>
            <Link to="/login ">Login</Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Registered;
