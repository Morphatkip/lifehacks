import React from "react";
import { useEffect, useState } from "react";
import { showNotification } from "../Utils/notification.util";
import Registered from "./Registered";
import registerBg from "../assets/img/register.jpg";

function Register() {
  const [countries, setCountries] = useState([]);
  const [savedUser, setSavedUser] = useState({});
  const [showRegister, setIsShowRegister] = useState(true);
  const [current, setCurrent] = useState();
  const [newUser, setNewUser] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    username: "",
    phoneNumber: "",
    alternatePhoneNumber: "",
    subscriptionExpirationDate: new Date(),
    business: {},
    role: "ADMIN",
    packageExpired: true,
  });

  const [business, setBusiness] = useState({
    name: "",
    description: "",
    location: "",
    telephoneOne: "",
    telephoneTwo: "",
    subscriptionExpirationDate: current,
  });

  const [location, setLocation] = useState({
    country: "",
    state: "",
  });

  const [passwordConfirmation, setPasswordConfirmation] = useState("");

  const handlePasswordConfirmationChange = (e) => {
    setPasswordConfirmation(e.target.value);
  };
  useEffect(() => {
    const today = new Date();
    today.setDate(today.getDate() + 1);
    setCurrent(today);
    fetch("https://restcountries.com/v3.1/all")
      .then((response) => response.json())
      .then((data) => {
        const sortedCountries = data.sort((a, b) =>
          a.name.common.localeCompare(b.name.common)
        );

        setCountries(sortedCountries);
      })
      .catch((error) => {
        // Handle error
      });
  }, []);

  const handleChange = (e) => {
    e.preventDefault();
    const value = e.target.value;
    const name = e.target.name;

    if (name === "role") {
      //  setCategory(value);
      setNewUser({
        ...newUser,
        role: value === "category1" ? "GENERAL" : "ADMIN",
      });
    } else {
      setNewUser({
        ...newUser,
        [name]: value,
      });
    }
  };

  const handleBusinessChange = (e) => {
    e.preventDefault();
    const value = e.target.value;
    setBusiness({
      ...business,
      [e.target.name]: value,
    });
  };

  const handleLocationChange = (e) => {
    e.preventDefault();
    const value = e.target.value;
    setLocation({
      ...location,
      [e.target.name]: value,
    });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    if (passwordConfirmation !== newUser.password) {
      showNotification("Password does not match");
      return;
    }
    business.location = location.country + " " + location.state;
    newUser.business = business;
  };

  return (
    <>
      {showRegister ? (
        <div>
          <section className="h-100 bg-dark">
            <div className="container py-5 h-100">
              <div className="row d-flex justify-content-center align-items-center h-100">
                <div className="col">
                  <div className="card card-registration my-4">
                    <div className="row g-0">
                      <div className="col-xl-6 d-none d-xl-block">
                        <img
                          src={registerBg}
                          alt=""
                          className="img-fluid"
                          style={{
                            borderTopLeftRadius: ".25rem",
                            borderBottomLeftRadius: ".25rem",
                          }}
                        />
                      </div>
                      <form className="col-xl-6" onSubmit={handleSubmit}>
                        <div>
                          <div className="card-body p-md-5 text-black">
                            <h3 className="mb-5 text-uppercase">
                              Registration Form
                            </h3>

                            <div className="row">
                              <div className="col-md-6 mb-4">
                                <div className="form-outline">
                                  <input
                                    type="text"
                                    className="form-control form-control-lg"
                                    onChange={handleChange}
                                    required
                                    name="firstName"
                                  />
                                  <label
                                    className="form-label"
                                    for="form3Example1m"
                                  >
                                    First name*
                                  </label>
                                </div>
                              </div>
                              <div className="col-md-6 mb-4">
                                <div className="form-outline">
                                  <input
                                    type="text"
                                    className="form-control form-control-lg"
                                    onChange={handleChange}
                                    required
                                    name="lastName"
                                  />
                                  <label
                                    className="form-label"
                                    for="form3Example1n"
                                  >
                                    Last name*
                                  </label>
                                </div>
                              </div>
                            </div>
                            <div className="row">
                              <div className="col-md-6 mb-4">
                                <div className="form-outline">
                                  <input
                                    type="text"
                                    className="form-control form-control-lg"
                                    onChange={handleChange}
                                    required
                                    name="username"
                                  />
                                  <label
                                    className="form-label"
                                    for="form3Example1n"
                                  >
                                    username *
                                  </label>
                                </div>
                              </div>
                            </div>

                            <div className="row">
                              <div className="col-md-6 mb-4">
                                <div className="form-outline">
                                  <input
                                    type="password"
                                    className="form-control form-control-lg"
                                    onChange={handleChange}
                                    required
                                    name="password"
                                  />
                                  <label
                                    className="form-label"
                                    htmlFor="form3Example1m"
                                  >
                                    Password*
                                  </label>
                                </div>
                              </div>
                              <div className="col-md-6 mb-4">
                                <div className="form-outline">
                                  <input
                                    type="password"
                                    className="form-control form-control-lg"
                                    onChange={handlePasswordConfirmationChange}
                                    required
                                    name="passwordConfirmation"
                                  />
                                  <label
                                    className="form-label"
                                    htmlFor="form3Example1n"
                                  >
                                    Confirm Password*
                                  </label>
                                </div>
                              </div>
                            </div>

                            {passwordConfirmation !== newUser.password && (
                              <p>Passwords do not match.</p>
                            )}

                            <div className="row">
                              <div className="col-md-6 mb-4">
                                <div className="form-outline">
                                  <input
                                    type="tel"
                                    onChange={handleChange}
                                    required
                                    className="form-control form-control-lg"
                                    name="phoneNumber"
                                  />
                                  <label
                                    className="form-label"
                                    for="form3Example1m1"
                                  >
                                    Phone number*
                                  </label>
                                </div>
                              </div>
                              <div className="col-md-6 mb-4">
                                <div className="form-outline">
                                  <input
                                    type="tel"
                                    onChange={handleChange}
                                    className="form-control form-control-lg"
                                    name="alternatePhoneNumber"
                                  />
                                  <label
                                    className="form-label"
                                    for="form3Example1n1"
                                  >
                                    Alternate phone number
                                  </label>
                                </div>
                              </div>
                            </div>

                            <div className="row">
                              <div className="col-md-6 mb-4">
                                <div className="form-outline">
                                  <input
                                    type="email"
                                    id="form3Example1m1"
                                    className="form-control form-control-lg"
                                    name="email"
                                    onChange={handleChange}
                                    required
                                  />
                                  <label
                                    className="form-label"
                                    for="form3Example1m1"
                                  >
                                    Email*
                                  </label>
                                </div>
                              </div>
                              <div className="col-md-6 mb-4">
                                <div className="form-outline">
                                  <input
                                    type="text"
                                    id="form3Example1n1"
                                    className="form-control form-control-lg"
                                    onChange={handleBusinessChange}
                                    name="name"
                                    required
                                  />
                                  <label
                                    className="form-label"
                                    for="form3Example1n1"
                                  >
                                    Business Name*
                                  </label>
                                </div>
                              </div>
                            </div>

                            <div className="row">
                              <div className="col-md-6 mb-4">
                                <div className="form-outline">
                                  <input
                                    type="tel"
                                    required
                                    className="form-control form-control-lg"
                                    onChange={handleBusinessChange}
                                    name="telephoneOne"
                                  />
                                  <label
                                    className="form-label"
                                    for="form3Example1m1"
                                  >
                                    Business phone number*
                                  </label>
                                </div>
                              </div>
                              <div className="col-md-6 mb-4">
                                <div className="form-outline">
                                  <input
                                    type="tel"
                                    onChange={handleBusinessChange}
                                    className="form-control form-control-lg"
                                    name="telephoneTwo"
                                  />
                                  <label
                                    className="form-label"
                                    for="form3Example1n1"
                                  >
                                    Alternate phone number
                                  </label>
                                </div>
                              </div>
                            </div>
                            <div className="form-outline mb-4">
                              <input
                                type="text"
                                onChange={handleBusinessChange}
                                required
                                className="form-control form-control-lg"
                                name="description"
                              />
                              <label className="form-label" for="form3Example8">
                                Business Description *
                              </label>
                            </div>
                            <div className="col-md-6 mb-4">
                              <select
                                className="select form-control"
                                onChange={handleChange}
                                name="role"
                              >
                                <option value="1">Package category</option>
                                <option value="category1">Basic </option>
                                <option value="category2">Advanced</option>
                              </select>
                            </div>

                            {/*        <div className="d-md-flex justify-content-start align-items-center mb-4 py-2">
                        <h6 className="mb-0 me-4">Gender: </h6>

                        <div className="form-check form-check-inline mb-0 me-4">
                          <input
                            className="form-check-input"
                            type="radio"
                            name="inlineRadioOptions"
                            id="femaleGender"
                            value="option1"
                          />
                          <label
                            className="form-check-label"
                            for="femaleGender"
                          >
                            Female
                          </label>
                        </div>

                        <div className="form-check form-check-inline mb-0 me-4">
                          <input
                            className="form-check-input"
                            type="radio"
                            name="inlineRadioOptions"
                            id="maleGender"
                            value="option2"
                          />
                          <label className="form-check-label" for="maleGender">
                            Male
                          </label>
                        </div>

                        <div className="form-check form-check-inline mb-0">
                          <input
                            className="form-check-input"
                            type="radio"
                            name="inlineRadioOptions"
                            id="otherGender"
                            value="option3"
                          />
                          <label className="form-check-label" for="otherGender">
                            Other
                          </label>
                        </div>
                      </div> */}

                            <div className="row">
                              <div className="col-md-6 mb-4">
                                <select
                                  className="select form-control"
                                  defaultValue=""
                                  onChange={handleLocationChange}
                                  required
                                  name="country"
                                >
                                  <option value="">Country</option>
                                  {countries.map((country) => (
                                    <option
                                      key={country.name.common}
                                      value={country.name.common}
                                    >
                                      {country.name.common}
                                    </option>
                                  ))}
                                </select>
                              </div>

                              <div className="form-outline mb-4 col-md-6">
                                <input
                                  type="text"
                                  onChange={handleLocationChange}
                                  required
                                  className="form-control form-control-lg"
                                  name="state"
                                />
                                <label
                                  className="form-label"
                                  for="form3Example90"
                                >
                                  County/State
                                </label>
                              </div>
                            </div>

                            {/*   <div className="form-outline mb-4">
                        <input
                          type="text"
                          id="form3Example99"
                          className="form-control form-control-lg"
                        />
                        <label className="form-label" for="form3Example99">
                          Course
                        </label>
                      </div> */}

                            {/* <div className="form-outline mb-4">
                        <input
                          type="text"
                          id="form3Example97"
                          className="form-control form-control-lg"
                        />
                        <label className="form-label" for="form3Example97">
                          Email ID
                        </label>
                      </div> */}

                            <div className="d-flex justify-content-end pt-3">
                              <button
                                type="button"
                                className="btn btn-light btn-lg"
                              >
                                Reset all
                              </button>
                              <button
                                type="submit"
                                className="btn btn-warning btn-lg ms-2"
                              >
                                Submit form
                              </button>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      ) : (
        <Registered savedUser={savedUser} />
      )}
    </>
  );
}

export default Register;
