import "bootstrap/dist/css/bootstrap.css";
import { Route, BrowserRouter, Routes } from "react-router-dom";
import { useState } from "react";
import { useEffect } from "react";
import Layout from "./pages/Layout";
import Stock from "./pages/Stock";
import Dashboard from "./pages/Dashboard";
import VerifyEmail from "./userManagement/VerifyEmail";
import Register from "./userManagement/Register";
import Login from "./userManagement/Login";
import Management from "./pages/Management";
import Settings from "./pages/Settings";
import { ToastContainer } from "react-toastify";
import Summary from "./pages/Summary";
import Expenses from "./pages/Expenses";
import Cart from "./pages/Cart";
import { useUser } from "./Utils/UserContext";
import Debtors from "./pages/Debtors";
import Administrator from "./pages/Administrator";
import ForgotPassword from "./userManagement/ForgotPassword";
import UserAccount from "./pages/UserAccount";
import Accounting from "./pages/Accounting";
import Sales from "./pages/Sales";
import EmailConfirmation from "./pages/subPages/EmailConfirmation";
import Account from "./components/Settings/Account";
import BusinessProfile from "./components/Settings/BusinessProfile";
import { InvoiceToPrint } from "./components/cart/receipts/InvoiceToPrint";
import CreateUser from "./components/Settings/CreateUser";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import PendingOrders from "./components/management/PendingOrders";

function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const { user } = useUser();
  const [userExist, setUserExist] = useState(false);

  const activeUser = () => {
    console.log("refreshed user", user);
    setCurrentUser(user);
    if (user) {
      setUserExist(true);
    }
  };

  useEffect(() => {
    activeUser();
    // eslint-disable-next-line
  }, []);

  return (
    <>
      <ToastContainer hideProgressBar={true} theme="colored" />
      {userExist ? (
        <BrowserRouter>
          {console.log(currentUser)}
          <Routes>
            <Route
              path="/"
              element={<Layout role={"ADMIN"} currentUser={currentUser} />}
            >
              <Route index element={<Dashboard currentUser={currentUser} />} />
              <Route path="expenses" element={<Expenses />} />

              {/* Management routes */}
              <Route path="management" element={<Management />} />
              <Route path="management/stock" element={<Stock />} />
              <Route
                path="management/pending-orders"
                element={<PendingOrders />}
              />
              <Route path="/settings" element={<Settings />}></Route>

              {/* settings route */}
              <>
                <Route path="/settings/account" element={<Account />} />
                <Route
                  path="/settings/business-profile"
                  element={<BusinessProfile />}
                />
                <Route
                  path="/settings/business-profile/add-user"
                  element={<CreateUser />}
                />
              </>

              {/* End of purchases routes */}
              <Route path="summary" element={<Summary />} />
              <Route path="cart" element={<Cart />}></Route>
              <Route path="receipt" element={<InvoiceToPrint />} />
              <Route path="debtors" element={<Debtors />} />
              <Route path="administrator" element={<Administrator />} />
              <Route path="user-account" element={<UserAccount />} />
              <Route path="accounting" element={<Accounting />} />
            </Route>
            <Route path="/sales" element={<Sales />} />
          </Routes>
        </BrowserRouter>
      ) : (
        <BrowserRouter>
          <Routes>
            <Route path="/verify-email" element={<VerifyEmail />} />
            <Route path="/register" element={<Register />} />
            <Route
              path="/login"
              element={
                <Login activeUser={activeUser} setUserExist={setUserExist} />
              }
            />
            <Route path="/privacy-policy" element={<PrivacyPolicy />} />
            <Route
              path="*"
              element={
                <Login activeUser={activeUser} setUserExist={setUserExist} />
              }
            />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route
              path="/confirmEmail/:token"
              element={<EmailConfirmation />}
            />
          </Routes>
        </BrowserRouter>
      )}
    </>
  );
}

export default App;
