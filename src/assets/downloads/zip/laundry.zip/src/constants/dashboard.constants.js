import EditIcon from "../images/icons/edit.png";
import HomeIcon from "../images/icons/home.png";
import SettingIcon from "../images/icons/setting.png";
import SaleIcon from "../images/icons/sale.png";
import SummaryIcon from "../images/icons/summary.png";
import ExpensesIcon from "../images/icons/expenses.png";
import Accounting from "../images/icons/accounting.png";
import Creditor from "../images/icons/creditor.png";

export const iconMap = {
  Dashboard: "fa-tachometer-alt",
  Sales: "fa-dollar-sign",
  Expenses: "fa-money-bill-wave",
  Creditor: "fa-credit-card",
  Operation: "fa-edit",
  Summary: "fa-chart-pie",
  Accounting: "fa-calculator",
  Administrator: "fa-cogs",
  Users: "fa-users",
  Purchases: "fa-shopping-cart",
};

export const menuItems = {
  SYSTEM_ADMIN: [
    { to: "/", label: "Dashboard" },
    { to: "/administrator", label: "Administrator" },
  ],
  ADMIN: [
    { to: "/", label: "Dashboard" },
    { to: "/management", label: "Operation" },
    { to: "/user-account", label: "Users" },
    { to: "/summary", label: "Summary" },
    { to: "/accounting", label: "Accounting" },
    { to: "/administrator", label: "Administrator" },
  ],
  USER: [
    { to: "/", label: "Dashboard" },
    { to: "/sales", label: "Sales" },
    { to: "/expenses", label: "Expenses" },
    { to: "/debtors", label: "Creditor" },
  ],
  GENERAL: [
    { to: "/", label: "Dashboard" },
    { to: "/sales", label: "Sales" },
    { to: "/expenses", label: "Expenses" },
    { to: "/debtors", label: "Creditor" },
    { to: "/management", label: "Operation" },
    { to: "/summary", label: "Summary" },
    { to: "/accounting", label: "Accounting" },
    { to: "/user-account", label: "Users" },
  ],
};
