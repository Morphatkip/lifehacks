function getTotalAmount(arrayData, amount) {
  return arrayData.reduce((total, item) => total + item.amount, 0);
}
