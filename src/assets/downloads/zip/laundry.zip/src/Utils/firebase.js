import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import {
  getFirestore,
  doc,
  getDoc,
  collection,
  getDocs,
  setDoc,
} from "firebase/firestore";
import {
  getStorage,
  ref,
  getDownloadURL,
  uploadBytesResumable,
} from "firebase/storage";
/* import env from "react-dotenv"; */
const firebaseConfig = {
  /*  apiKey: process.env.REACT_APP_API_KEY,
  authDomain: process.env.REACT_APP_AUTH_DOMAIN,
  projectId: process.env.REACT_APP_PROJECT_ID,
  storageBucket: process.env.REACT_APP_STORAGE_BUCKET,
  messagingSenderId: process.env.REACT_APP_MESSAGING_SENDER_ID,
  appId: process.env.REACT_APP_APP_ID,
  measurementId: process.env.REACT_APP_MEASUREMENT_ID, */

  apiKey: "AIzaSyCUnCT22vIcOTGOpQaF7hE2-j3TcyAXyKQ",
  authDomain: "everflows-106ad.firebaseapp.com",
  projectId: "everflows-106ad",
  storageBucket: "everflows-106ad.appspot.com",
  messagingSenderId: "804799289119",
  appId: "1:804799289119:web:aa0dae4cf0c4b0edce822a",
  measurementId: "G-FVRM43QEJE",

  /* apiKey: "AIzaSyAsbOS3PGl-vZPBexMAKkIU7bPkt25COxk",
  authDomain: "everflows-521a3.firebaseapp.com",
  databaseURL: "https://everflows-521a3-default-rtdb.firebaseio.com",
  projectId: "everflows-521a3",
  storageBucket: "everflows-521a3.appspot.com",
  messagingSenderId: "935224017670",
  appId: "1:935224017670:web:4b1359d3da601ae80a9487",
  measurementId: "G-Z517DV71HD", */
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const authorization = new getAuth(app);
const db = getFirestore(app);
export {
  auth,
  db,
  doc,
  getDoc,
  collection,
  getDocs,
  getStorage,
  ref,
  getDownloadURL,
  uploadBytesResumable,
  setDoc,
  authorization,
  app,
};
