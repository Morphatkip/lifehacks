export const printReceipt = (btn) => {
  return btn;
};
