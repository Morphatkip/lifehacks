var monitorSalesChange = false;
const triggerSalesChange = () => {
  monitorSalesChange = true;
};

export { monitorSalesChange, triggerSalesChange };
