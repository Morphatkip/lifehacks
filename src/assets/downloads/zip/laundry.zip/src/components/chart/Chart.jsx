import React from "react";
import Plot from "react-plotly.js";

export const SalesLineChart = ({ data }) => {
  const chartData = {
    x: data.map((sale) => new Date(sale.orderDate).toLocaleDateString()),
    y: data.map((sale) => sale.total),
    type: "scatter",
    mode: "lines+markers", // This will add both lines and markers to the chart
    line: { color: "rgba(75,192,192,1)", width: 3 },
    marker: { color: "rgba(75,192,192,1)" },
  };

  return (
    <Plot
      data={[chartData]}
      layout={{
        width: 500,
        height: 300,
        title: "Sales Line t",
        xaxis: { title: "Date" },
        yaxis: { title: "Total Sales" },
      }}
    />
  );
};
