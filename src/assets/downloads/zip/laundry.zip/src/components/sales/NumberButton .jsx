import React from "react";

const NumberButton = ({ value, onClick }) => {
  return (
    <button className="btn btn-primary m-1" onClick={() => onClick(value)}>
      {value}
    </button>
  );
};

export default NumberButton;
