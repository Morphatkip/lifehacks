import React from "react";
import ReceiptFrame from "./ReceiptFrame";

export const RFQuotationPrint = React.forwardRef((props, ref) => {
  const date = new Date().toLocaleString();

  const userStr = localStorage.getItem("user");
  let user = JSON.parse(userStr);
  const { business } = user;
  const { rfqs } = props;
  console.log(rfqs);

  // Convert logo bytes to Data URL
  const logoDataUrl = business?.logo
    ? `data:image/png;base64,${business.logo}` // Assuming the logo format is PNG
    : null;

  return (
    <div ref={ref}>
      <div className="container mt-4 row" style={{ fontSize: " 10px" }}>
        <div className="d-flex justify-content-between">
          <div>
            {logoDataUrl && (
              <img
                src={logoDataUrl}
                alt="Business Logo"
                style={{ width: "100px", height: "100px" }}
              />
            )}
            <h4 className="mt-0">{business.name}</h4>
          </div>
          <div className="d-flex flex-column">
            <div>
              <h4 className="fw-bold">Request For Quotation</h4>
            </div>
            <div>
              <h6>{date}</h6>
            </div>
          </div>
        </div>
        <div className="d-flex justify-content-between mt-4">
          <div className=" d-flex flex-column ">
            <div className="fw-bold">Office Address</div>
            <div> {business.location}</div>
            <br></br>
            <div>{business.telephoneOne}</div>
          </div>
          {/* <div className="d-flex flex-column">
            <div>To:</div>
            <div>{invoice.customer?.phoneNumber}</div>
           
          </div> */}
        </div>

        <div className=" table-responsive  mt-4 ">
          <table className="table">
            <thead className="fw-bold table-success ">
              <tr className="">
                <th>Items</th>
                <th>Measurement</th>
              </tr>
            </thead>
            <tbody className="table-hover">
              {rfqs.map((product) => (
                <RfqFrame product={product} key={product.id} />
              ))}
            </tbody>
          </table>
        </div>
        {/*  <div className="d-flex justify-content-end fw-bold">
          <div>
            <div className="row">
              <div className="col-md-6">Discount:</div>
              <div className="col-md-6">{invoice?.discount}</div>
            </div>
            <div className="row">
              <div className="col-md-6">Tax:</div>
              <div className="col-md-6">{invoice?.tax}</div>
            </div>
            <div className="row bg-success text-light">
              <div className="col-md-6">Total Due:</div>
              <div className="col-md-6">{invoice?.totalOwed}</div>
            </div>
          </div>
        </div> */}
        <hr className="hr bg-success mb-4 mt-4" />
      </div>
    </div>
  );
});

const RfqFrame = ({ product }) => {
  return (
    <tr>
      <td>{product.displayName}</td>
      <td>
        {product.weight}
        {product?.unitOfMeasurement.name}{" "}
      </td>
      <td></td>
    </tr>
  );
};
