import React from "react";

function CartFrame({
  serviceItem,
  handleRemove,
  index,
  togggleShowCartItems,
  selectedRow,
  setSelectedRow,
  reduceQuantity,
  increaseQuantity,
  changeQuantity,
}) {
  /*  useEffect(() => {
    getFunction(`/products/stocks/${serviceItem.product.id}`)
      .then((qnty) => {
        setAvailabelStock(qnty);
       
      })
      .catch((error) => {
    
      });

   

    // eslint-disable-next-line
  }, []); */

  const handleQuantityInputChange = (event) => {
    const newQuantity = parseFloat(event.target.value, 10);
    if (!isNaN(newQuantity) && newQuantity > 0) {
      changeQuantity(newQuantity); // Call the changeQuantity function with the new value
    }
  };

  return (
    <tr
      className={selectedRow === index ? "table-active" : ""}
      /* onClick={handleClick} */
    >
      <td>{serviceItem?.dataValues.serviceName}</td>
      <td>
        {" "}
        <input
          type="number"
          value={serviceItem.quantity}
          onChange={handleQuantityInputChange}
          step="0.01"
          min="0" // Ensuring minimum value of 1
        />
      </td>
      <td>{serviceItem?.dataValues.price}</td>
      <td>{parseFloat(serviceItem.quantity) * serviceItem.dataValues.price}</td>
      <td>
        <button onClick={handleRemove} className="btn">
          <i className="bi bi-trash" />
        </button>
      </td>
      {/*   <td><button  onClick={handleReduceQuantity} className="btn"><i className="bi bi-dash-circle"></i></button>
      <button onClick = {handleAddQuantity} className="btn"><i className="bi bi-plus-circle"></i></button></td> */}
    </tr>
  );
}

export default CartFrame;
