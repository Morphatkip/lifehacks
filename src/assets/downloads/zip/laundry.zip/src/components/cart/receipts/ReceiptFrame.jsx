import React from "react";

function ReceiptFrame({ product }) {
  return (
    <tr>
      <td>{product.product?.displayName}</td>
      <td>{product?.quantity}</td>
      <td>{product?.price}</td>
      <td>{product?.price * product.quantity}</td>
    </tr>
  );
}

export default ReceiptFrame;
