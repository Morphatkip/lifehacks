import React, { useEffect } from "react";
import { useState } from "react";
import { getCart, storeCart } from "../../Utils/local-storage";
import { showNotification } from "../../Utils/notification.util";

function EditCart({ togggleShowCartItems, soldItem, getCart: refresh }) {
  const [availableStock, setAvailabelStock] = useState(0);
  const [itemsSold, setItemSold] = useState({});

  useEffect(() => {
    // eslint-disable-next-line
  }, []);

  const handleChange = (e) => {
    let value = e.target.value;
    if (e.target.name === "quantity") {
      if (e.target.value > availableStock) {
        showNotification("Quantity is more than available Stock", "");
      } else {
        setItemSold({
          ...itemsSold,
          [e.target.name]: value,
        });
      }
    } else {
      setItemSold({
        ...itemsSold,
        [e.target.name]: value,
      });
    }
  };
  const handleSubmit = () => {
    let tempCart = getCart();
    console.log({ tempCart });
    tempCart[itemsSold.product.id] = itemsSold;
    console.log({ tempCart });
    storeCart({ ...tempCart });
    refresh();
    togggleShowCartItems();
  };

  const handleCancel = () => {
    togggleShowCartItems();
  };
  return (
    <div>
      <div>
        <h1> {itemsSold.name}</h1>
      </div>
      <form className="w-50">
        <div className="form-group my-2">
          <label htmlFor="buyerName">Quantity</label>
          <input
            type="number"
            className="form-control"
            onChange={handleChange}
            name="quantity"
            value={itemsSold.quantity}
            required
          />
        </div>
        <div className="form-group my-2">
          <label htmlFor="buyerName">Price</label>
          <input
            type="number"
            className="form-control"
            id="buyersName"
            onChange={handleChange}
            name="agreedPrice"
            value={itemsSold.agreedPrice}
            required
          />
        </div>
      </form>
      <button
        onClick={handleSubmit}
        type="submit"
        className="btn btn-primary m-4 "
      >
        Submit
      </button>
      <button onClick={handleCancel} type="submit" className="btn btn-primary ">
        Cancel
      </button>
    </div>
  );
}

export default EditCart;
