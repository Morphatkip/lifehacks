import React from "react";
import ReceiptFrame from "./ReceiptFrame";
import ReactToPrint from "react-to-print";
import { Link } from "react-router-dom";
class Receipt extends React.Component {
  render() {
    const date = new Date().toLocaleString();

    const storedData = localStorage.getItem("order");
    const order = JSON.parse(storedData);
    const userStr = localStorage.getItem("user");
    let user = JSON.parse(userStr);
    const { business } = user;

    return (
      <div className=" container mt-0" style={{ fontSize: " 10px" }}>
        {/*  <div style={{ display: "none" }}>
          
          <ReceiptToPrint ref={(el) => (this.componentRef = el)} />
        </div> */}

        <div className="d-flex flex-column justify-content-center align-items-center ">
          <h4 className="mb-0">{business.name}</h4>
          <p className="mb-0">{business.location}</p>
          <p className="mb-0">Telephone: {business.telephoneOne}</p>
        </div>

        <div className="cash-sales-section mt-4 display-12">
          <p className="mb-1">Customer Name: {order.customer.name}</p>
          <p className="mb-1">
            Purchase Option:{" "}
            {order.customer.debtor ? "Credit Sale" : "Cash Sale"}
          </p>
          <p className="mb-1">Sale Date: {date}</p>
        </div>

        <div className="card table-responsive-sm w-100 p-3">
          <table className="table">
            <thead className="fw-bold">
              <tr>
                <th>Item</th>
                <th>qty</th>
                <th>Rate</th>
                <th>Amount</th>
              </tr>
            </thead>
            <tbody className="table-hover">
              {order.orderItems.map((orderItem) => (
                <ReceiptFrame product={orderItem} key={orderItem.id} />
              ))}
            </tbody>
          </table>
          <h2 className="mb-0">Total: {order.total}</h2>
        </div>
        <div className=" m-2 d-flex justify-content-end align-items-center">
          <ReactToPrint
            trigger={() => {
              return (
                <Link to="/cart" className="btn btn-primary">
                  Print Receipt
                </Link>
              );
            }}
            content={() => this.componentRef}
          />
        </div>
      </div>
    );
  }
}

export default Receipt;
