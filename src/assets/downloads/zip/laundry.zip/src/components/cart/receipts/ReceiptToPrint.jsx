import React from "react";
import ReceiptFrame from "./ReceiptFrame";

export const ReceiptToPrint = React.forwardRef((props, ref) => {
  const date = new Date().toLocaleString();
  const { order } = props;

  /*   const storedData = localStorage.getItem("order");
  const order = JSON.parse(storedData); */
  const userStr = localStorage.getItem("user");
  let user = JSON.parse(userStr);
  const { business } = user;

  // Convert logo bytes to Data URL
  const logoDataUrl = business?.logo
    ? `data:image/png;base64,${business.logo}` // Assuming the logo format is PNG
    : null;

  return (
    <div ref={ref}>
      <div
        className="container mt-0"
        style={{
          fontSize: " 12px",
          fontFamily: "unset",
          fontWeight: "inherit",
        }}
      >
        <div className="d-flex flex-column justify-content-center align-items-center ">
          {logoDataUrl && (
            <img
              src={logoDataUrl}
              alt="Business Logo"
              style={{ width: "100px", height: "100px" }}
            />
          )}
          <h4 className="mb-0">{business?.name}</h4>
          <p className="mb-0">{business?.location}</p>
          <p className="mb-0">Telephone: {business?.telephoneOne}</p>
        </div>

        <div className="cash-sales-section  display-12">
          <p className="mb-1">Customer Name: {order?.customer?.name}</p>
          <p className="mb-1">
            Purchase Option:{" "}
            {order?.customer?.debtor ? "Credit Sale" : "Cash Sale"}
          </p>
          <p className="mb-1">Sale Date: {date}</p>
        </div>

        <div className="card table-responsive-sm w-100 ">
          <table className="table">
            <thead className="fw-bold">
              <tr>
                <th>Item</th>
                <th>qty</th>
                <th>Rate</th>
                <th>Amount</th>
              </tr>
            </thead>
            <tbody className="table-hover">
              {order?.orderItems?.map((orderItem) => (
                <ReceiptFrame product={orderItem} key={orderItem.id} />
              ))}
            </tbody>
          </table>
          <p className="mb-0">Total: {order?.total}</p>
        </div>
      </div>
    </div>
  );
});
