import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { getCart, storeCart } from "../../Utils/local-storage";
import { showNotification } from "../../Utils/notification.util";
import CartFrame from "./CartFrame";
import EditCart from "./EditCart";

function CartBody({ updateCart: refresh, cartUpdate }) {
  const navigate = useNavigate();
  const [cart, setCart] = useState([]);
  const handleRemove = (id) => {
    let tempCart = getCart();
    delete tempCart[id];
    storeCart({ ...tempCart });
    getCartItems();
    refresh();
  };
  const [itemsSold, setItemSold] = useState();
  const [showCartItems, setShowCartItems] = useState(true);

  const handleCheckOut = (e) => {
    e.preventDefault();
    navigate("/checkout");
  };
  const getCartItems = () => {
    setCart(Object.values(getCart()));
  };

  useEffect(() => {
    getCartItems();
    if (!cart) {
      showNotification("Cart is empty");
      navigate("/stock");
    }
    getCartItems();
    // eslint-disable-next-line
  }, [cartUpdate]);
  const togggleShowCartItems = (soldItem) => {
    setShowCartItems(!showCartItems);
    setItemSold(soldItem);
  };

  return (
    <div>
      {showCartItems ? (
        <>
          {cart.length === 0 ? (
            <>
              <div className="container">
                <div className="row">
                  <div className="col-md-6 mx-auto fw-bold">
                    <p>
                      The cart is empty! <br /> To add items, scan using Barcode
                      or go to sales and add items maanually to cart
                    </p>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div>
              <table className="table fw-bold ">
                <thead className="bg-muted">
                  <tr>
                    <th> Name</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Total</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody className="overflow-auto">
                  {cart?.map((soldItem, index) => (
                    <CartFrame
                      soldItem={soldItem}
                      key={index}
                      index={index}
                      handleRemove={handleRemove}
                      togggleShowCartItems={togggleShowCartItems}
                    />
                  ))}
                </tbody>
              </table>
              <div>
                <div className="d-flex justify-content-end">
                  <button onClick={handleCheckOut} className="btn btn-primary">
                    Check out
                  </button>
                </div>
              </div>
            </div>
          )}
        </>
      ) : (
        <EditCart
          togggleShowCartItems={togggleShowCartItems}
          soldItem={itemsSold}
          getCart={getCartItems}
        />
      )}
    </div>
  );
}

export default CartBody;
