import React from "react";
import "../../Styles/Settings/createUser.css";
import AddUser from "../Modal/AddUser";
import UseModal from "../Modal/UseModal";
import { useUser } from "../../Utils/UserContext";
import Settings from "../../pages/Settings";
function CreateUser() {
  const { isShowingAddUser, toggleAddUser } = UseModal();
  const { user } = useUser();
  const { business } = user;

  return (
    <Settings>
      {" "}
      <div className="buttons-container">
        <button className="btn btn-success" onClick={toggleAddUser}>
          Add User
        </button>
        <AddUser
          hide={toggleAddUser}
          isShowingAddUser={isShowingAddUser}
          business={business}
        />
        {/*  <button>Delete User</button> */}
      </div>
    </Settings>
  );
}

export default CreateUser;
