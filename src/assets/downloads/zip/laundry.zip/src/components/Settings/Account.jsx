import React, { useState } from "react";
import Settings from "../../pages/Settings";
import { useUser } from "../../Utils/UserContext";
import UseModal from "../Modal/UseModal";
import {
  ChangePassword,
  ProfileEdit,
  ProfileOverview,
  ProfileSettings,
} from "./ProfileComponents";
import { Link } from "react-router-dom";
import "../../assets/css/profile.css";
import MainContentContainer from "../management/MainContentContainer";

function Account() {
  const { user } = useUser();
  const { togggleEditUser, isShowingEditUser } = UseModal();
  const handleChangePassword = (e) => {
    e.preventDefault();
  };

  const [activeTab, setActiveTab] = useState("profile-overview");

  const handleTabClick = (tabId) => {
    setActiveTab(tabId);
  };
  console.log(user);
  return (
    <MainContentContainer>
      <div style={{ height: "100%" }}>
        <Settings>
          <div>
            <div className="pagetitle">
              <nav>
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="https://www.firetipsedu.com/">Home</Link>
                  </li>
                  <li className="breadcrumb-item">Settings</li>
                  <li className="breadcrumb-item active">Account</li>
                </ol>
              </nav>
            </div>
            {/*   End Page Title  */}
            <ul className="nav nav-tabs nav-tabs-bordered w-100">
              <li className="nav-item">
                <button
                  className={`nav-link ${
                    activeTab === "profile-overview" ? "active" : ""
                  }`}
                  onClick={() => handleTabClick("profile-overview")}
                >
                  Overview
                </button>
              </li>

              {/*    <li className="nav-item">
                <button
                  className={`nav-link ${
                    activeTab === "profile-edit" ? "active" : ""
                  }`}
                  onClick={() => handleTabClick("profile-edit")}
                >
                  Edit Profile
                </button>
              </li> */}

              {/*   <li className="nav-item">
                <button
                  className={`nav-link ${
                    activeTab === "profile-settings" ? "active" : ""
                  }`}
                  onClick={() => handleTabClick("profile-settings")}
                >
                  Settings
                </button>
              </li> */}

              <li className="nav-item">
                <button
                  className={`nav-link ${
                    activeTab === "profile-change-password" ? "active" : ""
                  }`}
                  onClick={() => handleTabClick("profile-change-password")}
                >
                  Change Password
                </button>
              </li>
            </ul>

            <section className="section profile">
              <div className="row">
                {/*  <div className="col-xl-4">
                <div className="card">
                  <div className="card-body profile-card pt-4 d-flex flex-column align-items-center">
                    <img
                      src="to be "
                      alt="Profile"
                      className="rounded-circle"
                    />
                    <h2>K Morphat</h2>
                    <h3>Software Engineer</h3>
                    <div className="social-links mt-2">
                      <a href="#" className="twitter">
                        <i className="bi bi-twitter"></i>
                      </a>
                      <a href="#" className="facebook">
                        <i className="bi bi-facebook"></i>
                      </a>
                      <a href="#" className="instagram">
                        <i className="bi bi-instagram"></i>
                      </a>
                      <a href="#" className="linkedin">
                        <i className="bi bi-linkedin"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
 */}

                <div className="col-xl-8">
                  <div className="card">
                    <div className="card-body pt-3">
                      {/*   Bordered Tabs  */}

                      <div className="tab-content pt-2">
                        <div
                          className={`tab-pane fade ${
                            activeTab === "profile-overview"
                              ? "show active"
                              : ""
                          } profile-overview`}
                        >
                          <ProfileOverview
                            profileDetails={{
                              fullName: user.dataValues.name,
                              job: user.dataValues.role,
                              phone: user.dataValues.phone_number,
                              email: user.dataValues.email,
                            }}
                          />
                        </div>

                        {/*   <div
                          className={`tab-pane fade ${
                            activeTab === "profile-edit" ? "show active" : ""
                          } profile-edit pt-3`}
                        >
                          <ProfileEdit user={user} />
                        </div> */}
                        <div
                          className={`tab-pane fade ${
                            activeTab === "profile-settings"
                              ? "show active"
                              : ""
                          } pt-3`}
                        >
                          <ProfileSettings />
                        </div>
                        <div
                          className={`tab-pane fade ${
                            activeTab === "profile-change-password"
                              ? "show active"
                              : ""
                          } pt-3`}
                        >
                          <ChangePassword user={user} />
                        </div>
                      </div>
                      {/* End tab content */}
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/*   End #main  */}
          </div>
        </Settings>
      </div>
    </MainContentContainer>
  );
}

export default Account;
