import React from "react";

import "../../assets/css/profile.css";
import MainContentContainer from "../management/MainContentContainer";

function BusinessProfile() {
  return (
    <MainContentContainer>
      <div style={{ height: "100%" }}></div>
    </MainContentContainer>
  );
}

export default BusinessProfile;
