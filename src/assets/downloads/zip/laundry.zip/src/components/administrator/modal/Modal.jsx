import React, { useState } from "react";
import ReactDOM from "react-dom";
import ModalComponent from "../../Modal/ModalComponent";
import "../../../Styles/Modal.css";
import "../../../Styles/Summary.css";

const Modal = ({ isShowingAddPayment, hide, user }) => {
  const [numberOfMonths, setNumberOfMonths] = useState(0);

  const handleSubmit = () => {
    handleClose();
  };

  const handleClose = () => {
    hide();
  };

  const handleNumberOfMonthsChange = (e) => {
    setNumberOfMonths(e.target.value);
  };

  return isShowingAddPayment
    ? ReactDOM.createPortal(
        <React.Fragment>
          <ModalComponent
            handleClose={handleClose}
            handleSave={handleSubmit}
            btnTitle="Save"
            title={"Add Payment"}
          >
            <div className="modal-body">
              <div className="mb-3">
                <label className="form-label">Number of Months:</label>
                <input
                  type="number"
                  className="form-control"
                  value={numberOfMonths}
                  onChange={handleNumberOfMonthsChange}
                />
              </div>
            </div>
          </ModalComponent>
        </React.Fragment>,
        document.body
      )
    : null;
};

export default Modal;
