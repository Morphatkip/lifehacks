import React from "react";
import "../../Styles/Summary.css";
export default function Title({
  name,
  btn,
  handleClick,
  input,
  handleSearch,
  showBtn,
  handleShowBtn,
  btnName,
  btn2Name,
  handleBtn2Action,
}) {
  const handleChange = (e) => {
    e.preventDefault();
    handleSearch(e.target.value);
  };
  return (
    <div>
      <div className="d-flex flex-row justify-content-between my-3">
        <div className="fw-bold"> {name}</div>

        {btn ? (
          <div>
            {btn2Name && (
              <button
                onClick={handleBtn2Action}
                className="btn btn-light text-black"
              >
                {btn2Name}
              </button>
            )}

            <button className="btn btn-light text-black" onClick={handleClick}>
              <span className="me-4">
                <i className="bi bi-plus" />
              </span>
              {btnName ? btnName : "Add"}
            </button>
          </div>
        ) : showBtn ? (
          <button className="btn btn-light text-black" onClick={handleClick}>
            <span className="me-4">
              <i className="bi bi-display" />
            </span>
            Pick Date
          </button>
        ) : (
          " "
        )}
      </div>
      <div className="d-flex flex-row justify-content-end my-3 mb-2">
        {input ? (
        <div className="form-group has-search w-25">
        <span className="fa fa-search form-control-feedback"></span>
        <input
          type="text"
          className="form-control"
          placeholder="Search"
          onChange={handleChange}
        />
      </div>
        ) : (
          ""
        )}
      </div>
    </div>
  );
}
