import React from "react";
import { Link } from "react-router-dom";

function Footer() {
  return (
    <footer id="footer" className="footer">
      <div className="container footer-top">
        <div className="row gy-4">
          <div className="col-lg-5 col-md-12 footer-about">
            <a href="/" className="logo d-flex align-items-center">
              <span>Green Zone Angle</span>
            </a>
            <p>
              {/*  Cras fermentum odio eu feugiat lide par naso tierra. Justo eget
              nada terra videa magna derita valies darta donna mare fermentum
              iaculis eu non diam phasellus. */}
            </p>
            <div className="social-links d-flex mt-4">
              <a href="/">
                <i className="bi bi-twitter"></i>
              </a>
              <a href="/">
                <i className="bi bi-facebook"></i>
              </a>
              <a href="/">
                <i className="bi bi-instagram"></i>
              </a>
              <a href="/">
                <i className="bi bi-linkedin"></i>
              </a>
            </div>
          </div>

          <div className="col-lg-2 col-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li>
                <a href="/">Home</a>
              </li>
              <li>
                <a href="/">About us</a>
              </li>
              <li>
                <a href="/">Services</a>
              </li>
              <li>
                <a href="/">Terms of service</a>
              </li>
              <li>
                <Link to="/privacy-policy">Privacy policy</Link>
              </li>
            </ul>
          </div>

          <div className="col-lg-2 col-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li>
                <a href="/">Point of Sales</a>
              </li>
              <li>
                <a href="/">Web Development</a>
              </li>
              <li>
                <a href="/">Product Management</a>
              </li>
              <li>
                <a href="/">Marketing</a>
              </li>
              <li>
                <a href="/">Graphic Design</a>
              </li>
            </ul>
          </div>

          <div className="col-lg-3 col-md-12 footer-contact text-center text-md-start">
            <h4>Contact Us</h4>

            <p>Nairobi, Moi Avenue</p>
            <p>Kenya</p>
            <p className="mt-4">
              <strong>Phone:</strong> <span> +254 702 251916</span>
            </p>
            <p>
              <strong>Phone:</strong> <span>+254 720 757410 </span>
            </p>
            <p>
              <strong>Email:</strong> <span>greenzoneangle@gmail.com</span>
            </p>
          </div>
        </div>
      </div>

      <div className="container copyright text-center mt-4">
        <p>
          &copy; <span>Copyright</span>{" "}
          <strong className="px-1">Green Zone Angle</strong>{" "}
          <span>All Rights Reserved</span>
        </p>
      </div>
    </footer>
  );
}

export default Footer;
