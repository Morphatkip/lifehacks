import React from "react";
import featuresLight from "../../assets/img/features-light-1.jpg";
import featuresLight2 from "../../assets/img/features-light-2.jpg";
import featuresLight3 from "../../assets/img/features-light-3.jpg";

const FeaturesSection = () => {
  return (
    <section id="features" className="features">
      <div className="container section-title" data-aos="fade-up">
        <h2>Features</h2>
        <p>
          Discover a world of powerful features including product and pricing
          management, barcode scanning, customer loyalty programs, and more, all
          designed to enhance your business operations
        </p>
      </div>
      <div className="container">
        <div className="row gy-4 align-items-center features-item">
          <div
            className="col-lg-5 order-2 order-lg-1"
            data-aos="fade-up"
            data-aos-delay="200"
          >
            <h3>Explore Powerful Features for Streamlined Operations</h3>
            <p>
              Experience the efficiency of our comprehensive feature set
              designed to simplify your business processes and maximize
              productivity.
            </p>
            <a href="/register" className="btn btn-get-started">
              Get Started
            </a>
          </div>
          <div
            className="col-lg-7 order-1 order-lg-2 d-flex align-items-center"
            data-aos="zoom-out"
            data-aos-delay="100"
          >
            <div className="image-stack">
              <img src={featuresLight} alt="" className="stack-front" />
              <img src={featuresLight2} alt="" className="stack-back" />
            </div>
          </div>
        </div>
        <div className="row gy-4 align-items-stretch justify-content-between features-item">
          <div
            className="col-lg-6 d-flex align-items-center features-img-bg"
            data-aos="zoom-out"
          >
            <img src={featuresLight3} className="img-fluid" alt="" />
          </div>
          <div
            className="col-lg-5 d-flex justify-content-center flex-column"
            data-aos="fade-up"
          >
            <h3>Setting the pace </h3>

            <ul>
              <li>
                <i className="bi bi-check"></i> <span>Customer Analytics</span>
              </li>
              <li>
                <i className="bi bi-check"></i>
                <span> Customizable Receipts</span>
              </li>
              <li>
                <i className="bi bi-check"></i> <span>Vendor Management</span>.
              </li>
            </ul>
            <a
              href="/register"
              className="btn btn-get-started align-self-start"
            >
              Get Started
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
