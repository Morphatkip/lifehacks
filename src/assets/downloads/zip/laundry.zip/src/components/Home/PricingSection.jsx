import React from "react";

const PricingSection = () => {
  return (
    <section id="pricing" className="pricing">
      <div className="container section-title" data-aos="fade-up">
        <h2>Pricing</h2>
        <p>Check out our available plans</p>
      </div>
      <div className="container" data-aos="zoom-in" data-aos-delay="100">
        <div className="row g-4">
          <div className="col-lg-4">
            <div className="pricing-item">
              <h3>Basic plan</h3>
              <div className="icon">
                <i className="bi bi-box"></i>
              </div>
              <h4>
                <sup>Ksh</sup>499<span> / month</span>
              </h4>
              <ul>
                <li>
                  <i className="bi bi-check"></i> <span>One Admin account</span>
                </li>
                <li>
                  <i className="bi bi-check"></i> <span>Sales</span>
                </li>
                <li>
                  <i className="bi bi-check"></i> <span>Summarry</span>
                </li>
                <li className="na">
                  <i className="bi bi-x"></i> <span>Credit Sales</span>
                </li>
                <li className="na">
                  <i className="bi bi-x"></i> <span>Predictions</span>
                </li>
              </ul>
              <div className="text-center">
                <a href="/" className="buy-btn">
                  Subscribe
                </a>
              </div>
            </div>
          </div>
          <div className="col-lg-4">
            <div className="pricing-item featured">
              <h3>Business Plan</h3>
              <div className="icon">
                <i className="bi bi-rocket"></i>
              </div>
              <h4>
                <sup>Ksh</sup>1499<span> / month</span>
              </h4>
              <ul>
                <li>
                  <i className="bi bi-check"></i> <span>One Admin account</span>
                </li>
                <li>
                  <i className="bi bi-check"></i> <span>Sales</span>
                </li>
                <li>
                  <i className="bi bi-check"></i> <span>Summary</span>
                </li>
                <li>
                  <i className="bi bi-check"></i> <span>Credit Sales</span>
                </li>
                <li>
                  <i className="bi bi-check"></i> <span>3 User accounts</span>
                </li>
              </ul>
              <div className="text-center">
                <a href="/" className="buy-btn">
                  Subscribe
                </a>
              </div>
            </div>
          </div>
          <div className="col-lg-4">
            <div className="pricing-item">
              <h3>Ultimate plan </h3>
              <div className="icon">
                <i className="bi bi-send"></i>
              </div>
              <h4>
                <sup>Ksh</sup>2000<span> / month</span>
              </h4>
              <ul>
                <li>
                  <i className="bi bi-check"></i>{" "}
                  <span>Unlimited Admin account</span>
                </li>
                <li>
                  <i className="bi bi-check"></i> <span>Sales</span>
                </li>
                <li>
                  <i className="bi bi-check"></i> <span>Summary</span>
                </li>
                <li>
                  <i className="bi bi-check"></i> <span>.............</span>
                </li>
                <li>
                  <i className="bi bi-check"></i>{" "}
                  <span>..................</span>
                </li>
              </ul>
              <div className="text-center">
                <a href="/" className="buy-btn">
                  Subscribe
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
