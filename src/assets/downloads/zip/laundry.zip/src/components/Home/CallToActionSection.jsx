import React from "react";
import ctaBg from "../../assets/img/cta-bg.jpg";
const CallToActionSection = () => {
  return (
    <section id="call-to-action" className="call-to-action">
      <img src={ctaBg} alt="" />
      <div className="container">
        <div
          className="row justify-content-center"
          data-aos="zoom-in"
          data-aos-delay="100"
        >
          <div className="col-xl-10">
            <div className="text-center">
              <h3>Simply the best </h3>
              {/* <p>jaifha fha jaiofa fjaopf ajf9a nfjaof afjjgf9af afi</p> */}
              {/*  <a className="cta-btn" href="/">
              
              </a> */}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CallToActionSection;
