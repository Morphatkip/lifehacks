import React from "react";
import "../../assets/css/main.css";
const ServicesSection = () => {
  return (
    <section id="services" className="services">
      <div className="container section-title" data-aos="fade-up">
        <h2>Services</h2>
        <p>
          Experience seamless credit sales management, comprehensive sales
          summaries, profit and loss analysis, and expense tracking with our
          advanced system
        </p>
      </div>
      <div className="container">
        <div className="row gy-4">
          <div className="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <div className="service-item d-flex">
              <div className="icon flex-shrink-0">
                <i className="bi bi-briefcase"></i>
              </div>
              <div>
                <h4 className="title">
                  <a href="services-details.html" className="stretched-link">
                    Credit Sales Management
                  </a>
                </h4>
                <p className="description">
                  Allow customers to make purchases on credit, and manage their
                  credit accounts within the system. This includes tracking
                  credit limits, outstanding balances, payment due dates, and
                  generating invoices for credit sales
                </p>
              </div>
            </div>
          </div>
          <div className="col-lg-6" data-aos="fade-up" data-aos-delay="200">
            <div className="service-item d-flex">
              <div className="icon flex-shrink-0">
                <i className="bi bi-card-checklist"></i>
              </div>
              <div>
                <h4 className="title">
                  <a href="services-details.html" className="stretched-link">
                    Sales Summary
                  </a>
                </h4>
                <p className="description">
                  Provide a comprehensive summary of sales data, such as daily,
                  weekly, monthly, or yearly sales reports. This includes
                  information on total sales revenue, the number of
                  transactions, average transaction value, and any applicable
                  taxes.
                </p>
              </div>
            </div>
          </div>
          <div className="col-lg-6" data-aos="fade-up" data-aos-delay="300">
            <div className="service-item d-flex">
              <div className="icon flex-shrink-0">
                <i className="bi bi-bar-chart"></i>
              </div>
              <div>
                <h4 className="title">
                  <a href="services-details.html" className="stretched-link">
                    Profit and Loss Analysis
                  </a>
                </h4>
                <p className="description">
                  Calculate and display the profitability of your business by
                  analyzing the revenue generated from sales and deducting the
                  associated costs, including inventory, operating expenses, and
                  any other relevant costs. This helps you understand the
                  financial health of your business
                </p>
              </div>
            </div>
          </div>
          <div className="col-lg-6" data-aos="fade-up" data-aos-delay="400">
            <div className="service-item d-flex">
              <div className="icon flex-shrink-0">
                <i className="bi bi-binoculars"></i>
              </div>
              <div>
                <h4 className="title">
                  <a href="services-details.html" className="stretched-link">
                    Expense Management
                  </a>
                </h4>
                <p className="description">
                  Enable tracking and management of various expenses incurred in
                  your business operations. This can include categorizing
                  expenses (e.g., inventory costs, rent, utilities, employee
                  salaries) and generating expense reports to assess the overall
                  expenditure.
                </p>
              </div>
            </div>
          </div>
          <div className="col-lg-6" data-aos="fade-up" data-aos-delay="500">
            <div className="service-item d-flex">
              <div className="icon flex-shrink-0">
                <i className="bi bi-brightness-high"></i>
              </div>
              <div>
                <h4 className="title">
                  <a href="services-details.html" className="stretched-link">
                    Inventory Management
                  </a>
                </h4>
                <p className="description">
                  Integrate an inventory management system to track and control
                  the stock levels of your products. This allows you to monitor
                  the availability of items, automate reordering processes, and
                  receive alerts for low stock or out-of-stock items.
                </p>
              </div>
            </div>
          </div>
          <div className="col-lg-6" data-aos="fade-up" data-aos-delay="600">
            <div className="service-item d-flex">
              <div className="icon flex-shrink-0">
                <i className="bi bi-calendar4-week"></i>
              </div>
              <div>
                <h4 className="title">
                  <a href="services-details.html" className="stretched-link">
                    Customer Relationship Management (CRM)
                  </a>
                </h4>
                <p className="description">
                  Implement a CRM module to store and organize customer data,
                  including contact details, purchase history, and loyalty
                  program information. This allows you to better understand your
                  customers and personalize their shopping experiences.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
