import React from "react";
import heroBg from "../../assets/img/hero-bg.jpg";

import "../../assets/css/main.css";
const HeroSection = () => {
  return (
    <>
      <section id="hero" className="hero">
        <img src={heroBg} alt="" data-aos="fade-in" />

        <div className="container">
          <div className="row">
            <div className="col-lg-10">
              <h2 data-aos="fade-up" data-aos-delay="100">
                Welcome
              </h2>
              <p data-aos="fade-up" data-aos-delay="200">
                We provide advanced solutions for businesses, empowering
                streamlined operations, enhanced customer experiences, and
                growth. With tailored systems, intuitive interfaces, and
                exceptional support, we optimize efficiency and help businesses
                stay ahead in a competitive market.
              </p>
            </div>
            {/*   <div className="col-lg-5">
              <form
                action="#"
                className="sign-up-form d-flex"
                data-aos="fade-up"
                data-aos-delay="300"
              >
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter email address"
                />
                <input
                  type="submit"
                  className="btn btn-primary"
                  value="Sign up"
                />
              </form>
            </div> */}
          </div>
        </div>
      </section>

      {/*    <section id="clients" className="clients">
        <div className="container-fluid" data-aos="fade-up">
          <div className="row gy-4">
            <div className="col-xl-2 col-md-3 col-6 client-logo">
              <img src={greenZone} className="img-fluid" alt="" />
            </div>
            <div className="col-xl-2 col-md-3 col-6 client-logo">
              <img
                src={require("../../assets/img/clients/client-2.png").default}
                className="img-fluid"
                alt=""
              />
            </div>
            <div className="col-xl-2 col-md-3 col-6 client-logo">
              <img
                src={require("../../assets/img/clients/client-3.png").default}
                className="img-fluid"
                alt=""
              />
            </div>
            <div className="col-xl-2 col-md-3 col-6 client-logo">
              <img
                src={require("../../assets/img/clients/client-4.png").default}
                className="img-fluid"
                alt=""
              />
            </div>
            <div className="col-xl-2 col-md-3 col-6 client-logo">
              <img
                src={require("../../assets/img/clients/client-5.png").default}
                className="img-fluid"
                alt=""
              />
            </div>
            <div className="col-xl-2 col-md-3 col-6 client-logo">
              <img
                src={require("../../assets/img/clients/client-6.png").default}
                className="img-fluid"
                alt=""
              />
            </div>
          </div>
        </div>
      </section> */}
    </>
  );
};

export default HeroSection;
