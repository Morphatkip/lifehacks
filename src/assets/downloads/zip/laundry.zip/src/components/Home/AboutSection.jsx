import React from "react";
import "../../assets/css/main.css";
const AboutSection = () => {
  return (
    <section id="about" className="about">
      <div className="container" data-aos="fade-up" data-aos-delay="100">
        <div className="row align-items-xl-center gy-5">
          <div className="col-xl-5 content">
            <h3>About Us</h3>
            <h2>We lead with freedom, reproach, and everything</h2>
            <p>
              We provide advanced point-of-sale (POS) solutions for businesses,
              empowering streamlined operations, enhanced customer experiences,
              and growth. With tailored systems, intuitive interfaces, and
              exceptional support, we optimize efficiency and help businesses
              stay ahead in a competitive market.
            </p>
            <a href="/" className="read-more">
              <span>Read More</span>
              <i className="bi bi-arrow-right"></i>
            </a>
          </div>
          <div className="col-xl-7">
            <div className="row gy-4 icon-boxes">
              <div className="col-md-6" data-aos="fade-up" data-aos-delay="200">
                <div className="icon-box">
                  <i className="bi bi-buildings"></i>
                  <h3>User-Friendly</h3>
                  <p>
                    Our system is designed with simplicity in mind, making it
                    easy to navigate and operate with minimal training required.
                  </p>
                </div>
              </div>
              <div className="col-md-6" data-aos="fade-up" data-aos-delay="300">
                <div className="icon-box">
                  <i className="bi bi-clipboard-pulse"></i>
                  <h3>Efficient</h3>
                  <p>
                    Streamline your checkout process with automated
                    calculations, accurate receipts, and fast payment
                    processing, reducing waiting times and boosting customer
                    satisfaction.
                  </p>
                </div>
              </div>
              <div className="col-md-6" data-aos="fade-up" data-aos-delay="400">
                <div className="icon-box">
                  <i className="bi bi-command"></i>
                  <h3>Actionable Sales Insights</h3>
                  <p>
                    Unlock the power of comprehensive sales reports and
                    analytics, empowering you with valuable data on sales
                    trends, top-selling products, and customer behavior to make
                    informed decisions and drive growth.
                  </p>
                </div>
              </div>
              <div className="col-md-6" data-aos="fade-up" data-aos-delay="500">
                <div className="icon-box">
                  <i className="bi bi-graph-up-arrow"></i>
                  <h3>Scalable for Growth</h3>
                  <p>
                    Our system offers flexibility and scalability, enabling you
                    to expand to multiple locations and handle increasing
                    transaction volumes with ease
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
