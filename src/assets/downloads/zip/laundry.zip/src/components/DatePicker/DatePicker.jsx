import React, { useState } from "react";
import "react-datetime/css/react-datetime.css";
import moment from "moment/moment";
import "../../Styles/Summary/DatePicker.css";
import { useEffect } from "react";
import "react-date-range/dist/styles.css"; // main style file
import "react-date-range/dist/theme/default.css"; // theme css file
import UseModal from "../Modal/UseModal";
import Title from "../title/Title";
import PickDateModal from "./PickDateModal";
import { Frame } from "./Frame";
function DatePicker() {
  const [order, setOrder] = useState([]);
  const [sales, setSales] = useState([]);
  const [isOrderFetched, setIsOrderFetched] = useState(false);
  const [selectionRange, setSelectionRange] = useState({
    startDate: moment().startOf("day").toDate(),
    endDate: new Date(),
    key: "selection",
  });
  const { isShowingPickDate, togglePickDate } = UseModal();
  const [totalSales, setTotalSales] = useState(0);

  const getAllOrders = async () => {
    try {
      const orders = await window.electron.getAllOrders();
      setOrder(orders);
      setSales(orders);
      setIsOrderFetched(true);
      console.log(orders);
    } catch (error) {
      console.log(error);
    }
  };

  const filterOrder = () => {
    const tempOrder = order.filter((sale) =>
      moment(new Date(sale.orderDate)).isBetween(
        moment(selectionRange.startDate),
        moment(selectionRange.endDate),
        "day",
        "[]"
      )
    );

    setSales(tempOrder);

    const totalSum = tempOrder.reduce(
      (accumulator, currentItem) => accumulator + currentItem.totalPrice,
      0
    );

    setTotalSales(totalSum);
  };

  useEffect(() => {
    getAllOrders();
    // eslint-disable-next-line
  }, []);

  useEffect(() => {
    filterOrder();

    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectionRange, isOrderFetched, order]);

  const handleClick = () => {
    togglePickDate();
  };
  return (
    <div className="container mt-3">
      <div className="side-container">
        <div>
          <Title showBtn handleClick={handleClick} />
        </div>
      </div>

      <div className="card w-100 p3">
        {isShowingPickDate ? (
          <PickDateModal
            hide={togglePickDate}
            selectionRange={selectionRange}
            setSelectionRange={setSelectionRange}
          />
        ) : null}
      </div>
      <div className="w-100 p-3 mt-4">
        <b> Cash Sales</b>
        <table className="table table-hover p-3">
          <thead className="bg-light">
            <tr>
              <th>Order Number</th>
              <th>Customer Name</th>
              <th>Date</th>
              <th>Status</th>
              <th>Total</th>
            </tr>
          </thead>

          <tbody className="">
            {sales?.map((product) => (
              <Frame productPurchased={product} key={product.id} />
            ))}

            <tr>
              <td>
                <b>Total</b>
              </td>
              <td></td>
              <td></td>
              <td></td>
              <td>
                <b style={{ color: "red" }}>$ {totalSales}</b>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default DatePicker;
