import React from "react";

function ExpenseFrame({ expense }) {
  // Format the date to a readable string
  const formattedDate = new Date(expense.dateIncurred).toLocaleDateString();

  return (
    <tr>
      <td>{expense.expenseName}</td>
      <td>{formattedDate}</td>
      <td>{expense.amount}</td>
    </tr>
  );
}

export default ExpenseFrame;
