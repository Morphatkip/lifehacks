import React from "react";

function Frame({ productPurchased }) {
  return (
    <>
      <tr>
        <td>#{productPurchased?.id} </td>
        <td>{productPurchased?.User?.name}</td>

        <td>{new Date(productPurchased.orderDate).toLocaleDateString()} </td>
        <td>{productPurchased.status} </td>
        <td>$ {productPurchased.totalPrice}</td>
      </tr>
    </>
  );
}

function CreditFrame({ productPurchased }) {
  return (
    <>
      {Object.values(productPurchased?.productPurchased)?.map((prdPurch) => (
        <tr>
          <td>{productPurchased?.buyersName}</td>
          <td>{productPurchased?.totalAmount}</td>
          <td>{productPurchased?.initialDeposit}</td>
          <td>
            {parseInt(productPurchased?.totalAmount) -
              parseInt(productPurchased?.initialDeposit)}
          </td>
        </tr>
      ))}
    </>
  );
}

function DebtorsFrame({ order, toggleShowCreditorsItem }) {
  const handleEditCreditor = (e) => {
    e.preventDefault();
    toggleShowCreditorsItem(order);
  };
  return (
    <>
      <tr onClick={handleEditCreditor}>
        <td>{order?.id}</td>
        <td>{order?.User?.name}</td>
        <td>{order?.totalPrice - (order?.Payment?.amount ?? 0)}</td>
        <td>{order?.Payment?.amount ?? 0}</td>
      </tr>
    </>
  );
}

function FrameEditDebtor({ orderItem }) {
  return (
    <tr>
      <td>{orderItem?.serviceName}</td>
      <td>{orderItem?.OrderItem?.quantity}</td>
      <td>{orderItem?.OrderItem?.price}</td>

      <td>
        $ {}
        {parseInt(orderItem?.OrderItem?.quantity) *
          parseInt(orderItem?.OrderItem?.price)}
      </td>
    </tr>
  );
}

export { Frame, CreditFrame, DebtorsFrame, FrameEditDebtor };
