import React, { useState } from "react";
import ReactDOM from "react-dom";
import "../../Styles/Modal.css";
import "../../Styles/Summary.css";
import { showNotification } from "../../Utils/notification.util";
import ModalComponent from "./ModalComponent";

const Modal = ({ isShowingAdd, hide, updateData: refresh }) => {
  const [service, setService] = useState({
    serviceName: "",
    description: "",
    price: 0,
    duration: 0,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setService((prevService) => ({
      ...prevService,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (window.electron && window.electron.addService) {
      try {
        const response = await window.electron.addService(service);

        if (response && response.dataValues) {
          showNotification("Service added successfully", "success");
          refresh();
        } else {
          showNotification("Failed to add service", "error");
        }
      } catch (error) {
        console.error("Failed to add service:", error);
        showNotification("An error occurred while adding the service", "error");
      }
    } else {
      console.error("Electron addService method is not defined.");
    }
    hide();
  };

  const handleClose = () => {
    hide();
  };

  return isShowingAdd
    ? ReactDOM.createPortal(
        <React.Fragment>
          <ModalComponent
            handleClose={handleClose}
            handleSave={handleSubmit}
            btnTitle="Save"
            title={"Add Service"}
          >
            <form onSubmit={handleSubmit}>
              <div className="row">
                <div className="col-12 my-2">
                  <label className="col-sm-7">Service Name*</label>
                  <div className="col-12">
                    <input
                      className="form-control"
                      type="text"
                      onChange={handleChange}
                      name="serviceName"
                      value={service.serviceName}
                      required
                    />
                  </div>
                </div>

                <div className="col-12 my-2">
                  <label className="col-sm-7">Description</label>
                  <div className="col-12">
                    <input
                      className="form-control"
                      type="text"
                      onChange={handleChange}
                      name="description"
                      value={service.description}
                    />
                  </div>
                </div>

                <div className="col-6 my-2">
                  <label className="col-sm-7">Price*</label>
                  <div className="col-12">
                    <input
                      className="form-control"
                      type="number"
                      onChange={handleChange}
                      name="price"
                      value={service.price}
                      required
                    />
                  </div>
                </div>

                <div className="col-6 my-2">
                  <label className="col-sm-7">Duration (minutes)</label>
                  <div className="col-12">
                    <input
                      className="form-control"
                      type="number"
                      onChange={handleChange}
                      name="duration"
                      value={service.duration}
                    />
                  </div>
                </div>
              </div>
            </form>
          </ModalComponent>
        </React.Fragment>,
        document.body
      )
    : null;
};

export default Modal;
