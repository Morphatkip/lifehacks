import React from "react";
import ModalComponent from "./ModalComponent";

function EditUserModal({
  togggleEditUser,
  isShowingEditUser,
  isShowingEditPassword,
  set,
}) {
  return (
    isShowingEditUser && (
      <ModalComponent>
        <form onSubmit={handleSubmit}>
          <div className="container">
            <div className="row">
              <div className="col-md-6">
                <div className="form-group">
                  <label>Display name</label>
                  <input
                    className="form-control"
                    type="text"
                    onChange={handleChange}
                    name="displayName"
                    value={productEdited.displayName}
                  />
                </div>
              </div>
            </div>
          </div>
        </form>
      </ModalComponent>
    )
  );
}

export default EditUserModal;
