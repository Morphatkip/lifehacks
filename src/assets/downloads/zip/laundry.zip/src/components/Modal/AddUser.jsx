import React from "react";
import { useState } from "react";
import "../../Styles/Modal.css";
import "../../Styles/Summary.css";
import ReactDOM from "react-dom";
import { useNavigate } from "react-router-dom";
import ModalComponent from "../Modal/ModalComponent";
import { showNotification } from "../../Utils/notification.util";
const AddUser = ({ isShowingAddUser, hide, business }) => {
  const navigate = useNavigate();
  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    address: "",
    password: "user",
    phone_number: "",
    role: "USER",
  });
  const [showPassword, setShowPassword] = useState(false);

  const handleChange = (e) => {
    e.preventDefault();
    const value = e.target.value;

    setNewUser({
      ...newUser,
      [e.target.name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await window.electron.createUser(newUser);

      if (response.success) {
        showNotification("User created successfully!", "success");
        hide(); // Close the modal after success
      } else {
        showNotification(response.message || "Failed to create user", "danger");
      }
    } catch (error) {
      console.error("Error creating user:", error);
      showNotification(error, "danger");
    }
  };

  const handleClose = () => {
    hide();
  };
  return isShowingAddUser
    ? ReactDOM.createPortal(
        <React.Fragment>
          <ModalComponent
            handleClose={handleClose}
            handleSave={handleSubmit}
            btnTitle="Save"
            title={"Add User"}
          >
            <form onSubmit={handleSubmit}>
              <div className="row">
                <div className="col-6">
                  <div className="col-12 my-2">
                    <label htmlFor="" className="col-sm-8">
                      Full name
                    </label>
                    <div className="col-12">
                      <input
                        className="form-control"
                        type="text"
                        value={newUser.name}
                        name="name"
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                </div>
                <div className="col-6">
                  <div className="col-12 my-2">
                    <label htmlFor="" className="col-sm-12">
                      Email
                    </label>
                    <div className="col-12">
                      <input
                        className="form-control"
                        type="text"
                        value={newUser.email}
                        name="email"
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="row">
                <div className="col-6">
                  <div className="col-12 my-2">
                    <label htmlFor="" className="col-sm-12">
                      Phone Number
                    </label>
                    <div className="col-12">
                      <input
                        className="form-control"
                        type="text"
                        value={newUser.phone_number}
                        name="phone_number"
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                </div>

                <div className="col-6">
                  <div className="col-12 my-2">
                    <label htmlFor="" className="col-sm-12">
                      Address
                    </label>
                    <div className="col-12">
                      <input
                        className="form-control"
                        type="text"
                        value={newUser.address}
                        name="address"
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </ModalComponent>
        </React.Fragment>,
        document.body
      )
    : null;
};

export default AddUser;
