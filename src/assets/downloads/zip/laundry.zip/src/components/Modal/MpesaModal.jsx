import React from "react";
import ModalComponent from "./ModalComponent";

function MpesaModal({
  toggleMpesaPayment,
  isShowingMpesaPayment,
  matchedTransaction,
  handleMpesaPayment,
}) {
  return isShowingMpesaPayment ? (
    <div style={{ zIndex: 1000 }}>
      <ModalComponent
        handleClose={toggleMpesaPayment}
        handleSave={handleMpesaPayment}
        title="Confirm payment"
        btnTitle="Confirm"
      >
        <div className="d-flex flex-column align-content-centre ">
          <div>
            {" "}
            name : {matchedTransaction?.firstName}
            {matchedTransaction?.middleName}
          </div>
          <div>amount: {matchedTransaction?.transAmount}</div>
        </div>
      </ModalComponent>
    </div>
  ) : null;
}

export default MpesaModal;
