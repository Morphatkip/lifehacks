import React from "react";
import ReactDOM from "react-dom";
import "../../Styles/Modal.css";
import "../../Styles/Summary.css";
import ModalComponent from "./ModalComponent";
import { showNotification } from "../../Utils/notification.util";
function DeleteModal({
  isShowingDelete,
  id,
  hide,
  fetchProducts: refresh,
}) {

 

    // Handle the delete action
    const handleDelete = async (e) => {
      e.preventDefault();
  
      try {
        // Call the deleteService function (from Electron's contextBridge)
        const result = await window.electron.deleteService(id);
  
        if (result.success) {
          showNotification( "Service deleted successfully.","success");
          refresh();  // Refresh the product list after successful deletion
        } else {
          showNotification("error", result.message || "Failed to delete service.");
        }
      } catch (error) {
        showNotification("error", "An error occurred while deleting the service.");
        
      }
  
      hide();  // Close the modal after the delete action
    };
  const handleClose = () => {
    hide();
  };
  return isShowingDelete
    ? ReactDOM.createPortal(
        <React.Fragment>
          <ModalComponent
            handleSave={handleDelete}
            title="Are you sure you want to delete this product?"
            handleClose={handleClose}
            btnTitle="Delete"
          ></ModalComponent>
        </React.Fragment>,
        document.body
      )
    : null;
}

export default DeleteModal;
