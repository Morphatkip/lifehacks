import { useState } from "react";
const UseModal = () => {
  const [isShowingAdd, setIsShowingAdd] = useState(false);
  const [isShowingSale, setIsShowingSale] = useState(false);
  const [isShowingEdit, setIsShowingEdit] = useState(false);
  const [isShowingDelete, setIsShowingDelete] = useState(false);
  const [isShowingAddUser, setIsShowingAddUser] = useState(false);
  const [isShowingAddExpense, setIsShowingAddEpense] = useState(false);
  const [isShowingPickDate, setIsShowingPickDate] = useState(false);
  const [isShowingAddPayment, setIsShowingAddPayment] = useState(false);
  const [isShowingPayment, setIsShowingPayment] = useState(false);
  const [isShowingMpesaPayment, setIsShowingMpesaPayment] = useState(false);
  const [isShowingEditUser, setIsShowingEditUser] = useState(false);
  const [isShowingConfirmation, setIsShowingConfirmation] = useState(false);
  function togglePickDate() {
    setIsShowingPickDate(!isShowingPickDate);
  }
  function toggleAdd() {
    setIsShowingAdd(!isShowingAdd);
  }
  function toggleSale() {
    setIsShowingSale(!isShowingSale);
  }

  function toggleEdit() {
    setIsShowingEdit(!isShowingEdit);
  }

  function toggleDelete() {
    setIsShowingDelete(!isShowingDelete);
  }
  function toggleAddUser() {
    setIsShowingAddUser(!isShowingAddUser);
  }
  function toggleAddExpenses() {
    setIsShowingAddEpense(!isShowingAddExpense);
  }
  function toggleAddPayment() {
    setIsShowingAddPayment(!isShowingAddPayment);
  }
  function togglePayment() {
    setIsShowingPayment(!isShowingPayment);
  }

  function toggleMpesaPayment() {
    setIsShowingMpesaPayment(!isShowingMpesaPayment);
  }
  function togggleEditUser() {
    setIsShowingEditUser(!isShowingEditUser);
  }
  function toggleConfirmation() {
    setIsShowingConfirmation(!isShowingConfirmation);
  }
  return {
    isShowingAdd,
    toggleAdd,
    isShowingSale,
    toggleSale,
    isShowingEdit,
    toggleEdit,
    isShowingDelete,
    toggleDelete,
    isShowingAddUser,
    toggleAddUser,
    toggleAddExpenses,
    isShowingAddExpense,
    togglePickDate,
    isShowingPickDate,
    toggleAddPayment,
    isShowingAddPayment,
    togglePayment,
    isShowingPayment,
    toggleMpesaPayment,
    isShowingMpesaPayment,
    togggleEditUser,
    isShowingEditUser,
    toggleConfirmation,
    isShowingConfirmation,
  };
};
export default UseModal;
