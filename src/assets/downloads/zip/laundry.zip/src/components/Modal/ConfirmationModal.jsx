import React from "react";
import ReactDOM from "react-dom";
import "../../Styles/Modal.css";
import "../../Styles/Summary.css";
import ModalComponent from "./ModalComponent";
function ConfirmationModal({
  toggleConfirmation,
  isShowingConfirmation,
  handleConfirmation,
  title,
  btnName,
}) {
  const handleClose = () => {
    toggleConfirmation(!isShowingConfirmation);
  };
  return isShowingConfirmation
    ? ReactDOM.createPortal(
        <React.Fragment>
          <ModalComponent
            handleSave={handleConfirmation}
            title={title}
            handleClose={handleClose}
            btnTitle={btnName}
          ></ModalComponent>
        </React.Fragment>,
        document.body
      )
    : null;
}

export default ConfirmationModal;
