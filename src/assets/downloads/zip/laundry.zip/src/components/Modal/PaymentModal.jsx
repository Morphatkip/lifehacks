import React from "react";
import { useState } from "react";
import ModalComponent from "./ModalComponent";
import Switch from "react-switch";

function PaymentModal({
  togglePayment,
  isShowingPayment,
  total,
  change,
  setDiscount,
  setAmountPaid,
  handleCustomerChange,
  isInvoice,
  customer,
  handleSave,
  customers,
  setCustomer,
  setOrderData,
}) {
  const [deposit, setDeposit] = useState(false);
  const handleToggle = () => {
    setDeposit(!deposit);
  };
  const [searchQuery, setSearchQuery] = useState("");
  const [searchCustomer, setSerchcustomer] = useState("");

  return isShowingPayment ? (
    <React.Fragment>
      <ModalComponent
        handleClose={togglePayment}
        handleSave={togglePayment}
        title={"Payment"}
        btnTitle={"Save"}
      >
        {isInvoice ? (
          <>
            {" "}
            <div className="container">
              <div className="d-flex justify-content-between ">
                <input
                  type="text"
                  name="name"
                  value={customer?.name}
                  onChange={handleCustomerChange}
                  placeholder="Name"
                  className="form-control m-2"
                />
                {searchQuery && customers.length > 0 && (
                  <div className="supplier-list-container">
                    <table className="">
                      <tbody>
                        {customers.map((customer) => (
                          <tr
                            onClick={() => setCustomer(customer.dataValues)}
                            key={customer.dataValues.id}
                            className="product-list-item d-flex "
                          >
                            <td className="product-data">
                              {customer.dataValues.name}
                            </td>
                            <td className="product-data">
                              {customer.dataValues.phoneNumber}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
                <input
                  type="text"
                  name="address"
                  value={customer?.address}
                  onChange={handleCustomerChange}
                  placeholder="Address"
                  className="form-control m-2"
                />
                []
              </div>
              <div className="d-flex justify-content-between">
                <input
                  type="text"
                  name="phoneNumber"
                  value={customer?.phoneNumber}
                  onChange={handleCustomerChange}
                  placeholder="Phone Number"
                  className="form-control m-2"
                />
                {/*  <input
                  type="number"
                  name="identityCardNumber"
                  value={customer?.identityCardNumber}
                  onChange={handleCustomerChange}
                  placeholder="Identity Card Number"
                  className="form-control m-2"
                  required
                /> */}
              </div>
              <div className="col-md-8 mx-auto border p-3">
                <div className="d-flex justify-content-between align-items-center">
                  <label className="mr-2">First Payment Details</label>
                  <Switch
                    checked={deposit}
                    onChange={handleToggle} // Use the local handleToggle function as the onChange event handler
                    onColor="#86d3ff" // Customize the color when the slider is on
                    offColor="#dddddd" // Customize the color when the slider is off
                    onHandleColor="#2693e6" // Customize the color of the slider handle when it is on
                    offHandleColor="#ff0000" // Customize the color of the slider handle when it is off
                    handleDiameter={20}
                    uncheckedIcon={false}
                    checkedIcon={false}
                    height={15}
                    width={40}
                  />
                </div>
              </div>
              {deposit && (
                <div className="container">
                  <div className="row m-3 fw-bold">
                    {/* <label className="col-md-4 mx-auto">
                      Total: <label>{total.toLocaleString()}</label>
                    </label>
                    <label className="col-md-5 mx-auto">
                      Change: <label>{change.toLocaleString()}</label>
                    </label> */}
                  </div>

                  <div className="row m-3">
                    <label className="col-md-4">Cash</label>
                    <span className="col-md-8">
                      <input
                        className="form-control "
                        type="number"
                        onChange={(e) => setAmountPaid(e.target.value)}
                      />
                    </span>
                  </div>
                  <div className="row m-3">
                    <label className="col-md-4">Mpesa</label>
                    <span className="col-md-8">
                      <input className="form-control " />
                    </span>
                  </div>
                  <div className="row m-3">
                    <label className="col-md-4">Discount</label>
                    <span className="col-md-8">
                      <input
                        className="form-control "
                        type="number "
                        onChange={(e) => {
                          setDiscount(e.target.value);
                        }}
                      />
                    </span>
                  </div>
                </div>
              )}
            </div>
          </>
        ) : (
          <>
            <div className="container">
              <div className="row m-3 fw-bold">
                {/*  <label className="col-md-4 mx-auto">
                  Total: <label>{total.toLocaleString()}</label>
                </label>
                <label className="col-md-5 mx-auto">
                  Change: <label>{change.toLocaleString()}</label>
                </label> */}
              </div>
              <div className="d-flex justify-content-between ">
                <input
                  type="text"
                  name="name"
                  value={customer?.name}
                  onChange={handleCustomerChange}
                  placeholder="Name"
                  className="form-control m-2"
                />
                {searchQuery && customers.length > 0 && (
                  <div className="supplier-list-container">
                    <table className="">
                      <tbody>
                        {customers.map((customer) => (
                          <tr
                            onClick={() => setCustomer(customer.dataValues)}
                            key={customer.dataValues.id}
                            className="product-list-item d-flex "
                          >
                            <td className="product-data">
                              {customer.dataValues.name}
                            </td>
                            <td className="product-data">
                              {customer.dataValues.phoneNumber}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
                <input
                  type="text"
                  name="address"
                  value={customer?.address}
                  onChange={handleCustomerChange}
                  placeholder="Address"
                  className="form-control m-2"
                />
              </div>
              <div className="d-flex justify-content-between">
                <input
                  type="text"
                  name="phoneNumber"
                  value={customer?.phoneNumber}
                  onChange={handleCustomerChange}
                  placeholder="Phone Number"
                  className="form-control m-2"
                />
                {/*  <input
                  type="number"
                  name="identityCardNumber"
                  value={customer?.identityCardNumber}
                  onChange={handleCustomerChange}
                  placeholder="Identity Card Number"
                  className="form-control m-2"
                  required
                /> */}
              </div>
              <div className="row m-3">
                <label className="col-md-4">Cash</label>
                <span className="col-md-8">
                  <input
                    className="form-control "
                    type="number"
                    name="totalPrice"
                    onChange={(e) => setAmountPaid(e.target.value)}
                  />
                </span>
              </div>

              <div className="row m-3">
                <label className="col-md-4">Discount</label>
                <span className="col-md-8">
                  <input
                    className="form-control "
                    type="number "
                    /*  onChange={(e) => {
                      setDiscount(e.target.value);
                    }} */
                  />
                </span>
              </div>
            </div>
          </>
        )}
      </ModalComponent>
    </React.Fragment>
  ) : null;
}

export default PaymentModal;
