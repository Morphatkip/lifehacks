import React, { useState, useEffect } from "react";
import ReactDOM from "react-dom";
import "../../Styles/Modal.css";
import "../../Styles/Summary.css";

import ModalComponent from "./ModalComponent";
import { showNotification } from "../../Utils/notification.util";

const EditModal = ({ hide, product, fetchProducts: refresh, goBack }) => {
  // Extract product values from Sequelize's dataValues
  const initialProduct = product?.dataValues ? { ...product.dataValues } : {};

  // State to manage edited service
  const [productEdited, setProductEdited] = useState(initialProduct);

  useEffect(() => {
    if (product?.dataValues) {
      setProductEdited({ ...product.dataValues });
    }
  }, [product]);

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setProductEdited((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Send update request to backend
      await window.electron.updateService(productEdited.id, productEdited);

      // Refresh product list & close modal
      refresh();
      hide();
      showNotification("Service updated successfully!", "success");
    } catch (error) {
      showNotification("Error updating service!", "error");
      console.error("Update Service Error:", error);
    }
  };

  return ReactDOM.createPortal(
    <React.Fragment>
      <ModalComponent
        handleClose={hide}
        handleSave={handleSubmit}
        btnTitle="Save"
        title="Edit Service"
      >
        <form onSubmit={handleSubmit}>
          <div className="container">
            <div className="row">
              <div className="col-md-6">
                <div className="form-group">
                  <label>Service Name</label>
                  <input
                    className="form-control"
                    type="text"
                    name="serviceName"
                    value={productEdited.serviceName || ""}
                    onChange={handleChange}
                  />
                </div>

                <div className="form-group">
                  <label>Selling Price</label>
                  <input
                    type="number"
                    className="form-control"
                    name="price"
                    value={productEdited.price || ""}
                    onChange={handleChange}
                  />
                </div>
              </div>

              <div className="col-md-6">
                <div className="form-group">
                  <label>Description</label>
                  <input
                    type="text"
                    className="form-control"
                    name="description"
                    value={productEdited.description || ""}
                    onChange={handleChange}
                  />
                </div>

                <div className="form-group">
                  <label>Duration</label>
                  <input
                    type="number"
                    className="form-control"
                    name="duration"
                    value={productEdited.duration || ""}
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>
          </div>
        </form>
      </ModalComponent>
    </React.Fragment>,
    document.body
  );
};

export default EditModal;
