import React from "react";
import { showNotification } from "../../Utils/notification.util";
import { Link, useNavigate } from "react-router-dom";
import { useUser } from "../../Utils/UserContext";
import { Dropdown } from "bootstrap";
import { useState, useRef } from "react";
function TopBar() {
  const { user } = useUser();
  const navigate = useNavigate();

  const alertDropdownRef = useRef(null);
  const messageDropdownRef = useRef(null);
  const userDropdownRef = useRef(null);

  const toggleDropdown = (dropdownRef) => {
    if (dropdownRef.current) {
      const dropdown = new Dropdown(dropdownRef.current);
      dropdown.toggle();
    }
  };
  const logout = () => {
    navigate("/");
    window.location.reload();
  };

  return (
    <nav className="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow mr-5 ml-3">
      {/*   Sidebar Toggle (Topbar) */}

      <button
        id="sidebarToggleTop"
        className="btn btn-link d-md-none rounded-circle mr-3"
      >
        <i className="fa fa-bars"></i>
      </button>

      {/*   Topbar Search */}
      <form className="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
        <div className="input-group">
          <input
            type="text"
            className="form-control bg-light border-0 small"
            placeholder="Search for..."
            aria-label="Search"
            aria-describedby="basic-addon2"
          />
          <div className="input-group-append">
            <button className="btn btn-primary" type="button">
              <i className="fas fa-search fa-sm"></i>
            </button>
          </div>
        </div>
      </form>

      {/*   Topbar Navbar */}
      <ul className="navbar-nav ml-auto">
        {/* Alerts Dropdown */}
        <li className="nav-item dropdown no-arrow mx-1">
          <a
            className="nav-link dropdown-toggle"
            href="#"
            id="alertsDropdown"
            role="button"
            ref={alertDropdownRef}
            onClick={() => toggleDropdown(alertDropdownRef)}
            aria-haspopup="true"
          >
            <i className="fas fa-bell fa-fw"></i>
            <span className="badge badge-danger badge-counter">0</span>
          </a>
          <div
            className="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
            aria-labelledby="alertsDropdown"
          >
            <h6 className="dropdown-header">Alerts Center</h6>
            <a className="dropdown-item d-flex align-items-center" href="#">
              <div className="mr-3">
                <div className="icon-circle bg-primary">
                  <i className="fas fa-file-alt text-white"></i>
                </div>
              </div>
              <div>
                <span className="font-weight-bold">A new report is ready!</span>
              </div>
            </a>
          </div>
        </li>

        {/* Messages Dropdown */}
        <li className="nav-item dropdown no-arrow mx-1">
          <a
            className="nav-link dropdown-toggle"
            href="#"
            id="messagesDropdown"
            role="button"
            ref={messageDropdownRef}
            onClick={() => toggleDropdown(messageDropdownRef)}
            aria-haspopup="true"
          >
            <i className="fas fa-envelope fa-fw"></i>
            <span className="badge badge-danger badge-counter">0</span>
          </a>
          <div
            className="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
            aria-labelledby="messagesDropdown"
          >
            <h6 className="dropdown-header">Message Center</h6>
            <a className="dropdown-item d-flex align-items-center" href="#">
              <div className="dropdown-list-image mr-3">
                <img
                  className="rounded-circle"
                  src="img/undraw_profile_1.svg"
                  alt="..."
                />
              </div>
              <div>
                <span className="font-weight-bold">New message received!</span>
              </div>
            </a>
          </div>
        </li>

        <div className="topbar-divider d-none d-sm-block"></div>

        {/* User Info Dropdown */}
        <li className="nav-item dropdown no-arrow">
          <a
            className="nav-link dropdown-toggle"
            href="#"
            id="userDropdown"
            role="button"
            ref={userDropdownRef}
            onClick={() => toggleDropdown(userDropdownRef)}
            aria-haspopup="true"
          >
            <span className="mr-2 d-none d-lg-inline text-gray-600 small">
              {user?.firstName} {user?.lastName}
            </span>
            <i className="fas fa-user"></i>
          </a>
          <div
            className="dropdown-menu dropdown-menu-right shadow animated--grow-in"
            aria-labelledby="userDropdown"
          >
            <Link className="dropdown-item" to="/settings/account">
              <i className="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
              Profile
            </Link>
            <Link className="dropdown-item" to="/settings/business-profile">
              <i className="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
              Settings
            </Link>
            <a className="dropdown-item" href="#">
              <i className="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
              Activity Log
            </a>
            <div className="dropdown-divider"></div>
            <a className="dropdown-item" onClick={logout} href="#">
              <i className="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
              Logout
            </a>
          </div>
        </li>
      </ul>
    </nav>
  );
}

export default TopBar;
