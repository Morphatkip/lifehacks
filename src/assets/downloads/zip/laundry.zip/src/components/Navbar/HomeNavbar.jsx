import React from "react";
import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import "../../assets/css/main.css";
import vinsateLogo from "../../assets/img/vinsate Logo.png";

function HomeNavbar({ scrollToSection }) {
  const [isMobileNavActive, setIsMobileNavActive] = useState(false);
  const location = useLocation();

  const toggleMobileNav = () => {
    setIsMobileNavActive((prevState) => !prevState);
  };

  const handleNavmenuClick = (elementId) => {
    scrollToSection(elementId);
    setIsMobileNavActive(false);
  };

  useEffect(() => {
    setIsMobileNavActive(false);
  }, [location]);

  return (
    <header
      id="header"
      className={`header fixed-top d-flex align-items-center rounded m-2 ${
        isMobileNavActive ? "mobile-nav-active" : ""
      }`}
    >
      <div className="container-fluid d-flex align-items-center justify-content-between rounded bg-dark">
        <Link to="/" className="logo d-flex align-items-center me-auto me-xl-0">
          <img src={vinsateLogo} alt="" />
          <h1>Vinsate</h1>
          <span>.</span>
        </Link>

        {/* Nav Menu */}
        <nav
          id="navmenu"
          className={`navmenu ${isMobileNavActive ? "z-index" : ""}`}
        >
          <ul>
            <li>
              <Link
                to="/"
                className={location.pathname === "/" ? "active" : ""}
                onClick={() => handleNavmenuClick("hero")}
              >
                Home
              </Link>
            </li>

            <li>
              <Link
                to="/services"
                className={location.pathname === "/services" ? "active" : ""}
                onClick={() => handleNavmenuClick("services")}
              >
                Services
              </Link>
            </li>
            <li>
              <Link
                to="/about"
                className={location.pathname === "/about" ? "active" : ""}
                onClick={() => handleNavmenuClick("about")}
              >
                About
              </Link>
            </li>

            {/*    <li>
              <Link
                to="/pricing"
                className={location.pathname === "/pricing" ? "active" : ""}
                onClick={() => handleNavmenuClick("pricing")}
              >
                Pricing
              </Link>
            </li>
            <li>
              <Link
                to="/team"
                className={location.pathname === "/team" ? "active" : ""}
                onClick={() => handleNavmenuClick("team")}
              >
                Team
              </Link>
            </li> */}
            <li>
              <Link
                to="/contact"
                className={location.pathname === "/contact" ? "active" : ""}
                onClick={() => handleNavmenuClick("contact")}
              >
                Contact
              </Link>
            </li>
            <li>
              <Link to="/login" onClick={handleNavmenuClick}>
                Login
              </Link>
            </li>
            <li>
              <Link to="/register" onClick={handleNavmenuClick}>
                Register
              </Link>
            </li>
          </ul>

          <i
            className="mobile-nav-toggle d-xl-none bi bi-list"
            onClick={toggleMobileNav}
          />
        </nav>
        {/* End Nav Menu */}
      </div>
    </header>
  );
}

export default HomeNavbar;
