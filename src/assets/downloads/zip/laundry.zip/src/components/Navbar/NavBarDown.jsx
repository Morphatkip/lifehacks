import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getCart, getRole, storeCart } from "../../Utils/local-storage";
import "../../Styles/Navbar.css";
import "../../Styles/Dashboard.css";
function NavBarDown({ cartLength }) {
  const branches = [
    { name: "Nakuru", value: "nakuru" },
    { name: "Kisumu", value: "kisumu" },
  ];

  return (
    <div className="navbar-light bg-light  d-flex justify-content-between align-items-center">
      <div className="text-center navbar-margin">
        <div className="form-group">
          {getRole() === "admin" ? (
            <select className="form-select">
              {branches.map((branch) => (
                <option key={branch.id} value={branch.value}>
                  {branch.name}
                </option>
              ))}
            </select>
          ) : (
            ""
          )}
        </div>
      </div>

      <div className="text-end navbar-margin">
        <div>
          <Link to="/cart " className="cart-link bg-success">
            <h1>
              <i className="bi bi-cart"></i>
              <sup>{cartLength}</sup>
            </h1>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default NavBarDown;
