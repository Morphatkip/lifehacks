import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { showNotification } from "../../Utils/notification.util";
import "../../Styles/Navbar.css";
import vinsateLogo from "../../assets/img/vinsate Logo.png";

function NavbarTop() {
  const navigate = useNavigate();
  const logout = () => {
    navigate("/");
    window.location.reload();
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light w-100">
      <ul className="navbar-nav d-flex justify-content-between w-100">
        <li className="nav-item">
          <Link className="navbar-brand mx-4" to="/">
            <img src={vinsateLogo} alt="" style={{ width: "30px" }} />
            Vinsate
          </Link>
        </li>

        <li className="nav-item">
          <div className="d-flex justify-content-end align-items-centre">
            {/*  <Link to="/cart " className="cart-link  ">
              <h1>
                <i className="bi bi-cart"></i>
                <sup>{cartLength}</sup>
              </h1>
            </Link> */}

            <button onClick={logout} className=" btn btn-light ms-3">
              Sign out
            </button>
          </div>
        </li>
      </ul>
    </nav>
  );
}

export default NavbarTop;
