import React from "react";
import CreditorsSubFrame from "./CreditorsSubFrame";

function CreditorsMainFrame({ productsList }) {
  return (
    <div>
      <div className="text-capitalize font-weight-bold">
        {productsList.buyersName}
      </div>
      <table className="table fw-bold ">
        <thead className="bg-muted">
          <tr>
            <th>{productsList.buyersName}</th>
            <th>{}</th>
            <th>Price</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody className="overflow-auto">
          {productsList?.productPurchased.map((ProductSold, index) => (
            <CreditorsSubFrame ProductSold={ProductSold} />
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default CreditorsMainFrame;
