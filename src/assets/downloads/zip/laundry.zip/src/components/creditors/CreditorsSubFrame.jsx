import React from "react";

function CreditorsSubFrame({ ProductSold }) {
  return (
    <tr>
      <td>{ProductSold.name}</td>
      <td>{ProductSold.quantity}</td>
      <td>{ProductSold.price}</td>
      <td>{parseInt(ProductSold.quantity) * parseInt(ProductSold.price)}</td>
    </tr>
  );
}

export default CreditorsSubFrame;
