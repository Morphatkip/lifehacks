import React from "react";
import { useState } from "react";
import { FrameEditDebtor } from "../DatePicker/Frame";
import Title from "../title/Title";
import Payment from "./payment/Payment";

function EditCreditor({
  toggleShowCreditorsItem,
  debtor,
  setShowCreditorsItems,
  fetchDebtorOrders,
}) {
  const [showPayment, setShowPayemnt] = useState(true);
  const handleBack = (e) => {
    e.preventDefault();
    toggleShowCreditorsItem();
  };
  const toggleShowPayment = () => {
    setShowPayemnt(!showPayment);
  };
  const handlePayment = () => {
    toggleShowPayment();
  };

  return (
    <>
      {showPayment ? (
        <div className="row">
          <div className="d-flex justify-content-start">
            <button onClick={handleBack} className=" btn btn-light">
              Back
            </button>
          </div>
          <div className="col-md-8 mx-auto border p-3">
            <Title
              name={debtor?.User?.name}
              btn
              btnName={"Make Payment"}
              handleClick={handlePayment}
            />

            <div className="conrtainer">
              <div className="m-4">
                <table className="table fw-bold">
                  <thead className="bg-muted">
                    <tr>
                      <th>Item</th>
                      <th>Quantity</th>
                      <th>Price</th>
                      <th>Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {debtor?.Services?.map((orderItem, index) => (
                      <FrameEditDebtor key={index} orderItem={orderItem} />
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <Payment
          toggleShowPayment={toggleShowPayment}
          debtor={debtor}
          setShowCreditorsItems={setShowCreditorsItems}
          fetchDebtorOrders={fetchDebtorOrders}
        />
      )}
    </>
  );
}

export default EditCreditor;
