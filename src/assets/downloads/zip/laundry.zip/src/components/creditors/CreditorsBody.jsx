import React, { useEffect } from "react";
import { useState } from "react";
import { DebtorsFrame } from "../DatePicker/Frame";
import EditCreditor from "./EditCreditor";

function CreditorsBody() {
  const [showCreditorsItem, setShowCreditorsItems] = useState(true);
  const [debtor, setDebtor] = useState({});
  const [debtOrders, setDebtOrders] = useState([]);

  const fetchDebtorOrders = async () => {
    try {
      const orders = await window.electron.getAllOrders();
      const debtors = orders.filter(
        (order) => order.Payment?.paymentStatus !== "Paid"
      );
      console.log(debtors);
      setDebtOrders(debtors);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchDebtorOrders();
  }, []);

  const toggleShowCreditorsItem = (debtorDetails) => {
    setShowCreditorsItems(!showCreditorsItem);
    setDebtor(debtorDetails);
  };

  return (
    <>
      {showCreditorsItem ? (
        <div className="h-100 container p-4">
          {debtOrders.length !== 0 ? (
            <>
              {/* Scrollable table wrapper */}
              <div
                className="table-responsive overflow-auto"
                style={{ maxHeight: "700px" }}
              >
                <table className="table m-4">
                  <thead>
                    <tr>
                      <th>Invoice number</th>
                      <th>Customer</th>
                      <th>Total Credit</th>
                      <th>Paid</th>
                    </tr>
                  </thead>
                  <tbody className="table-hover">
                    {debtOrders?.map((order) => (
                      <DebtorsFrame
                        key={order.id}
                        order={order}
                        toggleShowCreditorsItem={toggleShowCreditorsItem}
                      />
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          ) : (
            <div className="d-flex justify-content-center">
              <p>No debtors to Display</p>
            </div>
          )}
        </div>
      ) : (
        <EditCreditor
          toggleShowCreditorsItem={toggleShowCreditorsItem}
          debtor={debtor}
          setShowCreditorsItems={setShowCreditorsItems}
          fetchDebtorOrders={fetchDebtorOrders}
        />
      )}
    </>
  );
}

export default CreditorsBody;
