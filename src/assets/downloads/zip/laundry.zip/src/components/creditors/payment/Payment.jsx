import React, { useState } from "react";
import { showNotification } from "../../../Utils/notification.util";
import { useNavigate } from "react-router-dom";

function Payment({
  toggleShowPayment,
  debtor,
  setShowCreditorsItems,
  fetchDebtorOrders,
}) {
  const [payment, setPayment] = useState({ amount: 0 });

  const handleChange = (e) => {
    const { name, value } = e.target;
    const newValue = name === "amount" ? parseFloat(value) || 0 : value; // Handle NaN case
    setPayment({ ...payment, [name]: newValue });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Calculate new payment amount
    const currentPayment = debtor.Payment?.amount || 0;
    const newTotalPayment = currentPayment + payment.amount;

    // Determine new payment status
    const updatedPaymentStatus =
      newTotalPayment >= debtor.totalPrice ? "Completed" : "Pending";

    // Construct updated payment object
    const updatedPayment = {
      amount: newTotalPayment,
      paymentStatus: updatedPaymentStatus,
    };
    let orderId = debtor.id;
    try {
      // Use IPC to send the update request
      console.log(orderId);
      const response = await window.electron.updatePayment(
        orderId,
        updatedPayment
      );

      if (response.success) {
        showNotification("Payment Update Successfully", "success");
        // Close the payment modal
        setShowCreditorsItems(true);
        fetchDebtorOrders();
      } else {
        showNotification("Error", response.message, "error");
      }
    } catch (error) {
      console.error("Error updating payment:", error);
      /*  showNotification("Error", "Failed to update payment", "error"); */
    }
  };

  return (
    <div className="container">
      <div className="d-flex justify-content-start">
        <button onClick={toggleShowPayment} className="btn btn-light">
          Back
        </button>
      </div>
      <div className="row">
        <div className="col-md-8 mx-auto p-3">
          <h3>{debtor.customer?.name} Debt Payment</h3>
          <form onSubmit={handleSubmit}>
            <div className="form-group my-2">
              <label htmlFor="buyerName">Payment Amount</label>
              <input
                type="number"
                className="form-control"
                onChange={handleChange}
                name="amount"
                required
              />
            </div>

            <button type="submit" className="btn btn-primary m-4">
              Submit
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Payment;
