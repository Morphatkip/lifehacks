import React, { useState } from "react";
import ReactDOM from "react-dom";
import ModalComponent from "../Modal/ModalComponent";
import { useUser } from "../../Utils/UserContext";
import { showNotification } from "../../Utils/notification.util";
function AddExpenses({ hide, updateData: refresh }) {
  const [expense, setExpense] = useState({
    expenseName: "",
    amount: 0,
    dateIncurred: new Date(),
    category: "Fixed",
  });

  const handleClose = () => {
    hide();
  };
  const handleChange = (e) => {
    e.preventDefault();
    const value = e.target.value;
    setExpense({
      ...expense,
      [e.target.name]: value,
    });
  };
  const handleSubmit = async () => {
    try {
      const response = await window.electron.addExpense(expense);

      if (response && response.dataValues) {
        showNotification("Expense added successfully", "success");
        refresh();
      } else {
        showNotification("Failed to add service", "error");
      }
    } catch (error) {
      console.error("Failed to add expense:", error);
      showNotification("An error occurred while adding the service", "error");
    }
    refresh();
    hide();
  };
  return ReactDOM.createPortal(
    <React.Fragment>
      <ModalComponent
        handleClose={handleClose}
        handleSave={handleSubmit}
        btnTitle="Save"
        title={"Add Expenses"}
      >
        <form onSubmit={handleSubmit}>
          <div className="form-group my-2">
            <label className="col-sm-2"> Name</label>
            <div className="col-12">
              <input
                type="text"
                className="form-control"
                onChange={handleChange}
                name="expenseName"
                //value={expensesDetails.name}
              />
            </div>
          </div>

          <div className="form-group my-2">
            <label className="col-sm-2">Amount</label>
            <div className="col-12">
              <input
                type="number"
                className="form-control"
                onChange={handleChange}
                name="amount"
                // value={expensesDetails.amount}
              />
            </div>
          </div>
        </form>
      </ModalComponent>
    </React.Fragment>,
    document.body
  );
}

export default AddExpenses;
