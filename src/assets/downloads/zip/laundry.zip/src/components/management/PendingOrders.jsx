import React, { useEffect, useState } from "react";
import MainContentContainer from "./MainContentContainer";
import Title from "../title/Title";
import Modal from "../Modal/Modal";
import UseModal from "../Modal/UseModal";
import ConfirmationModal from "../Modal/ConfirmationModal";
import { showNotification } from "../../Utils/notification.util";

function PendingOrders() {
  const [servicePending, setServicePending] = useState([]);
  const { isShowingConfirmation, toggleConfirmation } = UseModal();
  const [orderClicked, setOrderClicked] = useState({});

  const getAllOrders = async () => {
    try {
      const orders = await window.electron.getAllOrders();
      const pendingOrders = orders.filter(
        (order) => order.status === "Pending"
      );
      // Update state
      setServicePending(pendingOrders);
      console.log(pendingOrders);
    } catch (error) {
      console.error("Failed to fetch sales data:", error);
    }
  };

  useEffect(() => {
    getAllOrders();
  }, []);

  const handleCompleteService = async (e) => {
    e.preventDefault();

    try {
      const updatedOrder = await window.electron.updateOrderStatus(
        orderClicked.id
      );

      // Optionally, update the UI or show a success message
      showNotification("Order marked as completed", "success");
      getAllOrders();
      toggleConfirmation();
    } catch (error) {
      showNotification(error, "error");
    }
  };

  return (
    <MainContentContainer>
      <div className="mt-3 h-100">
        <div className="side-container">
          <div className="card table-responsive-sm w-100 p-3">
            <table className="table  ">
              <thead className="fw-bold ">
                <tr>
                  <th>Id</th>
                  <th>Updated Date</th>
                  <th>Client Name</th>
                  <th> Service Price</th>
                </tr>
              </thead>
              <ConfirmationModal
                toggleConfirmation={toggleConfirmation}
                isShowingConfirmation={isShowingConfirmation}
                handleConfirmation={handleCompleteService}
                title="Mark Service as Complete ?"
                btnName="okay"
              />
              <tbody className="table-hover">
                {servicePending?.map((service, index) => (
                  <Frame
                    service={service}
                    key={service.id}
                    toggleConfirmation={toggleConfirmation}
                    setOrderClicked={setOrderClicked}
                    isShowingConfirmation={isShowingConfirmation}
                  />
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </MainContentContainer>
  );
}

export default PendingOrders;

const Frame = ({
  service,
  toggleConfirmation,
  setOrderClicked,
  isShowingConfirmation,
}) => {
  const { id, updatedAt, User, totalPrice } = service;
  const handleToggleConfirmation = (e) => {
    e.preventDefault();
    toggleConfirmation(!isShowingConfirmation);
    setOrderClicked(service);
  };
  return (
    <tr>
      <td onClick={handleToggleConfirmation}>#{id}</td>
      <td onClick={handleToggleConfirmation}>
        {new Date(updatedAt).toLocaleDateString()}
      </td>
      <td onClick={() => handleToggleConfirmation}>{User?.name}</td>
      <td onClick={() => handleToggleConfirmation}>{totalPrice}</td>
    </tr>
  );
};
