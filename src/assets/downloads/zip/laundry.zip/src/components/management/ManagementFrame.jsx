import React from "react";

function ManagementFrame({ user, handleShowUser }) {
  console.log({ user });
  return (
    <tr
      onClick={() => {
        handleShowUser(user);
        console.log(user);
      }}
    >
      <td>{user?.name}</td>
      <td>{user?.telephoneOne}</td>
      <td>{"package"}</td>
      <td>
        {user?.packageExpired ? (
          <div className="text-danger">Expired</div>
        ) : user?.packageExpired === null ? (
          <div className="text-danger">null</div>
        ) : (
          <div className="text-success">Active</div>
        )}
      </td>
      <td>{user?.subscriptionExpirationDate}</td>
    </tr>
  );
}

export default ManagementFrame;
