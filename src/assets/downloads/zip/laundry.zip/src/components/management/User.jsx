import React, { useState, useEffect } from "react";
import Switch from "react-switch";
import Modal from "../administrator/modal/Modal";

function User({
  user,
  handleShowUser,
  handleSwitchToggle,
  isShowingAddPayment,
  hide,
}) {
  const [isActive, setIsActive] = useState(false);
  useEffect(() => {
    console.log(user.packageExpired);
    setIsActive(!user.packageExpired);
  }, [user]);

  const handleToggle = () => {
    handleSwitchToggle(); // Call the handleSwitchToggle function passed as prop
    setIsActive(!isActive);
  };

  return (
    <div className="container">
      <div className="row">
        <div className="d-flex justify-content-start">
          <button onClick={handleShowUser} className="btn btn-light">
            Back
          </button>
        </div>
        <Modal
          isShowingAddPayment={isShowingAddPayment}
          hide={hide}
          user={user}
        />
        <div className="col-md-8 mx-auto border p-3">
          <div className="d-flex justify-content-between align-items-center">
            <label className="mr-2">Active</label>
            <Switch
              checked={isActive}
              onChange={handleToggle} // Use the local handleToggle function as the onChange event handler
              onColor="#86d3ff" // Customize the color when the slider is on
              offColor="#dddddd" // Customize the color when the slider is off
              onHandleColor="#2693e6" // Customize the color of the slider handle when it is on
              offHandleColor="#ff0000" // Customize the color of the slider handle when it is off
              handleDiameter={20}
              uncheckedIcon={false}
              checkedIcon={false}
              height={15}
              width={40}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default User;
