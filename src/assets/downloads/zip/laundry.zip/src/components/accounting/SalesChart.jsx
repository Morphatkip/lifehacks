import React from "react";
// eslint-disable-next-line

import { Line, Bar } from "react-chartjs-2";
import moment from "moment";
import {
  Chart,
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement, // Import PointElement for Line chart
  LineElement, // Import LineElement for Line chart
  Tooltip, // Import Tooltip if you're using it
  Legend, // Import Legend if you're using it
} from "chart.js";

Chart.register(
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  Tooltip,
  Legend
);

export const LineChart = ({ salesData }) => {
  // Group sales data by week and calculate average sales for each week
  const weeklySalesData = salesData.reduce((acc, sale) => {
    const week = moment(sale.orderDate).startOf("week").format("MMM DD, YYYY");
    acc[week] = acc[week] ? [...acc[week], sale.totalPrice] : [sale.totalPrice];
    return acc;
  }, {});

  const labels = Object.keys(weeklySalesData);
  const averageSales = labels.map((week) => {
    const totalSales = weeklySalesData[week].reduce(
      (sum, amount) => sum + amount,
      0
    );
    return totalSales / weeklySalesData[week].length;
  });

  const totalSales = labels.map((week) =>
    weeklySalesData[week].reduce((sum, amount) => sum + amount, 0)
  );

  const lineChartData = {
    labels: labels,
    datasets: [
      {
        label: "Average Weekly Sales Line chart",
        type: "line",
        backgroundColor: "rgb(255, 99, 132)",
        borderColor: "rgb(255, 99, 132)",
        data: averageSales,
      },
    ],
  };

  const barChartData = {
    labels: labels,
    datasets: [
      {
        label: "Total Weekly Sales Bar graph",
        backgroundColor: "rgb(54, 162, 235)",
        borderColor: "rgb(54, 162, 235)",
        data: totalSales,
      },
    ],
  };

  const options = {
    scales: {
      x: {
        display: true,
        title: {
          display: true,
          text: "Week",
        },
      },
      y: {
        display: true,
        title: {
          display: true,
          text: "Amount",
        },
      },
    },
  };

  return (
    <div style={{ maxHeight: "400px" }}>
      <Line data={lineChartData} options={options} />
      {/* <Bar data={barChartData} options={options} /> */}
    </div>
  );
};

export const BarChart = ({ salesData }) => {
  // Group sales data by week and calculate average sales for each week
  const weeklySalesData = salesData.reduce((acc, sale) => {
    const week = moment(sale.orderDate).startOf("week").format("MMM DD, YYYY");
    acc[week] = acc[week] ? [...acc[week], sale.totalPrice] : [sale.totalPrice];
    return acc;
  }, {});

  const labels = Object.keys(weeklySalesData);
  const averageSales = labels.map((week) => {
    const totalSales = weeklySalesData[week].reduce(
      (sum, amount) => sum + amount,
      0
    );
    return totalSales / weeklySalesData[week].length;
  });

  const totalSales = labels.map((week) =>
    weeklySalesData[week].reduce((sum, amount) => sum + amount, 0)
  );

  const lineChartData = {
    labels: labels,
    datasets: [
      {
        label: "Average Weekly Sales Line chart",
        type: "line",
        backgroundColor: "rgb(255, 99, 132)",
        borderColor: "rgb(255, 99, 132)",
        data: averageSales,
      },
    ],
  };

  const barChartData = {
    labels: labels,
    datasets: [
      {
        label: "Total Weekly Sales Bar graph",
        backgroundColor: "rgb(54, 162, 235)",
        borderColor: "rgb(54, 162, 235)",
        data: totalSales,
      },
    ],
  };

  const options = {
    scales: {
      x: {
        display: true,
        title: {
          display: true,
          text: "Week",
        },
      },
      y: {
        display: true,
        title: {
          display: true,
          text: "Amount",
        },
      },
    },
  };

  return (
    <div style={{ maxHeight: "400px" }}>
      <Bar data={barChartData} options={options} />
    </div>
  );
};
