import React, { useEffect, useState } from "react";
import { showNotification } from "../../Utils/notification.util";
import { useUser } from "../../Utils/UserContext";

function AddNewStock({ product, hide, fetchProducts: refresh, goBack }) {
  const [productStockToBeAdded, setProductStockToBeAdded] = useState({});
  const { user } = useUser();
  const [expiryFlag, setExpiryFlag] = useState(0);

  useEffect(() => {
    const today = new Date();
    if (product) {
      setProductStockToBeAdded({
        stockEntryDate: today,
        stockExpireDate: "",
        quantity: 0,
        product: product,
        batchNumber: "",
        expiryDateFlag: "",
      });
    }
    // eslint-disable-next-line
  }, []);

  const handleChange = (e) => {
    e.preventDefault();
    const value = e.target.value;
    setProductStockToBeAdded({
      ...productStockToBeAdded,
      [e.target.name]: value,
    });
  };
  const handleExpiryDateFlag = (e) => {
    e.preventDefault();
    setExpiryFlag(e.target.value);
    const exp = new Date(productStockToBeAdded.stockExpireDate);
    exp.setDate(exp.getDate() - expiryFlag);
    productStockToBeAdded.expiryDateFlag = exp;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (productStockToBeAdded.stockExpireDate === "") {
      showNotification("Expiry date cannot be null");
      return;
    }
    console.log(productStockToBeAdded);

    setProductStockToBeAdded({});
    hide();
  };
  return (
    <div className="row">
      <div className="d-flex justify-content-start">
        <div>
          <button onClick={hide} className="btn btn-light">
            Back
          </button>
        </div>
      </div>

      <div className="col-md-8 mx-auto border p-3">
        <form onSubmit={handleSubmit}>
          <div className=" form-group ">
            <div className="row m-2">
              <label className="col-sm-4">Quantity</label>
              <div className="col-sm-6">
                <input
                  className="form-control"
                  type="number"
                  onChange={handleChange}
                  name="quantity"
                  value={productStockToBeAdded.quantity}
                />
              </div>
            </div>

            <div className="row m-2">
              <label className="col-sm-4">Stock Expiry Date</label>
              <div className="col-sm-6">
                <input
                  className="form-control"
                  type="date"
                  onChange={handleChange}
                  name="stockExpireDate"
                  value={productStockToBeAdded.stockExpireDate}
                />
              </div>
            </div>

            <div className="row m-2">
              <label className="col-sm-4">Batch Number</label>
              <div className="col-sm-6">
                <input
                  className="form-control"
                  type="text"
                  onChange={handleChange}
                  name="batchNumber"
                  value={productStockToBeAdded.batchNumber}
                />
              </div>
            </div>

            <div className="row m-2">
              <label className="col-sm-4">Expiry Flag date</label>
              <div className="col-sm-6">
                <input
                  className="form-control"
                  type="text"
                  onChange={handleExpiryDateFlag}
                  //name="batchNumber"
                  value={expiryFlag}
                />
              </div>
            </div>
          </div>
          <div className="d-flex justify-content-end mt-5">
            <button type="submit" className="btn btn-success">
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default AddNewStock;
