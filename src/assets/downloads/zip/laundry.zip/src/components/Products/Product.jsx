import React from "react";
import { useState } from "react";
import EditModal from "../Modal/EditModal";
import UseModal from "../Modal/UseModal";
import AddNewStock from "../stock/AddNewStock";
import Title from "../title/Title";

function Product({
  management,
  stock,
  product,
  hide,
  stockQuantity,
  fetchProducts,
}) {
  const { isShowingEdit, toggleEdit } = UseModal();
  const [isShowingAddNewStock, setIsShowingAddNewStock] = useState(false);

  const toggleAddNewStock = () => {
    setIsShowingAddNewStock(!isShowingAddNewStock);
  };
  return (
    <div style={{ height: "100%" }}>
      {isShowingEdit ? (
        <EditModal
          hide={toggleEdit}
          goBack={hide}
          product={product}
          fetchProducts={fetchProducts}
        />
      ) : isShowingAddNewStock ? (
        <AddNewStock
          hide={toggleAddNewStock}
          product={product}
          fetchProducts={fetchProducts}
          goBack={hide}
        />
      ) : (
        <div className="row">
          <div className="d-flex justify-content-start">
            <div>
              <button onClick={hide} className="btn btn-light">
                Back
              </button>
            </div>
          </div>
          <div className="col-md-8 mx-auto border p-3">
            <Title
              name={product.displayName}
              btn
              btnName={"Edit"}
              handleClick={toggleEdit}
            />

            <div className="row">
              <div className="col">Service Name</div>
              <div className="col">{product.dataValues.serviceName}</div>
            </div>

            <div className="row">
              <div className="col">Service Price</div>
              <div className="col">{product.dataValues.price}</div>
            </div>

            <div className="row">
              <div className="col">descprition</div>
              <div className="col">{product.dataValues.description}</div>
            </div>

            <div className="row">
              <div className="col">Service Duration</div>
              <div className="col">{product.dataValues.duration} h</div>
            </div>
          </div>
          {/*   <div className="col-md-8 mx-auto p-3">
            <button className=" btn float-end border" onClick={toggleEdit}>
              Edit
            </button>
          </div> */}
        </div>
      )}
    </div>
  );
}

export default Product;
