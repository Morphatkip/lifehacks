// database.js
const { Sequelize, DataTypes } = require("sequelize");

// Initialize Sequelize with foreign key enforcement enabled
const sequelize = new Sequelize({
  dialect: "sqlite",
  storage: "./laundry_app.db",
  logging: console.log, // Enables logging for debugging
});

// Define the Users model
const User = sequelize.define(
  "User",
  {
    name: { type: DataTypes.STRING, allowNull: false },
    email: { type: DataTypes.STRING, allowNull: true, unique: true },
    password: { type: DataTypes.STRING, allowNull: true },
    phone_number: { type: DataTypes.STRING, allowNull: false },
    role: { type: DataTypes.STRING, allowNull: false }, // e.g., 'customer', 'admin'
    address: { type: DataTypes.STRING, allowNull: true },
  },
  { timestamps: true }
);

// Define the Services model
const Service = sequelize.define(
  "Service",
  {
    serviceName: { type: DataTypes.STRING, allowNull: false },
    description: { type: DataTypes.STRING, allowNull: true },
    price: { type: DataTypes.FLOAT, allowNull: false },
    duration: { type: DataTypes.INTEGER, allowNull: false }, // Duration in hours
  },
  { timestamps: true }
);

// Define the Orders model
const Order = sequelize.define(
  "Order",
  {
    userId: { type: DataTypes.INTEGER, allowNull: false },
    totalPrice: { type: DataTypes.FLOAT, allowNull: false },
    status: { type: DataTypes.STRING, allowNull: false }, // Pending, Completed, etc.
    orderDate: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
    completionDate: { type: DataTypes.DATE, allowNull: true },
  },
  { timestamps: true }
);

// Define the OrderItems model for many-to-many relationship between Orders and Services
const OrderItem = sequelize.define(
  "OrderItem",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    orderId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: { model: Order, key: "id" },
      onDelete: "CASCADE",
    },
    serviceId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: { model: Service, key: "id" },
      onDelete: "CASCADE",
    },
    quantity: { type: DataTypes.FLOAT, allowNull: false },
    price: { type: DataTypes.FLOAT, allowNull: false },
  },
  { timestamps: true }
);

// Define the Payments model
const Payment = sequelize.define(
  "Payment",
  {
    orderId: { type: DataTypes.INTEGER, allowNull: false },
    amount: { type: DataTypes.FLOAT, allowNull: false },
    paymentMethod: { type: DataTypes.STRING, allowNull: false },
    paymentStatus: { type: DataTypes.STRING, allowNull: false },
    paymentDate: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
  },
  { timestamps: true }
);

// Define the Deliveries model
const Delivery = sequelize.define(
  "Delivery",
  {
    orderId: { type: DataTypes.INTEGER, allowNull: false },
    deliveryAddress: { type: DataTypes.STRING, allowNull: false },
    pickupTime: { type: DataTypes.DATE, allowNull: false },
    deliveryTime: { type: DataTypes.DATE, allowNull: true },
    status: { type: DataTypes.STRING, allowNull: false },
  },
  { timestamps: true }
);

// Define the Reviews model
const Review = sequelize.define(
  "Review",
  {
    userId: { type: DataTypes.INTEGER, allowNull: false },
    serviceId: { type: DataTypes.INTEGER, allowNull: false },
    rating: { type: DataTypes.INTEGER, allowNull: false }, // 1-5
    comment: { type: DataTypes.STRING, allowNull: true },
  },
  { timestamps: true }
);

// Define the Promotions model
const Promotion = sequelize.define(
  "Promotion",
  {
    promoCode: { type: DataTypes.STRING, allowNull: false, unique: true },
    description: { type: DataTypes.STRING, allowNull: true },
    discountPercentage: { type: DataTypes.FLOAT, allowNull: false },
    startDate: { type: DataTypes.DATE, allowNull: false },
    endDate: { type: DataTypes.DATE, allowNull: false },
  },
  { timestamps: true }
);

// Define the Expenses model
const Expense = sequelize.define(
  "Expense",
  {
    expenseName: { type: DataTypes.STRING, allowNull: false },
    amount: { type: DataTypes.FLOAT, allowNull: false },
    dateIncurred: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
    category: { type: DataTypes.STRING, allowNull: false },
    description: { type: DataTypes.STRING, allowNull: true },
  },
  { timestamps: true }
);

//  CompanyInfo model
const CompanyInfo = sequelize.define(
  "CompanyInfo",
  {
    companyName: { type: DataTypes.STRING, allowNull: false },
    location: { type: DataTypes.STRING, allowNull: false },
    currency: { type: DataTypes.STRING, allowNull: false },
  },
  { timestamps: true }
);

// Define relationships
User.hasMany(Order, { foreignKey: "userId" });
Order.belongsTo(User, { foreignKey: "userId" });

Order.belongsToMany(Service, { through: OrderItem, foreignKey: "orderId" });
Service.belongsToMany(Order, { through: OrderItem, foreignKey: "serviceId" });

Order.hasOne(Payment, { foreignKey: "orderId" });
Payment.belongsTo(Order, { foreignKey: "orderId" });

Order.hasOne(Delivery, { foreignKey: "orderId" });
Delivery.belongsTo(Order, { foreignKey: "orderId" });

User.hasMany(Review, { foreignKey: "userId" });
Review.belongsTo(User, { foreignKey: "userId" });

Service.hasMany(Review, { foreignKey: "serviceId" });
Review.belongsTo(Service, { foreignKey: "serviceId" });

// Sync the database
sequelize
  .sync({ alter: true })
  .then(() => {
    console.log("✅ Database & tables created successfully!");
  })
  .catch((error) => {
    console.error("❌ Error syncing database:", error);
  });

// Export models
module.exports = {
  User,
  Service,
  Order,
  OrderItem,
  Payment,
  Delivery,
  Review,
  Promotion,
  Expense,
  CompanyInfo,
  sequelize,
};
