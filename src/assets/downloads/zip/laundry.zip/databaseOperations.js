const {
  User,
  Service,
  Order,
  Expense,
  Payment,
  Delivery,
  Review,
  Promotion,
  OrderItem,
} = require("./database");

// Function to login a user
const loginUser = async (email, password) => {
  try {
    const user = await User.findOne({ where: { email, password } });
    if (user) {
      return { success: true, user };
    } else {
      return { success: false, message: "Invalid email or password" };
    }
  } catch (error) {
    console.error("Login error:", error);
    throw new Error("Login failed");
  }
};

// Function to add a new service
const addService = async (serviceData) => {
  try {
    const service = await Service.create(serviceData);
    return service;
  } catch (error) {
    console.error("Add service error:", error);
    throw new Error("Failed to add service");
  }
};

// Function to get a single service by ID
const getService = async (id) => {
  try {
    const service = await Service.findByPk(id);
    return service;
  } catch (error) {
    console.error("Get service error:", error);
    throw new Error("Failed to fetch service");
  }
};

// Function to get all services
const getAllServices = async () => {
  try {
    const services = await Service.findAll();
    return services;
  } catch (error) {
    console.error("Get all services error:", error);
    throw new Error("Failed to fetch services");
  }
};
//Function to get all users
const getAllUsers = async () => {
  try {
    const users = await User.findAll();
    return users;
  } catch (error) {
    throw new Error("Failed to fetch users");
  }
};
// Function to create a new expense
const addExpense = async (expenseData) => {
  try {
    const expense = await Expense.create(expenseData);
    return expense;
  } catch (error) {
    console.error("Add expense error:", error);
    throw new Error("Failed to add expense");
  }
};

// Function to get a single expense by ID
const getExpense = async (id) => {
  try {
    const expense = await Expense.findByPk(id);
    return expense;
  } catch (error) {
    console.error("Get expense error:", error);
    throw new Error("Failed to fetch expense");
  }
};

// Function to get all expenses
const getAllExpenses = async () => {
  try {
    const expenses = await Expense.findAll();
    return expenses;
  } catch (error) {
    console.error("Get all expenses error:", error);
    throw new Error("Failed to fetch expenses");
  }
};

// Function to create a new order
const createOrder = async (
  orderData,
  serviceItems,
  customerData,
  paymentData
) => {
  try {
    // Check if the customer exists based on phone number (unique identifier)

    let customer = await User.findOne({
      where: { phone_number: customerData.phone_number },
    });

    // If the customer doesn't exist, create a new one
    if (!customer) {
      customer = await User.create(customerData);
    }

    // Create the order and associate it with the customer
    // Create the order and associate it with the customer
    const order = await Order.create({ ...orderData, userId: customer.id });

    // Loop through each service item and create an OrderItem for each service
    for (const item of serviceItems) {
      const { serviceId, quantity, price } = item;

      // Ensure the service exists (optional validation)
      const service = await Service.findByPk(serviceId);
      if (!service) {
        throw new Error(`Service with ID ${serviceId} not found`);
      }

      // Create an OrderItem entry for each service in the order
      await OrderItem.create({
        orderId: order.id,
        serviceId: serviceId,
        quantity: quantity,
        price: price,
      });
    }

    // Create and associate a payment with the order
    if (paymentData) {
      await Payment.create({ ...paymentData, orderId: order.id });
    }

    // Fetch the order again including associated data
    const completeOrder = await Order.findByPk(order.id, {
      include: [
        // Include customer details
        Service, // Include ordered services
      ],
    });

    return completeOrder.toJSON();
  } catch (error) {
    console.error("Create order error:", error);
    throw new Error("Failed to create order");
  }
};

// Function to get a single order by ID
const getOrder = async (id) => {
  try {
    const order = await Order.findByPk(id, {
      include: [Service, Payment, Delivery], // Include related services, payment, and delivery
    });
    return order;
  } catch (error) {
    console.error("Get order error:", error);
    throw new Error("Failed to fetch order");
  }
};

// Function to get all orders
const getAllOrders = async () => {
  try {
    const orders = await Order.findAll({
      include: [
        User, // Explicit alias matching Order.belongsTo(User, { foreignKey: "customerId" })
        Service,
        Payment,
        Delivery,
      ],
    });

    return orders.map((order) => order.toJSON()); // Convert each order to JSON
  } catch (error) {
    console.error("Get all orders error:", error);
    throw new Error("Failed to fetch orders");
  }
};

// Function to create a new payment
const createPayment = async (paymentData) => {
  try {
    const payment = await Payment.create(paymentData);
    return payment;
  } catch (error) {
    console.error("Create payment error:", error);
    throw new Error("Failed to create payment");
  }
};

// Function to create a new user
const createUser = async (userData) => {
  try {
    // Check if a user with the same email already exists
    const existingUser = await User.findOne({ email: userData.email });
    if (existingUser) {
      throw new Error("User with this email already exists");
    }

    // Create new user
    const user = await User.create(userData);
    return user;
  } catch (error) {
    console.error("Create user error:", error);
    throw new Error(error.message || "Failed to create user");
  }
};

// Function to create or update company info
const createCompany = async (companyData) => {
  try {
    // Check if a company already exists
    const existingCompany = await CompanyInfo.findOne();

    if (existingCompany) {
      throw new Error(
        "Company information already exists. Use updateCompany to modify details."
      );
    }

    // Create new company
    const company = await CompanyInfo.create(companyData);
    return company;
  } catch (error) {
    console.error("Create company error:", error);
    throw new Error(error.message || "Failed to create company");
  }
};

// Function to create a new delivery
const createDelivery = async (deliveryData) => {
  try {
    const delivery = await Delivery.create(deliveryData);
    return delivery;
  } catch (error) {
    console.error("Create delivery error:", error);
    throw new Error("Failed to create delivery");
  }
};

// Function to add a review
const addReview = async (reviewData) => {
  try {
    const review = await Review.create(reviewData);
    return review;
  } catch (error) {
    console.error("Add review error:", error);
    throw new Error("Failed to add review");
  }
};

// Function to get a single review by ID
const getReview = async (id) => {
  try {
    const review = await Review.findByPk(id);
    return review;
  } catch (error) {
    console.error("Get review error:", error);
    throw new Error("Failed to fetch review");
  }
};

// Function to get all reviews
const getAllReviews = async () => {
  try {
    const reviews = await Review.findAll();
    return reviews;
  } catch (error) {
    console.error("Get all reviews error:", error);
    throw new Error("Failed to fetch reviews");
  }
};

// Function to create a new promotion
const createPromotion = async (promotionData) => {
  try {
    const promotion = await Promotion.create(promotionData);
    return promotion;
  } catch (error) {
    console.error("Create promotion error:", error);
    throw new Error("Failed to create promotion");
  }
};

// Function to get a single promotion by ID
const getPromotion = async (id) => {
  try {
    const promotion = await Promotion.findByPk(id);
    return promotion;
  } catch (error) {
    console.error("Get promotion error:", error);
    throw new Error("Failed to fetch promotion");
  }
};
const getCompany = async () => {
  try {
    const company = await CompanyInfo.findOne(); // Fetch the single company record
    return company;
  } catch (error) {
    console.error("Get company error:", error);
    throw new Error("Failed to fetch company information");
  }
};

// Function to get all promotions
const getAllPromotions = async () => {
  try {
    const promotions = await Promotion.findAll();
    return promotions;
  } catch (error) {
    console.error("Get all promotions error:", error);
    throw new Error("Failed to fetch promotions");
  }
};

// Function to delete a service by ID
const deleteService = async (id) => {
  try {
    const service = await Service.findByPk(id);
    if (!service) {
      return { success: false, message: "Service not found" };
    }

    await service.destroy();
    return { success: true, message: "Service deleted successfully" };
  } catch (error) {
    console.error("Delete service error:", error);
    throw new Error("Failed to delete service");
  }
};

const updatePayment = async (orderId, updatedPayment) => {
  try {
    // Find the existing order and include payment details
    let order = await Order.findByPk(orderId, { include: [Payment] });

    if (!order) {
      throw new Error("Order not found");
    }

    // Check if a payment record exists for the order
    if (order.Payment) {
      // Update the existing payment record
      await order.Payment.update(updatedPayment);
    } else {
      // Create a new payment record linked to the order
      await Payment.create({ ...updatedPayment, orderId });
    }

    // Fetch and return the updated order with payment details
    order = await Order.findByPk(orderId, { include: [Payment] });
    return order.toJSON();
  } catch (error) {
    console.error("Update payment error:", error);
    throw new Error("Failed to update payment");
  }
};
//Function to update Service
const updateService = async (serviceId, updatedServiceData) => {
  try {
    // Find the service by ID
    const service = await Service.findByPk(serviceId);

    if (!service) {
      throw new Error("Service not found");
    }

    // Update the service with new data (only provided fields will be updated)
    await service.update(updatedServiceData);

    // Return the updated service
    return service.toJSON();
  } catch (error) {
    console.error("Update service error:", error);
    throw new Error("Failed to update service");
  }
};
//function to update User
const updateUser = async (userId, currentPassword, newPassword) => {
  try {
    // Find the user by ID
    const user = await User.findByPk(userId);
    if (!user) {
      throw new Error("User not found");
    }

    // Verify if current password is correct
    if (user.password !== currentPassword) {
      throw new Error("Current password is incorrect");
    }

    // Update user password
    await user.update({ password: newPassword });

    // Return updated user data
    return { success: true, message: "Password updated successfully" };
  } catch (error) {
    console.error("Update user error:", error);
    return { success: false, message: error.message };
  }
};
//Function to update order status
const updateOrderStatus = async (orderId) => {
  try {
    // Find the existing order
    let order = await Order.findByPk(orderId, {
      include: [User, Payment, Delivery], // Include associated tables
    });

    if (!order) {
      throw new Error("Order not found");
    }

    // Update the order status to "completed"
    await order.update({ status: "completed" });

    // Fetch the updated order with associations to ensure data integrity
    order = await Order.findByPk(orderId, {
      include: [User, Payment], // Re-fetch with associations
    });

    return order.toJSON();
  } catch (error) {
    console.error("Update order status error:", error);
    throw new Error("Failed to update order status");
  }
};

module.exports = {
  loginUser,
  addService,
  getService,
  getAllServices,
  addExpense,
  getExpense,
  getAllExpenses,
  createOrder,
  getOrder,
  getAllOrders,
  createPayment,
  createDelivery,
  addReview,
  getReview,
  getAllReviews,
  createPromotion,
  getPromotion,
  getAllPromotions,
  deleteService,
  getAllUsers,
  updatePayment,
  updateService,
  updateUser,
  createUser,
  updateOrderStatus,
  createCompany,
  getCompany,
};
