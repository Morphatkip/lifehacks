import React, { useState } from "react";
import "../assets/css/style.css";
import {
  ChangePassword,
  ProfileEdit,
  ProfileOverview,
  ProfileSettings,
} from "../components/ProfileComponents";
import { Link } from "react-router-dom";
import profileImage from "../assets/img/profile-img.jpg";
function Profile() {
  const [activeTab, setActiveTab] = useState("profile-overview");

  const handleTabClick = (tabId) => {
    setActiveTab(tabId);
  };
  return (
    <div>
      <main className="main container">
        <div className="pagetitle">
          <h1>Profile</h1>
          <nav>
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link to="https://www.firetipsedu.com/">Home</Link>
              </li>
              <li className="breadcrumb-item">User</li>
              <li className="breadcrumb-item active">Profile</li>
            </ol>
          </nav>
        </div>
        {/*   End Page Title  */}

        <section className="section profile">
          <div className="row">
            <div className="col-xl-4">
              <div className="card">
                <div className="card-body profile-card pt-4 d-flex flex-column align-items-center">
                  <img
                    src={profileImage}
                    alt="Profile"
                    className="rounded-circle"
                  />
                  <h2>K Morphat</h2>
                  <h3>Software Engineer</h3>
                  <div className="social-links mt-2">
                    <a href="#" className="twitter">
                      <i className="bi bi-twitter"></i>
                    </a>
                    <a href="#" className="facebook">
                      <i className="bi bi-facebook"></i>
                    </a>
                    <a href="#" className="instagram">
                      <i className="bi bi-instagram"></i>
                    </a>
                    <a href="#" className="linkedin">
                      <i className="bi bi-linkedin"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-xl-8">
              <div className="card">
                <div className="card-body pt-3">
                  <ul className="nav nav-tabs nav-tabs-bordered">
                    <li className="nav-item">
                      <button
                        className={`nav-link ${
                          activeTab === "profile-overview" ? "active" : ""
                        }`}
                        onClick={() => handleTabClick("profile-overview")}
                      >
                        Overview
                      </button>
                    </li>

                    <li className="nav-item">
                      <button
                        className={`nav-link ${
                          activeTab === "profile-edit" ? "active" : ""
                        }`}
                        onClick={() => handleTabClick("profile-edit")}
                      >
                        Edit Profile
                      </button>
                    </li>

                    <li className="nav-item">
                      <button
                        className={`nav-link ${
                          activeTab === "profile-settings" ? "active" : ""
                        }`}
                        onClick={() => handleTabClick("profile-settings")}
                      >
                        Settings
                      </button>
                    </li>

                    <li className="nav-item">
                      <button
                        className={`nav-link ${
                          activeTab === "profile-change-password"
                            ? "active"
                            : ""
                        }`}
                        onClick={() =>
                          handleTabClick("profile-change-password")
                        }
                      >
                        Change Password
                      </button>
                    </li>
                  </ul>

                  {/*   Bordered Tabs  */}

                  <div className="tab-content pt-2">
                    <div
                      className={`tab-pane fade ${
                        activeTab === "profile-overview" ? "show active" : ""
                      } profile-overview`}
                    >
                      <ProfileOverview />
                    </div>

                    <div
                      className={`tab-pane fade ${
                        activeTab === "profile-edit" ? "show active" : ""
                      } profile-edit pt-3`}
                    >
                      <ProfileEdit />
                    </div>
                    <div
                      className={`tab-pane fade ${
                        activeTab === "profile-settings" ? "show active" : ""
                      } pt-3`}
                    >
                      <ProfileSettings />
                    </div>
                    <div
                      className={`tab-pane fade ${
                        activeTab === "profile-change-password"
                          ? "show active"
                          : ""
                      } pt-3`}
                    >
                      <ChangePassword />
                    </div>
                  </div>
                  {/* End tab content */}
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      {/*   End #main  */}
    </div>
  );
}

export default Profile;
